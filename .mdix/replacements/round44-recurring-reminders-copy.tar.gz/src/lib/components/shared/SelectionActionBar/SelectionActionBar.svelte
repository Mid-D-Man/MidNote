<script lang="ts">
  import Button from "$lib/components/ui/Button/Button.svelte";
  import ConfirmDialog from "$lib/components/ui/ConfirmDialog/ConfirmDialog.svelte";
  import Sheet from "$lib/components/ui/Sheet/Sheet.svelte";
  import { breadcrumb } from "$lib/debug/log.svelte";
  import type { ExportFormat } from "$lib/utils/selectionActions";

  let {
    selectedCount,
    itemLabel,
    canMerge,
    selectionHasEncrypted = false,
    onCancel,
    onDelete,
    onSend,
    onCopy,
    onMerge,
    onExport,
  }: {
    selectedCount: number;
    // "note" or "todo" — only used for copy ("3 notes selected").
    itemLabel: string;
    canMerge: boolean;
    // Only changes the tooltip text — the actual block is canMerge
    // already being false (+page.svelte folds this in). Kept separate
    // here purely so the disabled-state explanation can be specific
    // ("unlock or deselect it") rather than the generic
    // not-enough-items copy when that's not actually why it's disabled.
    selectionHasEncrypted?: boolean;
    onCancel: () => void;
    onDelete: () => void;
    onSend: () => void;
    // Round 44: put the selected items' text on the clipboard.
    onCopy: () => void;
    onMerge: () => void;
    onExport: (format: ExportFormat) => void;
  } = $props();

  let showDeleteConfirm = $state(false);
  let showExportSheet = $state(false);

  function confirmDelete() {
    breadcrumb(`selection bar: delete confirmed (${selectedCount} items)`);
    onDelete();
  }

  function pickFormat(format: ExportFormat) {
    breadcrumb(`selection bar: export format picked -> ${format}`);
    showExportSheet = false;
    onExport(format);
  }
</script>

<div class="bar">
  <button class="cancel" onclick={onCancel} aria-label="Cancel selection">
    <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2">
      <line x1="18" y1="6" x2="6" y2="18" /><line x1="6" y1="6" x2="18" y2="18" />
    </svg>
  </button>

  <span class="count">{selectedCount} {itemLabel}{selectedCount === 1 ? "" : "s"} selected</span>

  <div class="actions">
    <Button
      variant="ghost"
      size="icon"
      onclick={() => {
        breadcrumb("selection bar: Send tapped");
        onSend();
      }}
      aria-label="Send"
      disabled={selectedCount === 0}
    >
      <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2">
        <circle cx="18" cy="5" r="3" /><circle cx="6" cy="12" r="3" /><circle cx="18" cy="19" r="3" />
        <line x1="8.6" y1="13.5" x2="15.4" y2="17.5" /><line x1="15.4" y1="6.5" x2="8.6" y2="10.5" />
      </svg>
    </Button>

    <Button
      variant="ghost"
      size="icon"
      onclick={() => {
        breadcrumb("selection bar: Copy content tapped");
        onCopy();
      }}
      aria-label="Copy content"
      title="Copy content"
      disabled={selectedCount === 0}
    >
      <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2">
        <rect x="9" y="9" width="13" height="13" rx="2" /><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" />
      </svg>
    </Button>

    <Button
      variant="ghost"
      size="icon"
      onclick={() => {
        breadcrumb("selection bar: Merge tapped");
        onMerge();
      }}
      aria-label="Merge"
      disabled={!canMerge}
      title={canMerge ? "Merge selected" : selectionHasEncrypted ? "Unlock or deselect the locked item to merge" : "Select 2+ items of the same type to merge"}
    >
      <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M6 3v12a3 3 0 0 0 3 3h6" /><path d="m15 6 3-3 3 3" /><path d="M18 3v18" />
      </svg>
    </Button>

    <Button
      variant="ghost"
      size="icon"
      onclick={() => {
        breadcrumb("selection bar: Export sheet opened");
        showExportSheet = true;
      }}
      aria-label="Export"
      disabled={selectedCount === 0}
    >
      <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M12 3v12" /><path d="m7 10 5 5 5-5" /><path d="M5 21h14" />
      </svg>
    </Button>

    <Button
      variant="ghost"
      size="icon"
      onclick={() => {
        breadcrumb("selection bar: Delete icon tapped (confirm dialog opening)");
        showDeleteConfirm = true;
      }}
      aria-label="Delete"
      disabled={selectedCount === 0 || selectionHasEncrypted}
      title={selectionHasEncrypted ? "Unlock or deselect the locked item to delete" : "Delete selected"}
    >
      <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2">
        <polyline points="3 6 5 6 21 6" />
        <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" />
      </svg>
    </Button>
  </div>
</div>

<ConfirmDialog
  bind:open={showDeleteConfirm}
  title="Delete {selectedCount} {itemLabel}{selectedCount === 1 ? '' : 's'}"
  description="This can't be undone."
  confirmLabel="Delete"
  danger
  onconfirm={confirmDelete}
/>

<Sheet bind:open={showExportSheet} side="bottom" title="Export as">
  <div class="menu-list">
    <button class="menu-item" onclick={() => pickFormat("separate")}>Separate files</button>
    <button class="menu-item" onclick={() => pickFormat("combined")}>One combined file</button>
    <button class="menu-item" onclick={() => pickFormat("zip")}>Zip archive</button>
  </div>
</Sheet>

<style>
  .bar {
    position: fixed;
    left: 0;
    right: 0;
    bottom: 0;
    z-index: 45;
    display: flex;
    align-items: center;
    gap: var(--space-3);
    padding: var(--space-3) var(--space-4);
    padding-bottom: max(var(--space-3), env(safe-area-inset-bottom));
    background: var(--surface-raised);
    border-top: 1px solid var(--hairline);
    box-shadow: 0 -8px 24px rgba(0, 0, 0, 0.28);
  }
  .cancel {
    flex-shrink: 0;
    width: 32px;
    height: 32px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: transparent;
    border: none;
    border-radius: var(--radius-sm);
    color: var(--text-hi);
    cursor: pointer;
  }
  .cancel:hover {
    background: var(--surface);
  }
  .count {
    flex: 1;
    min-width: 0;
    font-size: 13px;
    color: var(--text-hi);
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  .actions {
    display: flex;
    align-items: center;
    gap: var(--space-1);
    flex-shrink: 0;
  }
  .menu-list {
    display: flex;
    flex-direction: column;
    gap: var(--space-1);
  }
  .menu-item {
    display: block;
    width: 100%;
    text-align: left;
    padding: var(--space-2) var(--space-3);
    background: transparent;
    border: none;
    border-radius: var(--radius-sm);
    color: var(--text-hi);
    font-size: 13px;
    cursor: pointer;
  }
  .menu-item:hover {
    background: var(--surface);
  }
</style>
