// TEMPORARY local persistence — localStorage, same as the original
// SimpleNotesAndRecipies app used. This is a placeholder for
// src-tauri/src/data/entries.rs + index.rs, which aren't implemented yet
// (see the TODOs there). Swapping this module's internals for real
// Tauri invoke() calls later shouldn't require touching any component
// that imports from here, since the exported function shapes below are
// what a Tauri-backed version would expose too.
import type { Board, CustomIcon, CustomTheme, Entry, Note, Todo } from "$lib/types/entry";
import { NO_THEME } from "$lib/types/entry";
import { getColorSync } from "colorthief";

const ENTRIES_KEY = "midnote:entries";
const TAGS_KEY = "midnote:known-tags";
const CUSTOM_THEMES_KEY = "midnote:custom-themes";
const CUSTOM_ICONS_KEY = "midnote:custom-icons";

export function generateId(): string {
  return crypto.randomUUID();
}

export function loadEntries(): Entry[] {
  if (typeof localStorage === "undefined") return [];
  try {
    const raw = localStorage.getItem(ENTRIES_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) {
      console.error("storage: entries in localStorage isn't an array, ignoring:", parsed);
      return [];
    }
    // Defensive per-entry validation — a todo saved by an earlier build
    // during testing (different shape) shouldn't be able to crash the
    // whole list read, just get skipped and logged instead.
    const valid: Entry[] = [];
    for (const e of parsed) {
      if (!e || typeof e !== "object" || !e.id || !e.type) {
        console.error("storage: skipping malformed entry:", e);
        continue;
      }
      if (e.type === "todo") {
        if (!Array.isArray(e.steps)) e.steps = [];
        if (!Array.isArray(e.annotations)) e.annotations = [];
        if (!Array.isArray(e.categories) || e.categories.length === 0) e.categories = ["Steps"];
      }
      // Same defensive treatment as todos above. No migration path is
      // needed here (boards are new — no older on-disk shape exists to
      // upgrade from), but a board whose arrays are missing or
      // corrupted should still open as an empty board rather than
      // crashing the whole list read. viewport stays null when absent,
      // which the board route reads as "no saved position, fit to
      // content instead."
      if (e.type === "board") {
        if (!Array.isArray(e.nodes)) e.nodes = [];
        if (!Array.isArray(e.edges)) e.edges = [];
        if (!e.viewport || typeof e.viewport.zoom !== "number") e.viewport = null;
      }
      if (!Array.isArray(e.tags)) e.tags = [];
      // Entries saved before the struck field existed won't have it at
      // all (undefined, not false) — same migration-default treatment
      // as tags/steps/annotations/categories above. isPinned/theme are
      // the two newest fields and get identical treatment.
      if (typeof e.struck !== "boolean") e.struck = false;
      if (typeof e.isPinned !== "boolean") e.isPinned = false;
      // Theme v2 migration: v1 stored one flat `theme` field, which is
      // exactly what's now `headerTheme` (see entry.ts's comment on
      // headerTheme — the card/editor-header treatment is unchanged,
      // only renamed/re-scoped). An entry saved under v1 has `e.theme`
      // but not `e.headerTheme`; carry its value over rather than
      // resetting it to none, so nobody's existing theme choice
      // silently vanishes on upgrade. `bodyTheme` and `icon` are both
      // genuinely new — no prior value to migrate, default them fresh.
      const isValidThemeRef = (t: unknown): t is { kind: string } => !!t && typeof t === "object" && typeof (t as { kind?: unknown }).kind === "string";
      if (!isValidThemeRef(e.headerTheme)) {
        e.headerTheme = isValidThemeRef(e.theme) ? e.theme : { ...NO_THEME };
      }
      if (!isValidThemeRef(e.bodyTheme)) e.bodyTheme = { ...NO_THEME };
      // Icon v2 migration: v1 stored `icon` as a bare preset-name string
      // (or null). Wrap an existing string into the new IconRef shape
      // rather than resetting it to none, so nobody's existing icon
      // choice silently vanishes on upgrade — same reasoning as the
      // headerTheme migration just above. Anything already in the new
      // {kind, ...} shape (or genuinely absent) is left as-is / defaulted
      // to null.
      if (typeof e.icon === "string") {
        e.icon = { kind: "preset", name: e.icon };
      } else if (!e.icon || typeof e.icon !== "object" || (e.icon.kind !== "preset" && e.icon.kind !== "custom")) {
        e.icon = null;
      }
      // Lock fields are newest — same migration-default treatment.
      // encrypted already existed (always defaulted false already, see
      // above); an entry saved before Lock existed won't have these
      // three at all.
      if (e.lockKeyMode !== "app" && e.lockKeyMode !== "custom") e.lockKeyMode = null;
      if (typeof e.lockedPayload !== "string") e.lockedPayload = null;
      if (typeof e.lockedKeyFile !== "string") e.lockedKeyFile = null;
      // Pages: notes only. Missing entirely on any note saved before
      // this existed — defaults to "just the one page" (empty array),
      // which is exactly what those notes already are.
      if (e.type === "regular" && !Array.isArray(e.pages)) e.pages = [];
      // Page rename: newer still than pages itself — any note saved
      // before renaming existed (including ones that already have a
      // pages array) won't have page1Name at all, and existing pages
      // inside that array won't have a `name` field either. Both
      // default to null (auto-numbered), same migration pattern as
      // everything else in this function.
      if (e.type === "regular") {
        if (typeof e.page1Name !== "string") e.page1Name = null;
        for (const p of e.pages) {
          if (typeof p.name !== "string") p.name = null;
        }
      }
      valid.push(e);
    }
    return valid;
  } catch (err) {
    console.error("storage: failed to load entries, treating as empty:", err);
    return [];
  }
}

function saveEntries(entries: Entry[]) {
  if (typeof localStorage === "undefined") return;
  localStorage.setItem(ENTRIES_KEY, JSON.stringify(entries));
}

export function getEntry(id: string): Entry | undefined {
  return loadEntries().find((e) => e.id === id);
}

export function upsertEntry(entry: Entry) {
  const entries = loadEntries();
  const i = entries.findIndex((e) => e.id === entry.id);
  entry.lastModified = new Date().toISOString();
  if (i === -1) entries.push(entry);
  else entries[i] = entry;
  saveEntries(entries);
}

export function deleteEntry(id: string) {
  saveEntries(loadEntries().filter((e) => e.id !== id));
}

export function createNote(): Note {
  return {
    id: generateId(),
    type: "regular",
    title: "",
    // Not truly empty — a single empty <div> — so the very first line
    // is structurally consistent with every subsequent Enter-created
    // line (also a <div>). Matters for the ruled-lines feature: each
    // line's rule attaches to its own <div>'s border-bottom, and
    // without this the first line would be the one exception with
    // nothing to attach a rule to. See NoteContent.svelte.
    content: "<div><br></div>",
    pages: [],
    page1Name: null,
    tags: [],
    lastModified: new Date().toISOString(),
    isBookmarked: false,
    encrypted: false,
    struck: false,
    isPinned: false,
    headerTheme: { ...NO_THEME },
    bodyTheme: { ...NO_THEME },
    icon: null,
    lockKeyMode: null,
    lockedPayload: null,
    lockedKeyFile: null,
  };
}

export function createTodo(): Todo {
  return {
    id: generateId(),
    type: "todo",
    title: "",
    tags: [],
    lastModified: new Date().toISOString(),
    isBookmarked: false,
    encrypted: false,
    struck: false,
    isPinned: false,
    headerTheme: { ...NO_THEME },
    bodyTheme: { ...NO_THEME },
    icon: null,
    lockKeyMode: null,
    lockedPayload: null,
    lockedKeyFile: null,
    categories: ["Steps"],
    steps: [],
    annotations: [],
  };
}

export function createBoard(): Board {
  return {
    id: generateId(),
    type: "board",
    title: "",
    tags: [],
    lastModified: new Date().toISOString(),
    isBookmarked: false,
    encrypted: false,
    struck: false,
    isPinned: false,
    headerTheme: { ...NO_THEME },
    bodyTheme: { ...NO_THEME },
    icon: null,
    lockKeyMode: null,
    lockedPayload: null,
    lockedKeyFile: null,
    nodes: [],
    edges: [],
    viewport: null,
  };
}

// Known-tag registry — mirrors mdix_files/schema/tags.mdix's
// notes:: / todos:: split, now with a third boards:: scope.
interface KnownTags {
  notes: string[];
  todos: string[];
  boards: string[];
}

export type TagScope = keyof KnownTags;

export function loadKnownTags(): KnownTags {
  if (typeof localStorage === "undefined") return { notes: [], todos: [], boards: [] };
  try {
    const raw = localStorage.getItem(TAGS_KEY);
    // boards:: is newer than the other two, so anything saved before
    // it existed parses back with that key missing entirely — default
    // it rather than letting every board-tag read hit undefined.
    const parsed = raw ? (JSON.parse(raw) as Partial<KnownTags>) : {};
    return { notes: parsed.notes ?? [], todos: parsed.todos ?? [], boards: parsed.boards ?? [] };
  } catch {
    return { notes: [], todos: [], boards: [] };
  }
}

export function addKnownTag(kind: TagScope, tag: string) {
  if (typeof localStorage === "undefined") return;
  const known = loadKnownTags();
  if (!known[kind].includes(tag)) {
    known[kind].push(tag);
    localStorage.setItem(TAGS_KEY, JSON.stringify(known));
  }
}

export function removeKnownTag(kind: TagScope, tag: string) {
  if (typeof localStorage === "undefined") return;
  const known = loadKnownTags();
  known[kind] = known[kind].filter((t) => t !== tag);
  localStorage.setItem(TAGS_KEY, JSON.stringify(known));
}

// Custom (user-uploaded) theme registry — mirrors custom-themes.mdix's
// custom_theme(id, data, width, height, createdAt) exactly. Kept as its
// own top-level record the same way the schema does: an upload can be
// applied to more than one note, so it's stored once and referenced by
// id (ThemeRef.customThemeId) rather than duplicated onto every entry
// that uses it.
export function loadCustomThemes(): CustomTheme[] {
  if (typeof localStorage === "undefined") return [];
  try {
    const raw = localStorage.getItem(CUSTOM_THEMES_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch (err) {
    console.error("storage: failed to load custom themes, treating as empty:", err);
    return [];
  }
}

function saveCustomThemes(themes: CustomTheme[]) {
  if (typeof localStorage === "undefined") return;
  localStorage.setItem(CUSTOM_THEMES_KEY, JSON.stringify(themes));
}

export function deleteCustomTheme(id: string) {
  saveCustomThemes(loadCustomThemes().filter((t) => t.id !== id));
}

// Longest edge a stored theme image is allowed to be. This is a card/
// editor background, never viewed full-screen at native resolution, so
// there's no reason to keep a multi-megabyte original around — every
// uploaded photo gets downscaled to this before it ever touches
// localStorage. Real number, not the schema file's 1080x1920 placeholder
// (that was explicitly "not a recommendation" — this is the actual
// application decision it said still needed making).
const MAX_THEME_EDGE_PX = 720;
const THEME_JPEG_QUALITY = 0.82;

// Browser-only (Image/canvas) — never called during app boot or in the
// smoke test, only from a user-triggered file-input change in
// ThemePicker.svelte, so it's fine for this to have no jsdom-compatible
// path. NOT verified against a real decoded image in this sandbox (no
// real canvas/Image implementation here) — needs real on-device
// confirmation that an actual photo from the device gallery downscales
// and previews correctly.
export function storeCustomThemeImage(file: File): Promise<CustomTheme> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error("Couldn't read that file."));
    reader.onload = () => {
      const img = new Image();
      img.onerror = () => reject(new Error("That doesn't look like a valid image."));
      img.onload = () => {
        const scale = Math.min(1, MAX_THEME_EDGE_PX / Math.max(img.width, img.height));
        const width = Math.max(1, Math.round(img.width * scale));
        const height = Math.max(1, Math.round(img.height * scale));
        const canvas = document.createElement("canvas");
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext("2d");
        if (!ctx) {
          reject(new Error("Couldn't process that image on this device."));
          return;
        }
        ctx.drawImage(img, 0, 0, width, height);
        // Contrast text color, computed once here rather than on every
        // render — see CustomTheme.textColor's comment for why it can't
        // be done lazily in resolveTheme instead (image decode is
        // inherently async; resolveTheme is called from synchronous
        // $derived expressions all over the app). The canvas above
        // already has the fully-decoded, already-downscaled image drawn
        // into it for the JPEG re-encode step, so colorthief reads
        // directly off THAT — no second decode, no extra cost. Wrapped
        // in try/catch because canvas pixel reads can fail on some
        // browser/security configurations; if it does, textColor stays
        // undefined and resolveTheme's own fallback ("#ffffff") takes
        // over, matching this image's pre-existing always-light-text
        // behavior rather than the upload failing outright over a
        // cosmetic-only feature.
        let textColor: string | undefined;
        try {
          textColor = getColorSync(canvas)?.textColor;
        } catch (err) {
          console.error("storeCustomThemeImage: colorthief sampling failed, falling back to default text color:", err);
        }
        const theme: CustomTheme = {
          id: generateId(),
          data: canvas.toDataURL("image/jpeg", THEME_JPEG_QUALITY),
          width,
          height,
          createdAt: new Date().toISOString(),
          textColor,
        };
        const themes = loadCustomThemes();
        themes.push(theme);
        saveCustomThemes(themes);
        resolve(theme);
      };
      img.src = reader.result as string;
    };
    reader.readAsDataURL(file);
  });
}

// Custom (user-uploaded) icon registry — same "own top-level record,
// referenced by id" shape as loadCustomThemes above, for the same
// reason: one upload can be used as more than one note/todo's icon
// badge, so it's stored once (IconRef.customIconId) rather than
// duplicated onto every entry that uses it.
export function loadCustomIcons(): CustomIcon[] {
  if (typeof localStorage === "undefined") return [];
  try {
    const raw = localStorage.getItem(CUSTOM_ICONS_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch (err) {
    console.error("storage: failed to load custom icons, treating as empty:", err);
    return [];
  }
}

function saveCustomIcons(icons: CustomIcon[]) {
  if (typeof localStorage === "undefined") return;
  localStorage.setItem(CUSTOM_ICONS_KEY, JSON.stringify(icons));
}

export function deleteCustomIcon(id: string) {
  saveCustomIcons(loadCustomIcons().filter((i) => i.id !== id));
}

// Longest edge a stored icon image is allowed to be — this is a tiny
// badge (NoteCard/the todo row render it at 22px — see NoteCard.svelte's
// .icon-badge), never viewed any larger, so it needs nowhere near a
// theme image's 720px (MAX_THEME_EDGE_PX above). 128px covers even a
// 3x-density display's real pixel size with headroom to spare.
//
// MAX_ICON_SOURCE_BYTES rejects the SOURCE file outright above this size
// rather than attempting to decode it at all — not because a bigger
// photo couldn't be downscaled just as easily as a theme image is, but
// because there's no reason a tiny badge upload should ever need to
// decode a genuinely huge file; this exists to catch an accidental
// multi-hundred-MB selection (or a non-image file with an image-sounding
// name) before spending any real work on it. Anything under this limit
// is always accepted and simply scaled down to size — never rejected
// for being "too big" once it's through this one gate.
const MAX_ICON_EDGE_PX = 128;
const MAX_ICON_SOURCE_BYTES = 8 * 1024 * 1024;

// Same browser-only/not-verified-against-a-real-decoded-image caveat as
// storeCustomThemeImage above. Two real differences from that function,
// both deliberate: output is PNG, not JPEG — an icon badge is small
// enough that file size barely matters, and it may well have a
// transparent background (a logo, a sticker) worth actually preserving.
// And the source is center-cropped to a square before downscaling —
// every icon preset glyph, and every swatch in every picker this app
// already has, is circular, so a non-square upload gets cropped
// consistently with everything around it instead of squashed to fit.
export function storeCustomIconImage(file: File): Promise<CustomIcon> {
  return new Promise((resolve, reject) => {
    if (file.size > MAX_ICON_SOURCE_BYTES) {
      const limitMb = MAX_ICON_SOURCE_BYTES / (1024 * 1024);
      reject(new Error(`That file's too large (${Math.round(file.size / (1024 * 1024))}MB) — try something under ${limitMb}MB.`));
      return;
    }
    const reader = new FileReader();
    reader.onerror = () => reject(new Error("Couldn't read that file."));
    reader.onload = () => {
      const img = new Image();
      img.onerror = () => reject(new Error("That doesn't look like a valid image."));
      img.onload = () => {
        const srcEdge = Math.min(img.width, img.height);
        const srcX = (img.width - srcEdge) / 2;
        const srcY = (img.height - srcEdge) / 2;
        const outEdge = Math.min(MAX_ICON_EDGE_PX, srcEdge);
        const canvas = document.createElement("canvas");
        canvas.width = outEdge;
        canvas.height = outEdge;
        const ctx = canvas.getContext("2d");
        if (!ctx) {
          reject(new Error("Couldn't process that image on this device."));
          return;
        }
        ctx.drawImage(img, srcX, srcY, srcEdge, srcEdge, 0, 0, outEdge, outEdge);
        const icon: CustomIcon = {
          id: generateId(),
          data: canvas.toDataURL("image/png"),
          createdAt: new Date().toISOString(),
        };
        const icons = loadCustomIcons();
        icons.push(icon);
        saveCustomIcons(icons);
        resolve(icon);
      };
      img.src = reader.result as string;
    };
    reader.readAsDataURL(file);
  });
}
