<script lang="ts">
  import Sheet from "$lib/components/ui/Sheet/Sheet.svelte";
  import ConfirmDialog from "$lib/components/ui/ConfirmDialog/ConfirmDialog.svelte";
  import Spinner from "$lib/components/ui/Spinner/Spinner.svelte";
  import { breadcrumb } from "$lib/debug/log.svelte";
  import { pushToast } from "$lib/stores/toast.svelte";

  let {
    itemLabel,
    struck = false,
    pinned = false,
    encrypted = false,
    onDelete,
    onDownload,
    onToggleStrikethrough,
    onTogglePin,
    onToggleLock,
    onOpenTags,
    busy = false,
  }: {
    // "note" or "todo" — copy only ("Delete note?").
    itemLabel: string;
    struck?: boolean;
    pinned?: boolean;
    encrypted?: boolean;
    onDelete: () => void;
    onDownload: () => void;
    onToggleStrikethrough: () => void;
    onTogglePin: () => void;
    onToggleLock: () => void;
    // Hidden while encrypted (see the Tags row below) — a locked
    // entry's real tags live inside its encrypted payload, not on the
    // visible record, so there's nothing meaningful to edit here until
    // it's unlocked.
    onOpenTags: () => void;
    // True while THIS specific entry's lock_payload/unlock_payload
    // invoke() is in flight (Argon2id is deliberately slow — real
    // wall-clock time, not instant). The caller (NoteCard.svelte / the
    // todo row in +page.svelte) owns this state, since it's the one
    // that knows when the await actually resolves; this component just
    // renders whatever it's told. Swaps the ⋮ trigger for a spinner and
    // disables it, rather than adding a busy row inside the menu itself
    // — the menu's already closed by the time the slow part starts
    // (pick() closes it immediately on tap), so the trigger is the only
    // thing still on-screen to show it on.
    busy?: boolean;
  } = $props();

  let open = $state(false);
  let showDeleteConfirm = $state(false);

  // Sheet, not a positioned dropdown — deliberately, same reasoning as
  // Export's menu: this trigger can end up anywhere in a scrolling grid,
  // including right at the bottom edge of the viewport, which is
  // exactly the position a dropdown can't reliably escape (see
  // DropdownMenu.svelte's own header comment). A bottom sheet has
  // nowhere to clip to.
  // Card's own long-press-to-select system (longPress.ts) fires
  // navigation from pointerup, not click — createLongPressHandlers'
  // onpointerup() calls opts.onTap() directly, independent of whatever
  // the browser's click event does. Stopping propagation on pointerdown
  // alone (which only blocks the long-press TIMER from starting) isn't
  // enough: the tap-navigation path fires from pointerup regardless of
  // whether a timer was running. Both need stopping, on this trigger and
  // on the Sheet/dialog beneath it never mattering since those aren't
  // inside the card's DOM subtree.
  function stop(e: Event) {
    e.stopPropagation();
  }

  function openMenu(e: Event) {
    e.stopPropagation();
    if (busy) return;
    breadcrumb(`card overflow: opened (${itemLabel})`);
    open = true;
  }

  function pick(action: () => void, label: string) {
    breadcrumb(`card overflow: ${label} tapped (${itemLabel})`);
    open = false;
    action();
  }

  // BUGFIX (data-safety): Delete had no gate at all before this — a
  // locked entry could be destroyed without ever proving you know its
  // password, which defeats the entire point of locking it in the
  // first place. Download stays allowed while locked (a locked entry's
  // visible content is already cleared, so there's nothing to leak either
  // way — a past, deliberate decision, unaffected by this change);
  // Delete is different because it's irreversible and needs no content
  // exposure to do damage, so it gets its own explicit block instead of
  // inheriting Download's reasoning.
  function handleDeleteTapped() {
    breadcrumb(`card overflow: delete tapped (${itemLabel}, encrypted=${encrypted})`);
    open = false;
    if (encrypted) {
      pushToast({ title: "Unlock first", description: `Unlock this ${itemLabel} before deleting it.`, variant: "destructive" });
      return;
    }
    showDeleteConfirm = true;
  }
</script>

<!--
  Sheet and ConfirmDialog aren't portaled (confirmed by reading
  Sheet.svelte — no document.body/portal mechanism, it's positioned via
  plain CSS position:fixed while staying a DOM descendant of wherever
  it's declared). That means every button inside them here is still,
  structurally, a descendant of the card — same pointerup-bubbles-to-
  onTap exposure as the trigger itself, not just the trigger. One
  stop-propagation boundary around the whole subtree instead of
  per-button handlers scattered through the menu markup below.
  display:contents so this wrapper doesn't affect layout at all — Sheet
  and the trigger position themselves exactly as before.
-->
<div class="overflow-menu-root" role="presentation" onclick={stop} onpointerdown={stop} onpointerup={stop} onpointermove={stop} onpointercancel={stop}>
  <button
    class="trigger"
    onclick={openMenu}
    disabled={busy}
    aria-label={busy ? "Working…" : "More options"}
  >
    {#if busy}
      <Spinner class="trigger-spinner" />
    {:else}
      <svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor">
        <circle cx="12" cy="5" r="1.8" />
        <circle cx="12" cy="12" r="1.8" />
        <circle cx="12" cy="19" r="1.8" />
      </svg>
    {/if}
  </button>

  <Sheet bind:open side="bottom" title="Options">
    <div class="menu-list">
      <button class="menu-item" onclick={() => pick(onTogglePin, "pin")}>
        <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2">
          <path d="M12 17v5" />
          <path d="M9 3h6l-1 6 3 3v2H7v-2l3-3-1-6z" />
        </svg>
        <span>{pinned ? "Unpin" : "Pin to top"}</span>
      </button>
      {#if !encrypted}
        <button class="menu-item" onclick={() => pick(onOpenTags, "tags")}>
          <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M20.59 13.41 11 3.83A2 2 0 0 0 9.59 3.24L3 3v6.59a2 2 0 0 0 .59 1.41l9.59 9.59a2 2 0 0 0 2.82 0l4.59-4.59a2 2 0 0 0 0-2.82z" />
            <circle cx="7.5" cy="7.5" r="1" fill="currentColor" />
          </svg>
          <span>Tags</span>
        </button>
      {/if}
      <button class="menu-item" onclick={() => pick(onToggleStrikethrough, "strikethrough")}>
        <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2">
          <line x1="4" y1="12" x2="20" y2="12" />
          <path d="M16 6.5c-.9-1-2.3-1.5-4-1.5-2.5 0-4.5 1.2-4.5 3.2 0 1.3.9 2.1 2.2 2.6" />
          <path d="M9 16.5c.7 1.4 2.3 2 4.2 2 2.5 0 4.3-1.1 4.3-3" />
        </svg>
        <span>{struck ? "Remove strikethrough" : "Strikethrough"}</span>
      </button>
      <button class="menu-item" onclick={() => pick(onToggleLock, "lock")}>
        {#if encrypted}
          <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2">
            <rect x="3" y="11" width="18" height="11" rx="2" /><path d="M7 11V7a5 5 0 0 1 9.9-1" />
          </svg>
        {:else}
          <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2">
            <rect x="3" y="11" width="18" height="11" rx="2" /><path d="M7 11V7a5 5 0 0 1 10 0v4" />
          </svg>
        {/if}
        <span>{encrypted ? "Unlock" : "Lock"}</span>
      </button>
      <button class="menu-item" onclick={() => pick(onDownload, "download")}>
        <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2">
          <path d="M12 3v12" /><path d="m7 10 5 5 5-5" /><path d="M5 21h14" />
        </svg>
        <span>Download</span>
      </button>
      <button
        class="menu-item danger"
        onclick={handleDeleteTapped}
      >
        <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2">
          <polyline points="3 6 5 6 21 6" />
          <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" />
        </svg>
        <span>Delete</span>
      </button>
    </div>
  </Sheet>

  <ConfirmDialog
    bind:open={showDeleteConfirm}
    title="Delete this {itemLabel}?"
    description="This can't be undone."
    confirmLabel="Delete"
    danger
    onconfirm={() => {
      breadcrumb(`card overflow: delete confirmed (${itemLabel})`);
      onDelete();
    }}
  />
</div>

<style>
  .overflow-menu-root {
    display: contents;
  }
  .trigger {
    width: 28px;
    height: 28px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: transparent;
    border: none;
    border-radius: var(--radius-sm);
    /* Same fallback pattern as Button.svelte's .btn-ghost — falls back
       to the original fixed value everywhere this menu is used without
       a themed ancestor (NoteCard.svelte / the todo row set
       --theme-text-lo via getImageTextColorVars when their header theme
       is an image). --text-faint's normal light/dark-mode value has no
       relationship to what's actually behind an image-themed card. */
    color: var(--theme-text-lo, var(--text-faint));
    cursor: pointer;
    flex-shrink: 0;
  }
  .trigger:hover {
    background: var(--surface-raised);
    color: var(--text-hi);
  }
  .trigger:disabled {
    cursor: default;
  }
  /* Spinner.svelte is 20px by default — sized down slightly here so it
     doesn't visually outgrow the 16px ⋮ icon it's replacing. :global +
     !important because Svelte's own scoped-style specificity on
     Spinner's internal .spinner rule otherwise wins over a plain class
     selector from this component's stylesheet. */
  :global(.trigger-spinner) {
    width: 16px !important;
    height: 16px !important;
  }
  .menu-list {
    display: flex;
    flex-direction: column;
    gap: var(--space-1);
  }
  .menu-item {
    display: flex;
    align-items: center;
    gap: var(--space-3);
    width: 100%;
    text-align: left;
    padding: var(--space-3);
    background: transparent;
    border: none;
    border-radius: var(--radius-sm);
    color: var(--text-hi);
    font-size: 14px;
    cursor: pointer;
  }
  .menu-item:hover {
    background: var(--surface-raised);
  }
  .menu-item svg {
    flex-shrink: 0;
  }
  .menu-item.danger {
    color: var(--danger);
  }
</style>
