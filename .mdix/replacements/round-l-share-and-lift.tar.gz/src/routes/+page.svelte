<script lang="ts">
  import { goto } from "$app/navigation";
  import AppHeader from "$lib/components/layout/AppHeader/AppHeader.svelte";
  import NoteCard from "$lib/components/notes/NoteCard/NoteCard.svelte";
  import AiNoteCreator from "$lib/components/notes/AiNoteCreator/AiNoteCreator.svelte";
  import Button from "$lib/components/ui/Button/Button.svelte";
  import ConfirmDialog from "$lib/components/ui/ConfirmDialog/ConfirmDialog.svelte";
  import SelectionActionBar from "$lib/components/shared/SelectionActionBar/SelectionActionBar.svelte";
  import CardOverflowMenu from "$lib/components/shared/CardOverflowMenu/CardOverflowMenu.svelte";
  import LockBadge from "$lib/components/shared/LockBadge/LockBadge.svelte";
  import ReminderBadge from "$lib/components/shared/ReminderBadge/ReminderBadge.svelte";
  import { reminderDueAt } from "$lib/utils/reminderRepeat";
  import TagsPopup from "$lib/components/shared/TagsPopup/TagsPopup.svelte";
  import FoldersView from "$lib/components/folders/FoldersView.svelte";
  import FolderPickerHost from "$lib/components/folders/FolderPickerHost.svelte";
  import { folderState, requestMove } from "$lib/stores/folders.svelte";
  import { effectiveTags } from "$lib/utils/folders";
  import { entries, saveEntry, removeEntry, toggleBookmark, toggleStrikethrough, togglePinned } from "$lib/stores/entries.svelte";
  import type { Note, Todo, Board, Entry } from "$lib/types/entry";
  import { noteTags, todoTags, boardTags, registerTag, unregisterTag } from "$lib/stores/tags.svelte";
  import { isSystemTag } from "$lib/utils/systemTags";
  import { createNote, type TagScope } from "$lib/storage";
  import { stripHtml, plainTextToHtml } from "$lib/utils/richText";
  import { createLongPressHandlers } from "$lib/utils/longPress";
  import { createSwipeHandlers } from "$lib/utils/swipe";
  import { progressLabel, countDone } from "$lib/utils/todoEdits";
  import { mergeNotes, mergeTodos, buildExportFiles, buildEncryptedBackupFile, downloadFiles, type ExportFormat } from "$lib/utils/selectionActions";
  import { shareText, shareOutcomeToast, entriesToShareText, shareEntryFromMenu } from "$lib/utils/share";
  import { copyEntryContent, copyEntriesContent } from "$lib/utils/copyText";
  import { pushToast } from "$lib/stores/toast.svelte";
  import { breadcrumb } from "$lib/debug/log.svelte";
  import { resolveTheme, hexToRgba, resolveIcon, getImageTextColorVars } from "$lib/utils/themePalette";
  import { customThemes } from "$lib/stores/customThemes.svelte";
  import { customIcons } from "$lib/stores/customIcons.svelte";
  import { appBodyTheme, loadLastActiveView, setLastActiveView, listViewMode, setListViewMode, type ActiveView } from "$lib/stores/settings.svelte";
  import { lockEntry, unlockEntry } from "$lib/utils/lockFlow";

  // BUGFIX: this used to always start on "notes" — since navigating to
  // note/[id] or todo/[id] and back fully unmounts/remounts this route,
  // that meant leaving a todo (or a note) always landed back on the
  // Notes tab regardless of which one you'd actually been viewing. Seeds
  // from whatever was last shown instead — see settings.svelte.ts's
  // loadLastActiveView/setLastActiveView.
  let activeView = $state<ActiveView>(loadLastActiveView());
  let selectedTag = $state<string | null>(null);
  let searchQuery = $state("");
  let sortBy = $state<"recent" | "alphabetical" | "bookmarked">("recent");

  // Long-press multi-select — see NoteCard.svelte / SelectionActionBar.svelte.
  // Scoped to whichever list (notes or todos) is currently showing:
  // switching tabs while items are selected would leave the action bar
  // showing a selection that's no longer even visible, so it clears.
  let selectMode = $state(false);
  let selectedIds = $state<Set<string>>(new Set());
  // Per-item, not a single flag — the list can hold many todos, and
  // only the one actually mid-invoke() should show a spinner/block taps.
  // NoteCard tracks this itself internally (it owns exactly one item);
  // there's no dedicated Todo component to own an equivalent, so it
  // lives here instead. Reassigned (not mutated in place) each time so
  // Svelte's reactivity actually notices the Set changed — `.add()`/
  // `.delete()` alone on a $state Set don't trigger a re-render.
  let lockBusyIds = $state<Set<string>>(new Set());
  let showMergeConfirm = $state(false);
  let pendingMerge = $state<{ merged: Entry; sourceIds: string[] } | null>(null);

  // BUGFIX (Trash, round 25): all three excluded trashed entries here —
  // without this, "deleting" a note/todo/board would move it to Trash
  // (see entries.svelte.ts's removeEntry) but it'd keep showing up right
  // here in the normal list, since this file's own filters never knew
  // Trash existed.
  const notes = $derived(entries.filter((e): e is Note => e.type === "regular" && !e.deletedAt));
  const todos = $derived(entries.filter((e): e is Todo => e.type === "todo" && !e.deletedAt));
  const boards = $derived(entries.filter((e): e is Board => e.type === "board" && !e.deletedAt));

  // Round 33: list (one card per row) or grid (two compact cards per row).
  // One setting for all three tabs.
  const isGrid = $derived(listViewMode.value === "grid");
  const displayItems = $derived(activeView === "notes" ? notes : activeView === "todos" ? todos : boards);
  const tagList = $derived(activeView === "notes" ? noteTags : activeView === "todos" ? todoTags : boardTags);
  // Singular noun for this tab, used by the New/Create buttons, the
  // empty state and the selection bar — one place rather than the same
  // ternary repeated at each of those call sites.
  const itemNoun = $derived(activeView === "notes" ? "Note" : activeView === "todos" ? "Todo" : "Board");
  const newRoute = $derived(activeView === "notes" ? "/note/new" : activeView === "todos" ? "/todo/new" : "/board/new");

  const filteredItems = $derived(
    // Round 47: a tag filter matches an entry's EFFECTIVE tags - its own plus those of the folders it sits in.
    (selectedTag ? displayItems.filter((i) => effectiveTags(folderState.view, i.id).all.includes(selectedTag!)) : displayItems).filter((i) => {
      const q = searchQuery.toLowerCase();
      if (!q) return true;
      // note.content is HTML now (see NoteContent.svelte) — strip tags
      // before searching, or e.g. searching "strong" would false-match
      // every bolded note.
      const haystack = i.title + " " + (i.type === "regular" ? stripHtml(i.content) : "");
      return haystack.toLowerCase().includes(q);
    })
  );

  // Round 47: tags an entry carries only because of the folders above it (shown quieter on its card),
  // and the ones among them the tag filter row doesn't already offer.
  function inheritedOf(id: string): string[] {
    return effectiveTags(folderState.view, id).inherited.map((t) => t.tag);
  }
  const inheritedChipTags = $derived.by(() => {
    const known = new Set(tagList);
    const out: string[] = [];
    for (const i of displayItems) {
      for (const tag of inheritedOf(i.id)) if (!known.has(tag) && !out.includes(tag)) out.push(tag);
    }
    return out;
  });

  const sortedItems = $derived.by(() => {
    const base = [...filteredItems].sort((a, b) => {
      if (sortBy === "recent") return new Date(b.lastModified).getTime() - new Date(a.lastModified).getTime();
      if (sortBy === "alphabetical") return a.title.localeCompare(b.title);
      return (b.isBookmarked ? 1 : 0) - (a.isBookmarked ? 1 : 0);
    });
    // Pin floats an item to the top of the browse list, but only while
    // actually browsing — the moment there's a search query the person
    // is looking for something specific, and pin order re-sorting the
    // matches around would work against them, not for them. Tag
    // filtering doesn't count as "searching" here, only the text box.
    if (searchQuery.trim()) return base;
    const pinned = base.filter((i) => i.isPinned);
    const rest = base.filter((i) => !i.isPinned);
    return [...pinned, ...rest];
  });

  // Landing-page BODY theme (Settings) — everything on this page except
  // the top app-bar. CORRECTED mapping, confirmed against an annotated
  // screenshot: "Header" is specifically AppHeader.svelte's own <header>
  // (hamburger, "MidNote" wordmark, sync icon) — that component now
  // resolves appHeaderTheme itself (see its own header comment), so
  // there's nothing to compute for it here. "Body" is genuinely
  // everything else, including the Notes/Todos tab row below
  // AppHeader — .view-tabs deliberately gets NO wash of its own below;
  // it's a transparent child sitting inside this same <main>, so
  // .page's background-attachment:fixed image/color already shows
  // straight through it, which is exactly the desired look.
  const appBodyResolved = $derived(resolveTheme(appBodyTheme.value, customThemes));
  const pageBodyStyle = $derived(
    appBodyResolved.kind === "color"
      ? `background: ${hexToRgba(appBodyResolved.color, 0.16)};`
      : appBodyResolved.kind === "image"
        ? // BUGFIX: text/UI sitting directly on the body area (the Tags
          // section's heading and "Add Tag" button specifically — see
          // .tags-header/.btn-outline overrides below) had no contrast
          // handling at all before this; getImageTextColorVars gives
          // every descendant the right --theme-text-*/--theme-tag-*
          // variables to use, picked per-image via colorthief rather
          // than assumed.
          `background-image: url(${appBodyResolved.dataUrl}); background-size: cover; background-attachment: fixed; ${getImageTextColorVars(appBodyResolved.textColor)}`
        : "",
  );
  // .view-tabs has its own deliberate --surface background in its base
  // CSS (a shade lighter than .page's --bg, by design, in the
  // untheened default look) — that's unrelated to theming and stays
  // untouched when no body theme is set. Only override it to transparent
  // when a body theme actually IS active, so .page's background (image
  // or color, whichever was picked) shows straight through instead of
  // this row cutting a solid-colored gap out of it.
  const viewTabsStyle = $derived(appBodyResolved.kind !== "none" ? "background: transparent;" : "");

  // Named generically (not "todoItemStyle") because it now also paints
  // the board list card — it only ever touched `.headerTheme`, which
  // Todo and Board both carry unchanged via EntryRef, so nothing about
  // the actual theme-resolution logic needed to change, just who's
  // allowed to call it.
  function listCardStyle(entry: Todo | Board): string {
    const resolved = resolveTheme(entry.headerTheme, customThemes);
    if (resolved.kind === "color") return `border-left: 4px solid ${resolved.color}; background: ${hexToRgba(resolved.color, 0.08)};`;
    // BUGFIX — same as NoteCard.svelte's identical fix: text used to be
    // forced to a fixed white hierarchy unconditionally for ANY image
    // theme; now it's the earned, per-image textColor from colorthief
    // (computed once at upload — see CustomTheme.textColor).
    if (resolved.kind === "image")
      return `background-image: url(${resolved.dataUrl}); background-size: cover; background-position: center; ${getImageTextColorVars(resolved.textColor)}`;
    return "";
  }

  const selectedEntries = $derived(entries.filter((e) => selectedIds.has(e.id)));
  const selectionHasEncrypted = $derived(selectedEntries.some((e) => e.encrypted));
  // Merging concatenates content/steps directly (see selectionActions.ts)
  // — a locked entry's real content lives inside its encrypted payload,
  // not in those fields (they're cleared while locked), so merging one
  // in would silently produce a merged item missing that entry's actual
  // content entirely, and then — since a merge normally offers to
  // delete its sources afterward — risk the original locked content
  // being deleted with nothing real ever having made it into the
  // result. Blocked outright rather than merging "around" it.
  // Boards excluded: merging two boards would mean combining their
  // nodes/edges onto one canvas, a real feature but not one that
  // exists yet — mergeNotes/mergeTodos below have no board equivalent,
  // and the branch that calls them assumes exactly two possibilities.
  const canMerge = $derived(selectedIds.size >= 2 && !selectionHasEncrypted && activeView !== "boards");

  function switchView(view: ActiveView) {
    activeView = view;
    setLastActiveView(view);
    selectedTag = null;
    sortBy = "recent";
    exitSelectMode();
  }

  // Swipe left/right between Notes/Todos/Boards on the landing page.
  // Fixed order matching the tabs' own left-to-right positions — swipe
  // left moves forward (Notes -> Todos -> Boards), same direction
  // convention as swiping through a photo gallery. Clamped at the ends
  // rather than wrapping Boards back around to Notes, which would be a
  // surprising jump with no visual cue it happened.
  const VIEW_ORDER: ActiveView[] = ["notes", "todos", "boards", "folders"];
  function switchToRelativeView(direction: 1 | -1) {
    // Selection is per-tab (switchView above already clears it), so a
    // swipe mid-selection is allowed to go through — same as tapping a
    // tab button directly already does — rather than silently eating
    // the gesture, which would feel like the swipe just didn't work.
    const idx = VIEW_ORDER.indexOf(activeView);
    const nextIdx = idx + direction;
    if (nextIdx < 0 || nextIdx >= VIEW_ORDER.length) return;
    switchView(VIEW_ORDER[nextIdx]);
  }
  // Created once, not per-render: the callbacks close over the reactive
  // `activeView` $state directly, so they always act on its current
  // value without needing to be recreated when it changes.
  const swipeAreaHandlers = createSwipeHandlers({
    onSwipeLeft: () => switchToRelativeView(1),
    onSwipeRight: () => switchToRelativeView(-1),
  });

  // BUGFIX: this used to unlock (permanently!) right here, before
  // navigating at all — confirmed as the actual cause of "opening a
  // locked note strips its lock for good and it's never re-locked."
  // The editor route's own body already gates on note.encrypted (the
  // locked-placeholder screen) and NoteEditorHeader/TodoHeader's own
  // delete icon already checks it too (that header renders
  // unconditionally, even when the body shows the placeholder) — so
  // navigating in doesn't expose anything or allow deleting a locked
  // entry regardless of what happens here. Real unlocking-to-view now
  // happens entirely inside the editor route via lockFlow.ts's
  // session-scoped unlockForSession()/relockSilently() pair (see that
  // route's onNavigate hook) — this function's only job is getting
  // there. NoteCard routes its own tap through this exact function via
  // its `onClick` prop; the inline todo row does the same.
  function handleClick(id: string) {
    const item = entries.find((i) => i.id === id);
    if (!item) return;
    goto(item.type === "todo" ? `/todo/${id}` : item.type === "board" ? `/board/${id}` : `/note/${id}`);
  }

  function handleAddTag() {
    const name = prompt("Enter tag name:");
    // These controls only exist on the Notes/Todos/Boards tabs (the Folders tab has its own).
    if (name && activeView !== "folders") registerTag(activeView, name);
  }

  // built-in tags (AI Generated, Example) have no × on the chip: they can't be removed from the list
  const isBuiltIn = (tag: string) => activeView !== "folders" && isSystemTag(tag, activeView);

  function handleRemoveTag(tag: string) {
    if (activeView !== "folders" && !isBuiltIn(tag)) unregisterTag(activeView, tag);
    if (selectedTag === tag) selectedTag = null;
  }

  function handleAiNoteCreated(note: { title: string; content: string; html: string }): string {
    const n = createNote();
    n.title = note.title;
    // note.content is stored as HTML (see NoteContent.svelte). The AI creator hands back BOTH: `html`, the answer turned
    // into the note's own formatting (bullets, bold; everything escaped, utils/aiNoteHtml.ts), and the plain text. If a
    // caller gives no html, the plain text is escaped rather than written in, or a "<" would be parsed as a tag.
    n.content = note.html || plainTextToHtml(note.content);
    n.tags = ["AI Generated"];
    saveEntry(n);
    registerTag("notes", "AI Generated");
    return n.id;
  }

  // --- Multi-select ---

  function enterSelectMode(id: string) {
    breadcrumb(`selection: entered select mode via long-press on ${id}`);
    selectMode = true;
    selectedIds = new Set([id]);
  }

  function toggleSelect(id: string) {
    const next = new Set(selectedIds);
    if (next.has(id)) next.delete(id);
    else next.add(id);
    selectedIds = next;
  }

  function exitSelectMode() {
    selectMode = false;
    selectedIds = new Set();
  }

  // BUGFIX (round 25): removeEntry is a soft delete now (Trash) — copy
  // updated on both toasts below to match; nothing else here changed.
  function handleDeleteSelected() {
    const count = selectedIds.size;
    selectedIds.forEach((id) => removeEntry(id));
    pushToast({ title: `${count} ${activeView === "notes" ? "note" : "todo"}${count === 1 ? "" : "s"} moved to Trash`, variant: "destructive" });
    exitSelectMode();
  }

  // Per-card ⋮ menu actions — outside multi-select entirely, one item
  // at a time. Shared between notes and todos (both are just Entry
  // here), matching the shared CardOverflowMenu component itself.
  function handleDeleteSingle(id: string) {
    const item = entries.find((e) => e.id === id);
    removeEntry(id);
    pushToast({ title: `${item?.type === "todo" ? "Todo" : "Note"} moved to Trash`, variant: "destructive" });
  }

  // BUGFIX: this is the "content is empty" report. An earlier round
  // routed the two EDITOR headers' Export buttons onto the encrypted
  // backup path when an entry is locked, but missed this one — the
  // list card's own overflow-menu Download, which is a separate call
  // site that went straight to the PLAINTEXT builder with no encrypted
  // check at all. A locked entry has its content/steps/nodes cleared
  // (lockFlow.ts's clearPlaintextFields), so what came out was a .txt
  // holding nothing but the title. Exactly the same shape of miss as
  // the earlier handleClick-vs-editor-unlock bug: a second copy of the
  // same decision living on the list page that didn't get migrated
  // with the first.
  async function handleDownloadSingle(id: string) {
    const item = entries.find((e) => e.id === id);
    if (!item) return;
    if (item.encrypted) {
      await downloadFiles([buildEncryptedBackupFile(item)]);
      pushToast({ title: "Encrypted backup downloaded", description: "Still locked — the file holds encrypted data, not readable content." });
      return;
    }
    await downloadFiles(buildExportFiles([item], "separate"));
    pushToast({ title: "Downloaded" });
  }

  // NoteCard's own onToggleLock passes the Note object it already has;
  // the inline todo/board rows (neither has a dedicated component of
  // its own) do the same with whichever Entry they have — either way
  // this just picks the right direction and hands off to lockFlow.ts,
  // which owns the actual dialogs/invoke calls/entry mutation.
  async function handleToggleLock(item: Entry) {
    // Same new-Set-reassignment pattern as toggleSelect above — Svelte 5
    // $state doesn't fire on in-place Set.add()/.delete(), only on
    // reassigning the binding itself.
    lockBusyIds = new Set(lockBusyIds).add(item.id);
    try {
      if (item.encrypted) await unlockEntry(item);
      else await lockEntry(item);
    } finally {
      const next = new Set(lockBusyIds);
      next.delete(item.id);
      lockBusyIds = next;
    }
  }

  // Tags popup for the TODO and BOARD inline rows specifically —
  // NoteCard handles its own equivalent internally (it already owns
  // `note` directly), but todo/board rows have no dedicated component
  // of their own, so this page tracks which one (if any) currently has
  // the popup open. Widened from Todo-only to Entry so a board row can
  // reuse the exact same mechanism rather than a second copy of it.
  // Kept as two separate pieces of state on purpose: tagsPopupOpen is
  // what TagsPopup actually bind:opens (so its own internal close —
  // tapping the scrim — correctly flows back here); tagsPopupFor just
  // tracks which entry it's for and is fine staying stale once closed,
  // same as this page's pendingMerge already does.
  let tagsPopupFor = $state<Entry | null>(null);
  let tagsPopupOpen = $state(false);
  // Which known-tag scope the currently-open popup should register
  // into/read from — "todos" or "boards" depending on tagsPopupFor's own
  // type, since KnownTags (storage.ts) keeps them separate per entry
  // type the same way the tabs themselves do.
  const tagsPopupScope = $derived<TagScope>(tagsPopupFor?.type === "board" ? "boards" : "todos");
  const tagsPopupAvailableTags = $derived(tagsPopupScope === "boards" ? boardTags : todoTags);
  function handleAddTagTo(item: Entry, tag: string) {
    item.tags = [...item.tags, tag];
    registerTag(tagsPopupScope, tag);
    saveEntry(item);
  }
  function handleRemoveTagFrom(item: Entry, tag: string) {
    item.tags = item.tags.filter((t) => t !== tag);
    saveEntry(item);
  }

  // Round 34: shares the selection as TEXT through the phone's share sheet
  // (utils/share.ts). Locked items are skipped — their content is cleared
  // while locked, so sharing them would send nothing — and the toast says
  // how many. If sharing is impossible here the old behaviour stays as the
  // fallback: download the files instead of leaving a dead end.
  async function handleSendSelected() {
    const { text, skippedLocked } = entriesToShareText(selectedEntries);
    if (!text) {
      pushToast({ title: "Nothing to share", description: "The selected items are locked. Unlock them first.", variant: "destructive" });
      return;
    }
    const title = selectedEntries.length === 1 ? selectedEntries[0].title || "MidNote" : `${selectedEntries.length} items from MidNote`;
    const result = await shareText(text, { title, log: breadcrumb });
    breadcrumb(`home: share ${selectedEntries.length} selected -> ${result} (${skippedLocked} locked skipped)`);
    if (result === "unsupported" || result === "toolarge") {
      await downloadFiles(buildExportFiles(selectedEntries, "separate"));
      pushToast({ title: result === "toolarge" ? "Too long to share as text" : "Sharing isn't available here", description: "Downloaded instead." });
      exitSelectMode();
      return;
    }
    const toast = shareOutcomeToast(result);
    if (toast) pushToast(toast);
    else if (skippedLocked > 0) {
      pushToast({ title: "Locked items skipped", description: `${skippedLocked} locked item${skippedLocked === 1 ? "" : "s"} weren't included.` });
    }
    if (result !== "cancelled") exitSelectMode();
  }

  // Round 44: "Copy content" on the multi-select bar — every selected item's text
  // on the clipboard, one after another (locked items skipped, the toast says how
  // many). Selection mode ends when something was copied.
  async function handleCopySelected() {
    const { toast, copied } = await copyEntriesContent(selectedEntries);
    breadcrumb(`home: copy content of ${selectedEntries.length} selected -> ${copied} copied`);
    pushToast(toast);
    if (copied > 0) exitSelectMode();
  }

  function handleMergeSelected() {
    if (selectionHasEncrypted) {
      pushToast({ title: "Can't merge a locked item", description: "Unlock it first, or deselect it to merge the rest.", variant: "destructive" });
      return;
    }
    if (!canMerge) return;
    breadcrumb(`selection: merging ${selectedIds.size} ${activeView}`);
    const sourceIds = [...selectedIds];
    if (activeView === "notes") {
      const merged = mergeNotes(selectedEntries as Note[]);
      pendingMerge = { merged, sourceIds };
    } else {
      const merged = mergeTodos(selectedEntries as Todo[]);
      pendingMerge = { merged, sourceIds };
    }
    saveEntry(pendingMerge.merged);
    showMergeConfirm = true;
  }

  function confirmDeleteMergeSources() {
    if (!pendingMerge) return;
    // removeEntry is a soft delete (Trash) — the originals are
    // recoverable there, not gone the moment this runs.
    pendingMerge.sourceIds.forEach((id) => removeEntry(id));
    pushToast({ title: "Merged", description: `${pendingMerge.sourceIds.length} originals moved to Trash.` });
    goToMergedAndReset();
  }

  function keepMergeSources() {
    pushToast({ title: "Merged", description: "Originals kept as-is." });
    goToMergedAndReset();
  }

  function goToMergedAndReset() {
    const merged = pendingMerge?.merged;
    exitSelectMode();
    pendingMerge = null;
    if (merged) goto(merged.type === "todo" ? `/todo/${merged.id}` : `/note/${merged.id}`);
  }

  async function handleExportSelected(format: ExportFormat) {
    breadcrumb(`selection: exporting ${selectedIds.size} items as ${format}`);
    // Same fix as handleDownloadSingle: locked entries in a multi-select
    // would otherwise each produce an empty plaintext file. They get
    // their encrypted backup instead, alongside the normal export of
    // whatever else was selected — rather than blocking the whole
    // export because one locked item was in the set.
    const locked = selectedEntries.filter((e) => e.encrypted);
    const open = selectedEntries.filter((e) => !e.encrypted);
    const files = [...(open.length > 0 ? buildExportFiles(open, format) : []), ...locked.map(buildEncryptedBackupFile)];
    await downloadFiles(files);
    pushToast({ title: "Exported", description: `${selectedIds.size} item${selectedIds.size === 1 ? "" : "s"} downloaded.` });
    exitSelectMode();
  }

  // Todos don't have a dedicated card component (see the inline markup
  // below) — same long-press-vs-tap gesture, reimplemented here rather
  // than pulled into a shared component, since the todo item's markup
  // is simple enough that a whole extra component would be more
  // indirection than the few lines it'd save.
  let suppressTodoClick = new Set<string>();

  function todoPressHandlers(id: string) {
    return createLongPressHandlers({
      onLongPress: () => {
        suppressTodoClick.add(id);
        enterSelectMode(id);
      },
      onTap: () => {
        suppressTodoClick.add(id);
        if (selectMode) toggleSelect(id);
        else handleClick(id);
      },
    });
  }

  function handleTodoClick(id: string) {
    if (lockBusyIds.has(id)) return;
    if (suppressTodoClick.has(id)) {
      suppressTodoClick.delete(id);
      return;
    }
    if (selectMode) toggleSelect(id);
    else handleClick(id);
  }
</script>

  <main class="page" class:body-has-image={appBodyResolved.kind === "image"} style={pageBodyStyle}>
    <AppHeader />

    <div class="view-tabs" style={viewTabsStyle}>
      <button class:active={activeView === "notes"} onclick={() => switchView("notes")}>Notes</button>
      <button class:active={activeView === "todos"} onclick={() => switchView("todos")}>Todos</button>
      <button class:active={activeView === "boards"} onclick={() => switchView("boards")}>Boards</button>
      <button class:active={activeView === "folders"} onclick={() => switchView("folders")}>Folders</button>
    </div>

    <div class="content">
      <div class="inner">
        {#if activeView === "folders"}
          <FoldersView />
        {:else}
        <div class="controls">
          <input
            class="search"
            type="text"
            placeholder="Search {activeView}..."
            bind:value={searchQuery}
          />
          <select class="sort" bind:value={sortBy}>
            <option value="recent">Recent</option>
            <option value="alphabetical">A-Z</option>
            <option value="bookmarked">Bookmarked</option>
          </select>
          <div class="view-toggle" role="group" aria-label="Layout">
            <button
              type="button"
              class:active={!isGrid}
              aria-label="List view"
              aria-pressed={!isGrid}
              onclick={() => {
                breadcrumb("view: list");
                setListViewMode("list");
              }}
            >
              <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">
                <line x1="4" y1="6" x2="20" y2="6" /><line x1="4" y1="12" x2="20" y2="12" /><line x1="4" y1="18" x2="20" y2="18" />
              </svg>
            </button>
            <button
              type="button"
              class:active={isGrid}
              aria-label="Grid view"
              aria-pressed={isGrid}
              onclick={() => {
                breadcrumb("view: grid");
                setListViewMode("grid");
              }}
            >
              <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">
                <rect x="4" y="4" width="7" height="7" rx="1" /><rect x="13" y="4" width="7" height="7" rx="1" />
                <rect x="4" y="13" width="7" height="7" rx="1" /><rect x="13" y="13" width="7" height="7" rx="1" />
              </svg>
            </button>
          </div>
        </div>

        <div class="tags-section">
          <div class="tags-header">
            <h3>Tags</h3>
            <Button variant="outline" size="sm" onclick={handleAddTag}>Add Tag</Button>
          </div>
          <div class="tag-chips">
            {#each tagList as tag (tag)}
              <div class="chip" class:selected={selectedTag === tag}>
                <button onclick={() => (selectedTag = selectedTag === tag ? null : tag)}>{tag}</button>
                {#if !isBuiltIn(tag)}
                  <button class="remove" onclick={() => handleRemoveTag(tag)} aria-label="Remove {tag}">×</button>
                {/if}
              </div>
            {/each}
            {#each inheritedChipTags as tag (tag)}
              <div class="chip inherited" class:selected={selectedTag === tag}>
                <button onclick={() => (selectedTag = selectedTag === tag ? null : tag)} aria-label={`Filter by ${tag} (from a folder)`}>{tag}</button>
              </div>
            {/each}
          </div>
        </div>

        {#if activeView === "notes" && !selectMode}
          <AiNoteCreator onNoteCreated={handleAiNoteCreated} />
        {/if}

        <div class="swipe-area" {...swipeAreaHandlers}>
          <div class="section-header">
            <h2>All {itemNoun}s{selectedTag ? ` — ${selectedTag}` : ""}</h2>
            {#if !selectMode}
              <Button onclick={() => goto(newRoute)}>
                + New {itemNoun}
              </Button>
            {/if}
          </div>

          {#if sortedItems.length === 0}
            <div class="empty">
              <p>No {activeView} found.</p>
              <Button size="lg" onclick={() => goto(newRoute)}>
                Create {itemNoun}
              </Button>
            </div>
          {:else}
            <div class="grid view-{listViewMode.value}">
            {#each sortedItems as item (item.id)}
              {#if item.type === "regular"}
                <NoteCard
                  note={item}
                  onToggleBookmark={toggleBookmark}
                  onClick={handleClick}
                  selectionMode={selectMode}
                  selected={selectedIds.has(item.id)}
                  onToggleSelect={toggleSelect}
                  onEnterSelectMode={enterSelectMode}
                  onDelete={handleDeleteSingle}
                  onDownload={handleDownloadSingle}
                  onToggleStrikethrough={toggleStrikethrough}
                  onTogglePin={togglePinned}
                  unlockingToOpen={lockBusyIds.has(item.id)}
                  compact={isGrid}
                  inheritedTags={inheritedOf(item.id)}
                  onMove={() => requestMove([item.id])}
                />
              {:else if item.type === "board"}
                <!-- Brought to parity with the todo row above (kebab
                     menu, pin, bookmark, select-mode) per CLAUDEcode's
                     explicit ask — this was the one deliberately-deferred
                     piece left over from round 17. Header theme/scrim now
                     wired too (round 22) — it's the exact same
                     listCardStyle/has-image-theme/theme-scrim treatment
                     the todo row below uses, since Board carries
                     headerTheme via EntryRef unchanged; nothing here is
                     board-specific. -->
                {@const resolvedBoardIcon = resolveIcon(item.icon, customIcons)}
                <div
                  class="todo-item"
                  class:compact={isGrid}
                  class:selected={selectedIds.has(item.id)}
                  class:has-image-theme={resolveTheme(item.headerTheme, customThemes).kind === "image"}
                  style={listCardStyle(item)}
                  role="button"
                  tabindex="0"
                  onclick={() => handleTodoClick(item.id)}
                  onkeydown={(e) => e.key === "Enter" && handleTodoClick(item.id)}
                  {...todoPressHandlers(item.id)}
                >
                  {#if resolveTheme(item.headerTheme, customThemes).kind === "image"}
                    <div class="theme-scrim" aria-hidden="true"></div>
                  {/if}
                  {#if selectMode}
                    <div class="select-check" class:checked={selectedIds.has(item.id)} aria-hidden="true">
                      {#if selectedIds.has(item.id)}
                        <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="3">
                          <polyline points="20 6 9 17 4 12" />
                        </svg>
                      {/if}
                    </div>
                  {:else}
                    <div class="todo-overflow">
                      {#if item.isPinned}
                        <span class="pin-indicator" aria-label="Pinned" title="Pinned">
                          <svg viewBox="0 0 24 24" width="12" height="12" fill="currentColor">
                            <path d="M12 17v5" /><path d="M9 3h6l-1 6 3 3v2H7v-2l3-3-1-6z" />
                          </svg>
                        </span>
                      {/if}
                      <CardOverflowMenu
                        itemLabel="board"
                        struck={item.struck}
                        pinned={item.isPinned}
                        encrypted={item.encrypted}
                        busy={lockBusyIds.has(item.id)}
                        onDelete={() => handleDeleteSingle(item.id)}
                        onDownload={() => handleDownloadSingle(item.id)}
                        onCopy={async () => pushToast(await copyEntryContent(item))}
                        onShare={async () => {
                          const toast = await shareEntryFromMenu(item, "board", () => downloadFiles(buildExportFiles([item], "separate")), breadcrumb);
                          if (toast) pushToast(toast);
                        }}
                        onToggleStrikethrough={() => toggleStrikethrough(item.id)}
                        onTogglePin={() => togglePinned(item.id)}
                        onToggleLock={() => handleToggleLock(item)}
                        onMove={() => requestMove([item.id])}
                        onOpenTags={() => {
                          tagsPopupFor = item;
                          tagsPopupOpen = true;
                        }}
                      />
                    </div>
                    <button
                      class="bookmark"
                      class:active={item.isBookmarked}
                      onclick={(e) => {
                        e.stopPropagation();
                        toggleBookmark(item.id);
                      }}
                      onpointerdown={(e) => e.stopPropagation()}
                      onpointerup={(e) => e.stopPropagation()}
                      onpointermove={(e) => e.stopPropagation()}
                      onpointercancel={(e) => e.stopPropagation()}
                      aria-label="Toggle bookmark"
                    >
                      <svg viewBox="0 0 24 24" width="16" height="16" fill={item.isBookmarked ? "currentColor" : "none"} stroke="currentColor" stroke-width="2">
                        <polygon points="12 2 15.09 8.63 22 9.24 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.24 8.91 8.63 12 2" />
                      </svg>
                    </button>
                  {/if}
                  <div class="title-row">
                    {#if resolvedBoardIcon.kind === "preset"}
                      <span class="icon-badge" aria-hidden="true">{resolvedBoardIcon.glyph}</span>
                    {:else if resolvedBoardIcon.kind === "custom"}
                      <span class="icon-badge icon-badge-image" style="background-image:url({resolvedBoardIcon.dataUrl})" aria-hidden="true"></span>
                    {/if}
                    {#if item.encrypted}
                      <LockBadge />
                    {/if}
                    {#if reminderDueAt(item)}
                      <ReminderBadge at={reminderDueAt(item) as string} repeating={!!item.reminderRepeat} />
                    {/if}
                    <strong class:struck={item.struck}>{item.title || "Untitled"}</strong>
                  </div>
                  {#if !item.encrypted}
                    <span class="meta">
                      {item.nodes.length} node{item.nodes.length === 1 ? "" : "s"} · {new Date(item.lastModified).toLocaleDateString()}
                    </span>
                  {/if}
                  {#if item.tags.length > 0 || inheritedOf(item.id).length > 0}
                    <div class="tags">
                      {#each item.tags as tag (tag)}
                        <span class="tag">{tag}</span>
                      {/each}
                      {#each inheritedOf(item.id) as tag (tag)}
                        <span class="tag inherited" title="From a folder">{tag}</span>
                      {/each}
                    </div>
                  {/if}
                </div>
              {:else}
                {@const resolvedItemIcon = resolveIcon(item.icon, customIcons)}
                <div
                  class="todo-item"
                  class:compact={isGrid}
                  class:selected={selectedIds.has(item.id)}
                  class:has-image-theme={resolveTheme(item.headerTheme, customThemes).kind === "image"}
                  style={listCardStyle(item)}
                  role="button"
                  tabindex="0"
                  onclick={() => handleTodoClick(item.id)}
                  onkeydown={(e) => e.key === "Enter" && handleTodoClick(item.id)}
                  {...todoPressHandlers(item.id)}
                >
                  {#if resolveTheme(item.headerTheme, customThemes).kind === "image"}
                    <div class="theme-scrim" aria-hidden="true"></div>
                  {/if}
                  {#if selectMode}
                    <div class="select-check" class:checked={selectedIds.has(item.id)} aria-hidden="true">
                      {#if selectedIds.has(item.id)}
                        <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="3">
                          <polyline points="20 6 9 17 4 12" />
                        </svg>
                      {/if}
                    </div>
                  {:else}
                    <!-- Left corner, matching NoteCard's .corner-actions
                         placement — moved from the right so the new
                         bookmark star (below) can take the right
                         corner, same as NoteCard, instead of the two
                         fighting over the same spot. -->
                    <div class="todo-overflow">
                      {#if item.isPinned}
                        <span class="pin-indicator" aria-label="Pinned" title="Pinned">
                          <svg viewBox="0 0 24 24" width="12" height="12" fill="currentColor">
                            <path d="M12 17v5" /><path d="M9 3h6l-1 6 3 3v2H7v-2l3-3-1-6z" />
                          </svg>
                        </span>
                      {/if}
                      <CardOverflowMenu
                        itemLabel="todo"
                        struck={item.struck}
                        pinned={item.isPinned}
                        encrypted={item.encrypted}
                        busy={lockBusyIds.has(item.id)}
                        onDelete={() => handleDeleteSingle(item.id)}
                        onDownload={() => handleDownloadSingle(item.id)}
                        onCopy={async () => pushToast(await copyEntryContent(item))}
                        onShare={async () => {
                          const toast = await shareEntryFromMenu(item, "todo", () => downloadFiles(buildExportFiles([item], "separate")), breadcrumb);
                          if (toast) pushToast(toast);
                        }}
                        onToggleStrikethrough={() => toggleStrikethrough(item.id)}
                        onTogglePin={() => togglePinned(item.id)}
                        onToggleLock={() => handleToggleLock(item)}
                        onMove={() => requestMove([item.id])}
                        onOpenTags={() => {
                          tagsPopupFor = item;
                          tagsPopupOpen = true;
                        }}
                      />
                    </div>
                    <!-- Todos never had this at all before — NoteCard's
                         had one since Pin/Theme v1, this was just a gap.
                         Same markup/behavior as NoteCard's own bookmark
                         button, just wired to this item instead. -->
                    <button
                      class="bookmark"
                      class:active={item.isBookmarked}
                      onclick={(e) => {
                        e.stopPropagation();
                        toggleBookmark(item.id);
                      }}
                      onpointerdown={(e) => e.stopPropagation()}
                      onpointerup={(e) => e.stopPropagation()}
                      onpointermove={(e) => e.stopPropagation()}
                      onpointercancel={(e) => e.stopPropagation()}
                      aria-label="Toggle bookmark"
                    >
                      <svg viewBox="0 0 24 24" width="16" height="16" fill={item.isBookmarked ? "currentColor" : "none"} stroke="currentColor" stroke-width="2">
                        <polygon points="12 2 15.09 8.63 22 9.24 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.24 8.91 8.63 12 2" />
                      </svg>
                    </button>
                  {/if}
                  <div class="title-row">
                    {#if resolvedItemIcon.kind === "preset"}
                      <span class="icon-badge" aria-hidden="true">{resolvedItemIcon.glyph}</span>
                    {:else if resolvedItemIcon.kind === "custom"}
                      <span class="icon-badge icon-badge-image" style="background-image:url({resolvedItemIcon.dataUrl})" aria-hidden="true"></span>
                    {/if}
                    {#if item.encrypted}
                      <LockBadge />
                    {/if}
                    {#if reminderDueAt(item)}
                      <ReminderBadge at={reminderDueAt(item) as string} repeating={!!item.reminderRepeat} />
                    {/if}
                    <strong class:struck={item.struck}>{item.title || "Untitled"}</strong>
                  </div>
                  <!-- Same as NoteCard.svelte: while locked, only name +
                       icon + tags show. Todos never showed tags at all
                       before this (a pre-existing gap unrelated to
                       encryption, on top of the actual bug) — added
                       here unconditionally, same as NoteCard, rather
                       than only while locked, which would have made a
                       locked todo show MORE than an unlocked one. -->
                  {#if !item.encrypted}
                    <span class="meta">
                      {progressLabel(item.steps)} · {new Date(item.lastModified).toLocaleDateString()}
                    </span>
                    <!-- Round 38: a thin progress bar under the line, once anything is ticked. -->
                    {#if item.steps.length > 0 && countDone(item.steps) > 0}
                      <div class="todo-progress" class:complete={countDone(item.steps) === item.steps.length} role="img" aria-label={`${countDone(item.steps)} of ${item.steps.length} steps done`}>
                        <div class="todo-progress-fill" style="width: {Math.round((countDone(item.steps) / item.steps.length) * 100)}%"></div>
                      </div>
                    {/if}
                  {/if}
                  {#if item.tags.length > 0 || inheritedOf(item.id).length > 0}
                    <div class="tags">
                      {#each item.tags as tag (tag)}
                        <span class="tag">{tag}</span>
                      {/each}
                      {#each inheritedOf(item.id) as tag (tag)}
                        <span class="tag inherited" title="From a folder">{tag}</span>
                      {/each}
                    </div>
                  {/if}
                </div>
              {/if}
            {/each}
          </div>
          {/if}
        </div>
        {/if}
      </div>
    </div>
  </main>

  {#if selectMode}
    <SelectionActionBar
      selectedCount={selectedIds.size}
      itemLabel={itemNoun.toLowerCase()}
      {canMerge}
      {selectionHasEncrypted}
      onCancel={exitSelectMode}
      onDelete={handleDeleteSelected}
      onSend={handleSendSelected}
      onCopy={handleCopySelected}
      onMerge={handleMergeSelected}
      onExport={handleExportSelected}
      onMove={() => requestMove([...selectedIds], exitSelectMode)}
    />
  {/if}

  <FolderPickerHost />

  <!-- BUGFIX (round 25): "removed" here is a soft delete (Trash) now —
       copy updated so this doesn't read as more final than it is. -->
  <ConfirmDialog
    bind:open={showMergeConfirm}
    title="Move the originals to Trash?"
    description="They've been combined into '{pendingMerge?.merged.title ?? 'the merged item'}'. Keep them separately, or move them to Trash now that they're merged?"
    confirmLabel="Move to Trash"
    danger
    onconfirm={confirmDeleteMergeSources}
    oncancel={keepMergeSources}
  />

  <TagsPopup
    bind:open={tagsPopupOpen}
    tags={tagsPopupFor?.tags ?? []}
    availableTags={tagsPopupAvailableTags}
    onAddTag={(tag) => tagsPopupFor && handleAddTagTo(tagsPopupFor, tag)}
    onRemoveTag={(tag) => tagsPopupFor && handleRemoveTagFrom(tagsPopupFor, tag)}
  />

<style>
  .page {
    display: flex;
    flex-direction: column;
    height: 100dvh;
    max-width: 100vw;
    overflow-x: hidden;
    background: var(--bg);
  }
  /* BUGFIX: no justify-content + no width on the buttons meant they
     just clamped together at the natural width of their own text,
     flush left — asked to be spread properly instead, with room to
     grow into a third tab (Boards) later without needing to revisit
     this. flex:1 on each button divides the bar into equal, full-width
     segments — the first tab's tap target starts at the true left
     screen edge and the last one's ends at the true right edge (hence
     dropping this container's own horizontal padding, which would
     otherwise inset both from the actual edges), and adding a third
     button later just becomes a third equal segment automatically. */
  .view-tabs {
    display: flex;
    border-bottom: 1px solid var(--hairline);
    background: var(--surface);
    flex-shrink: 0;
  }
  .view-tabs button {
    flex: 1;
    text-align: center;
    padding: var(--space-3) var(--space-4);
    font-family: var(--font-sans);
    font-weight: 500;
    font-size: 14px;
    background: none;
    border: none;
    border-bottom: 2px solid transparent;
    color: var(--text-lo);
    cursor: pointer;
  }
  .view-tabs button.active {
    color: var(--accent);
    border-bottom-color: var(--accent);
  }
  .content {
    flex: 1;
    min-height: 0;
    overflow-y: auto;
    overflow-x: hidden;
    padding: var(--space-5) var(--space-4);
  }
  .inner {
    max-width: 760px;
    width: 100%;
    margin: 0 auto;
    display: flex;
    flex-direction: column;
    gap: var(--space-5);
    min-width: 0;
  }
  .controls {
    display: flex;
    gap: var(--space-3);
    min-width: 0;
  }
  .search {
    flex: 1;
    min-width: 0;
    font-family: var(--font-sans);
    font-size: 14px;
    color: var(--text-hi);
    background: var(--surface);
    border: 1px solid var(--hairline);
    border-radius: var(--radius-sm);
    padding: var(--space-2) var(--space-3);
  }
  .sort {
    flex-shrink: 0;
    max-width: 40%;
    font-family: var(--font-sans);
    font-size: 14px;
    color: var(--text-hi);
    background: var(--surface);
    border: 1px solid var(--hairline);
    border-radius: var(--radius-sm);
    padding: var(--space-2) var(--space-3);
  }
  .tags-section {
    padding-bottom: var(--space-4);
    border-bottom: 1px solid var(--hairline);
  }
  .tags-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: var(--space-3);
  }
  .tags-header h3 {
    font-size: 13px;
    font-weight: 600;
    color: var(--text-hi);
    margin: 0;
  }
  /* BUGFIX: the "Tags" heading has no background of its own (it's a
     plain <h3>, not a themed component), so it still needs an explicit
     override here — unlike "Add Tag" (a Button variant="outline"),
     which now picks up --theme-tag-bg/--theme-text-hi automatically via
     Button.svelte's own CSS var fallback, since those vars are already
     set on this file's .page (an ancestor) whenever body-has-image is
     active. Scoped to body-has-image specifically so nothing changes
     for the untheemed default look or a color-preset body theme (the
     low-alpha wash there was never the actual problem). */
  .body-has-image .tags-header h3 {
    color: var(--theme-text-hi);
  }
  .tag-chips {
    display: flex;
    flex-wrap: wrap;
    gap: var(--space-2);
  }
  .chip {
    display: flex;
    align-items: center;
    gap: var(--space-1);
    background: var(--surface-raised);
    border-radius: 999px;
    padding: 4px var(--space-1) 4px var(--space-3);
    font-size: 13px;
  }
  .chip.selected {
    background: var(--accent);
  }
  /* a tag that comes from a folder: no remove button, a little quieter */
  .chip.inherited {
    padding-right: var(--space-3);
    opacity: 0.8;
  }
  .chip.selected button {
    color: var(--bg);
  }
  .chip button {
    background: none;
    border: none;
    color: var(--text-hi);
    cursor: pointer;
    font-size: 13px;
  }
  .chip .remove {
    padding: 0 var(--space-2);
    opacity: 0.6;
  }
  .section-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: var(--space-3);
    flex-wrap: wrap;
  }
  /* .inner is display:flex/column with its own `gap` between direct
     children — section-header and empty/grid used to BE two of those
     direct children, getting that gap between them for free. Now
     they're both inside this wrapper instead (needed as the single
     element the swipe gesture listens on), so it has to reproduce the
     same flex/gap itself or that spacing collapses to zero. */
  /* BUGFIX (round 22): `touch-action: pan-y` is load-bearing, not
     decorative — see swipe.ts's header comment for the full mechanism.
     Without it (the default is `auto`), Chromium/WebView pre-empts every
     real touch-driven swipe with `pointercancel` before swipe.ts's
     onpointerup ever sees a real dx, so the gesture silently never
     fired. `pan-y` tells the browser vertical scrolling is still its
     job, but horizontal movement here is ours to interpret — the same
     class of fix as board nodes' `touch-action: none` (see BoardCanvas'
     node CSS), just `pan-y` instead of `none` here since this area must
     still scroll vertically. Applied to descendants too (not just this
     wrapper) since some browsers only reliably suppress the pre-emptive
     cancel when every touched element in the chain agrees, not just the
     nearest ancestor. */
  .swipe-area,
  .swipe-area * {
    touch-action: pan-y;
  }
  .swipe-area {
    display: flex;
    flex-direction: column;
    gap: var(--space-5);
    min-width: 0;
  }
  .section-header h2 {
    font-family: var(--font-display);
    font-size: 19px;
    color: var(--text-hi);
    margin: 0;
    min-width: 0;
    overflow-wrap: break-word;
  }
  .empty {
    text-align: center;
    padding: var(--space-6) 0;
  }
  .empty p {
    color: var(--text-lo);
    margin: 0 0 var(--space-4);
  }
  .grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(240px, 1fr));
    gap: var(--space-4);
  }
  /* A grid item's minimum width is its content's minimum width, and a "1fr" track is really "minmax(auto, 1fr)":
     one long unbreakable string in ANY card (a "=====" divider line in a note, a long URL) made the whole column wider
     than the screen and every card ran off the right edge. min-width: 0 on the items and minmax(0, 1fr) on the tracks
     below let a card be as narrow as its column and wrap or clip its own text instead. */
  .grid > :global(*) {
    min-width: 0;
  }
  /* Round 33. "list" is one card per row at every width; "grid" is compact
     cards, two per row on a phone (the 480px media block below) and as many
     as fit on a wider screen. */
  .grid.view-list {
    grid-template-columns: minmax(0, 1fr);
  }
  .grid.view-grid {
    grid-template-columns: repeat(auto-fill, minmax(170px, 1fr));
    gap: var(--space-3);
  }
  .view-toggle {
    flex-shrink: 0;
    display: flex;
    border: 1px solid var(--hairline);
    border-radius: var(--radius-sm);
    background: var(--surface);
    overflow: hidden;
  }
  .view-toggle button {
    width: 38px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: transparent;
    border: none;
    color: var(--text-lo);
    cursor: pointer;
  }
  .view-toggle button + button {
    border-left: 1px solid var(--hairline);
  }
  .view-toggle button.active {
    background: var(--accent-wash);
    color: var(--accent);
  }
  /* Compact todo/board cards (NoteCard has its own compact rules). The
     corner actions are absolutely positioned across the top, so the title
     row drops below them instead of squeezing between them — in a ~160px
     card there is no room beside them. */
  .todo-item.compact {
    padding: var(--space-3);
  }
  .todo-item.compact .title-row {
    margin: 28px 0 0 0;
  }
  .todo-item.compact .title-row strong {
    white-space: normal;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    line-clamp: 2;
    -webkit-box-orient: vertical;
    font-size: 14px;
  }
  .todo-progress {
    height: 4px;
    margin-top: var(--space-2);
    background: var(--hairline);
    border-radius: 999px;
    overflow: hidden;
  }
  .todo-progress-fill {
    height: 100%;
    background: var(--accent-dim, var(--accent));
    border-radius: 999px;
  }
  .todo-progress.complete .todo-progress-fill {
    background: var(--accent);
  }
  .todo-item.compact .meta {
    font-size: 11px;
  }
  .todo-item {
    position: relative;
    display: flex;
    flex-direction: column;
    gap: var(--space-1);
    text-align: left;
    background: var(--surface);
    border: 1px solid var(--hairline);
    border-radius: var(--radius-md);
    padding: var(--space-4);
    cursor: pointer;
    color: var(--text-hi);
  }
  .todo-item:hover {
    border-color: var(--accent-dim);
  }
  .todo-item.selected {
    border-color: var(--accent);
    box-shadow: 0 0 0 2px var(--accent-wash);
  }
  .todo-item .meta {
    font-size: 12px;
    color: var(--text-faint);
  }
  /* Same rules as NoteCard.svelte's .tags/.tag — todos never had a tags
     display of their own before this. */
  .todo-item .tags {
    display: flex;
    flex-wrap: wrap;
    gap: var(--space-1);
  }
  .todo-item .tag.inherited {
    opacity: 0.6;
  }
  .todo-item .tag {
    font-size: 11px;
    padding: 2px var(--space-2);
    border-radius: 999px;
    background: var(--accent-wash);
    color: var(--accent);
    font-weight: 500;
  }
  .todo-item .select-check {
    position: absolute;
    top: var(--space-2);
    right: var(--space-2);
    width: 24px;
    height: 24px;
    border-radius: 50%;
    border: 2px solid var(--hairline);
    background: var(--surface);
    display: flex;
    align-items: center;
    justify-content: center;
    color: var(--bg);
  }
  .todo-item .select-check.checked {
    background: var(--accent);
    border-color: var(--accent);
  }
  .todo-item .todo-overflow {
    position: absolute;
    top: var(--space-2);
    left: var(--space-2);
    display: flex;
    align-items: center;
    gap: 2px;
  }
  .todo-item .pin-indicator {
    width: 16px;
    height: 16px;
    color: var(--accent);
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
  }
  /* Same markup/behavior/look as NoteCard.svelte's own .bookmark — this
     is that same feature, just missing from todos until now. Right
     corner, matching NoteCard, now that .todo-overflow (above) has
     moved to the left to make room for it. */
  .todo-item .bookmark {
    position: absolute;
    top: var(--space-2);
    right: var(--space-2);
    width: 32px;
    height: 32px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: transparent;
    border: none;
    border-radius: var(--radius-sm);
    /* Same fallback as NoteCard.svelte's identical .bookmark rule — see
       that file's comment for why only the unbookmarked/outline state
       needs this, not .active below. */
    color: var(--theme-text-lo, var(--text-faint));
    cursor: pointer;
  }
  .todo-item .bookmark:hover {
    background: var(--surface-raised);
  }
  .todo-item .bookmark.active {
    color: var(--accent-2);
  }
  /* Same title-row/icon-badge pattern as NoteCard.svelte — the icon
     badge (when set) sits just before the title text. Margin here
     reserves room for the corner-actions cluster now on the left and
     the bookmark star on the right, same reasoning as NoteCard's own
     title-row margin. Applies to boards too now that they have the
     same overflow cluster/bookmark as todos (used to have its own
     margin-reset variant here from when boards had neither). */
  .todo-item .title-row {
    display: flex;
    align-items: center;
    gap: var(--space-2);
    min-width: 0;
    margin: 0 var(--space-6) 0 48px;
  }
  .todo-item .icon-badge {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 22px;
    height: 22px;
    border-radius: 50%;
    background: var(--surface-raised);
    font-size: 13px;
    line-height: 1;
    flex-shrink: 0;
  }
  .todo-item .icon-badge-image {
    background-size: cover;
    background-position: center;
  }
  .todo-item .title-row strong {
    min-width: 0;
    flex: 1;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  .todo-item strong.struck {
    text-decoration: line-through;
    color: var(--text-lo);
  }
  .todo-item .theme-scrim {
    position: absolute;
    inset: 0;
    background: linear-gradient(180deg, rgba(4, 6, 16, 0.15) 0%, rgba(4, 6, 16, 0.72) 100%);
    border-radius: inherit;
  }
  /* --theme-text-hi/mid/lo and --theme-tag-bg/text are set inline via
     listCardStyle (see getImageTextColorVars) — light or dark depending
     on this specific image's actual sampled color, not assumed. Same
     reasoning as NoteCard.svelte's identical override. */
  .todo-item.has-image-theme {
    color: var(--theme-text-hi);
  }
  .todo-item.has-image-theme .meta {
    color: var(--theme-text-lo);
  }
  .todo-item.has-image-theme .tag {
    background: var(--theme-tag-bg);
    color: var(--theme-tag-text);
  }

  @media (max-width: 480px) {
    .content {
      padding-left: var(--space-3);
      padding-right: var(--space-3);
    }
    .grid {
      grid-template-columns: minmax(0, 1fr);
    }
    .grid.view-grid {
      grid-template-columns: repeat(2, minmax(0, 1fr));
    }
    .controls {
      flex-wrap: wrap;
    }
    .sort {
      max-width: none;
      flex: 1 1 auto;
    }
    .section-header h2 {
      font-size: 17px;
    }
  }
</style>
