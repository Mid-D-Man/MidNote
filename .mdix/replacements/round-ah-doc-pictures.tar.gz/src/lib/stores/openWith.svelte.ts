// Round K — "Open with MidNote": a file the phone's "Open with" list handed to the app.
//
// utils/openWith.ts holds the rules (what a file is, how its text becomes a note); utils/openWithNative.ts is the
// phone side (the content:// link and the file's bytes). This store connects them and holds what the sheet shows.
//
// Nothing is created or changed until the person taps a button in the sheet. The file is read as DATA only and is never
// kept: after the sheet closes, only a note the person chose to create (or a backup handed to Backup & restore, which
// has its own preview) remains.
//
// Writes `openWith` only from event handlers / client callbacks, never from an $effect (docs/svelte5-effect-safety.md).
import { breadcrumb } from "$lib/debug/log.svelte";
import { saveEntry } from "$lib/stores/entries.svelte";
import { createNote } from "$lib/storage";
import { realOpenWithBackend } from "$lib/utils/openWithNative";
import { docxToText, DocxError } from "$lib/utils/docxText";
import { pptxToText } from "$lib/utils/pptxText";
import { ZipError } from "$lib/utils/zipRead";
import { pdfToText, PdfError } from "$lib/utils/pdfText";
import { widgetKind, widgetPath } from "$lib/utils/widgetLinks";
import { formatFromExtension } from "$lib/utils/readingFormat";
import { setReadingFormat } from "$lib/stores/readingView.svelte";
import { MAX_NOTE_CHARS, MAX_READ_BYTES, classifyIncoming, clampForNote, isContentUrl, nameFromUrl, textToNoteHtml, titleFor } from "$lib/utils/openWith";
import type { PickedFile } from "$lib/utils/backupFiles";
import { parseTextLink, rememberTextLink, isTextLink, type TextLink } from "$lib/utils/textLinks";
import { readAloud, readSelectionAloud } from "$lib/stores/readAloud.svelte";
import { MAX_DOC_IMAGES, docxImages, pptxImages, type DocImage } from "$lib/utils/docImages";
import { saveDocImages } from "$lib/utils/docImageStore";
import { sendAppToBack } from "$lib/utils/nativeReader";

export interface OpenFile {
  name: string | null;
  /** Bytes read. */
  size: number;
  kind: "text" | "docx" | "pptx" | "pdf" | "backup" | "refused";
  /** text / docx / pptx / pdf: what the note would contain. "" otherwise. */
  text: string;
  /** text / docx / pptx / pdf: characters in the whole file's text (more than `text` when it was cut). */
  chars: number;
  cut: boolean;
  /** pdf / pptx: a line about what was read ("12 pages", what is left out). "" otherwise. */
  info: string;
  part: "backup" | "key" | "encrypted" | null;
  /** refused: what to tell the person. */
  message: string;
  /** backup: the bytes to hand to Backup & restore. */
  bytes: Uint8Array | null;
  /** "selection": text picked in another app's selection menu (not a file). */
  source?: "selection";
  /** The pictures of a PowerPoint / Word / PDF file; they are kept on this phone with the note when it is made (utils/docImageStore.ts). */
  images?: DocImage[];
}

export const openWith = $state({
  /** Reading a file right now. */
  busy: false,
  /** What was read and is waiting for the person's choice. */
  file: null as OpenFile | null,
  /** A backup waiting for Backup & restore to open (when its screen wasn't already showing). */
  backup: null as PickedFile[] | null,
});

const LAST_COLD_KEY = "midnote:last-open-url";
const LAST_WIDGET_KEY = "midnote:last-widget-url";
let started = false;
let seq = 0;

function blank(name: string | null, size: number): OpenFile {
  return { name, size, kind: "refused", text: "", chars: 0, cut: false, info: "", part: null, message: "", bytes: null };
}

function refused(name: string | null, size: number, message: string): OpenFile {
  return { ...blank(name, size), message };
}

const WORD_UNREADABLE = "That isn't a Word document that MidNote can read.";
const PPTX_UNREADABLE = "That isn't a PowerPoint presentation that MidNote can read.";
const PDF_UNREADABLE = "That isn't a PDF that MidNote can read.";
const PDF_NO_TEXT = "This PDF has no text to read, and no pictures MidNote can show.";
const PDF_UNDECODABLE = "The text in this PDF uses a font MidNote can't decode, so nothing readable came out.";
const PPTX_NOTE = "Charts and animations are left out.";

/** The text of a Word, PowerPoint or PDF file, as the file to show. Never throws: every way it can fail is a refused file with a plain message. */
async function extractDocument(kind: "docx" | "pptx" | "pdf", name: string | null, bytes: Uint8Array): Promise<OpenFile> {
  const size = bytes.length;
  const withText = (as: "docx" | "pptx" | "pdf", text: string, info: string, forceCut = false, images: DocImage[] = []): OpenFile => {
    const clamped = clampForNote(text);
    return { ...blank(name, size), kind: as, text: clamped.text, chars: text.length, cut: clamped.cut || forceCut, info, images };
  };
  // the pictures are a bonus: a file whose pictures can't be read still opens, with its text
  const picturesOf = async (read: () => Promise<DocImage[]>): Promise<DocImage[]> => {
    try {
      return await read();
    } catch (e) {
      breadcrumb(`open with: pictures could not be read (${e instanceof Error ? e.message.slice(0, 80) : "error"})`);
      return [];
    }
  };
  const pictureCount = (images: DocImage[]) => {
    if (images.length === 0) return "";
    const n = `${images.length} picture${images.length === 1 ? "" : "s"}`;
    return images.length >= MAX_DOC_IMAGES ? `the first ${n}` : n;
  };
  const slideInfo = (text: string, images: DocImage[]) => {
    const n = (text.match(/^Slide \d+$/gm) ?? []).length;
    const pics = pictureCount(images);
    return `${n} slide${n === 1 ? "" : "s"}${pics ? `, ${pics}` : ""}. ${PPTX_NOTE}`;
  };
  try {
    if (kind === "pdf") {
      const r = await pdfToText(bytes, MAX_NOTE_CHARS + 20_000);
      if (r === null) return refused(name, size, PDF_UNREADABLE);
      if (r.text.trim() === "") return refused(name, size, r.garbled ? PDF_UNDECODABLE : PDF_NO_TEXT);
      const parts = [`${r.pages} page${r.pages === 1 ? "" : "s"}${r.truncated ? `, the first ${r.pagesRead} read` : ""}`];
      if (r.scanned) parts.push(`No text found, so the pages are kept as pictures (${pictureCount(r.pictures)})`);
      else parts.push(r.pictures.length > 0 ? `${pictureCount(r.pictures)}. Drawings are left out` : "Text only: pictures and drawings are left out");
      if (r.garbled) parts.push("some text uses a font MidNote can't decode, so parts are missing");
      return withText("pdf", r.text, parts.join(". ") + ".", r.truncated, r.pictures);
    }
    if (kind === "pptx") {
      const text = await pptxToText(bytes);
      if (text === null) return refused(name, size, PPTX_UNREADABLE);
      if (text.trim() === "") return refused(name, size, "That presentation has no text in it.");
      const images = await picturesOf(() => pptxImages(bytes));
      return withText("pptx", text, slideInfo(text, images), false, images);
    }
    let text: string | null = null;
    try {
      text = await docxToText(bytes);
    } catch (e) {
      if (e instanceof DocxError) {
        breadcrumb(`open with: docx refused (${e.kind})`);
        return refused(name, size, e.message);
      }
    }
    if (text === null && name === null) {
      // a file whose name is unknown, so it may be a PowerPoint file
      const slides = await pptxToText(bytes);
      if (slides !== null) {
        if (slides.trim() === "") return refused(name, size, "That presentation has no text in it.");
        const images = await picturesOf(() => pptxImages(bytes));
        return withText("pptx", slides, slideInfo(slides, images), false, images);
      }
    }
    if (text === null) return refused(name, size, WORD_UNREADABLE);
    if (text.trim() === "") return refused(name, size, "That document has no text in it.");
    const images = await picturesOf(() => docxImages(bytes));
    return withText("docx", text, pictureCount(images) ? `${pictureCount(images)}.` : "", false, images);
  } catch (e) {
    if (e instanceof PdfError || e instanceof ZipError) {
      breadcrumb(`open with: ${kind} refused (${e.kind})`);
      return refused(name, size, e.message);
    }
    breadcrumb(`open with: ${kind} could not be read (${e instanceof Error ? e.message.slice(0, 80) : "error"})`);
    return refused(name, size, kind === "pdf" ? PDF_UNREADABLE : kind === "pptx" ? PPTX_UNREADABLE : WORD_UNREADABLE);
  }
}

/** Reads and classifies one content:// link, then shows the sheet. Never throws. */
export async function openIncoming(url: string): Promise<void> {
  if (!isContentUrl(url)) return; // the midnote://auth sign-in link and anything else is not ours
  const backend = realOpenWithBackend();
  if (!backend) return;
  const mine = ++seq;
  openWith.busy = true;
  openWith.file = null;
  const name = nameFromUrl(url);
  try {
    const bytes = await backend.read(url, MAX_READ_BYTES);
    if (mine !== seq) return; // the person closed the sheet, or another file came in
    let file: OpenFile;
    if (bytes.length > MAX_READ_BYTES) {
      file = refused(name, bytes.length, "That file is too big to open (the limit is 32 MB).");
    } else {
      const c = classifyIncoming(name, bytes);
      if (c.kind === "refused") file = refused(name, bytes.length, c.message);
      else if (c.kind === "backup") file = { ...blank(name, bytes.length), kind: "backup", part: c.part, bytes };
      else if (c.kind === "text") file = { ...blank(name, bytes.length), kind: "text", text: c.text, chars: c.chars, cut: c.cut };
      else {
        file = await extractDocument(c.kind, name, bytes);
        if (mine !== seq) return;
      }
    }
    breadcrumb(`open with: ${file.kind}${file.part ? ` (${file.part})` : ""}, ${file.size} bytes`);
    openWith.file = file;
  } catch (e) {
    if (mine !== seq) return;
    breadcrumb(`open with: couldn't read the file (${e instanceof Error ? e.message.slice(0, 120) : "error"})`);
    openWith.file = refused(name, 0, "MidNote couldn't read that file. Try opening it again, or save a copy to your phone first.");
  } finally {
    if (mine === seq) openWith.busy = false;
  }
}

/**
 * Text picked in another app's selection menu (midnote://text/..., utils/textLinks.ts). "note": the text waits in the same sheet a
 * file does, and a note is only made when the person taps Create note. "read": it is read aloud, and the app steps back so the
 * person is where they were while it carries on. A link already acted on (Android hands links over again) is ignored.
 */
async function handleTextLink(url: string): Promise<void> {
  const link: TextLink | null = parseTextLink(url);
  if (!link) {
    breadcrumb("text link: ignored (not usable)");
    return;
  }
  if (!rememberTextLink(link.id)) return;
  breadcrumb(`text link: ${link.mode} (${link.text.length} chars${link.cut ? ", cut" : ""})`);
  if (link.mode === "note") {
    openWith.file = {
      ...blank(null, new TextEncoder().encode(link.text).length),
      kind: "text",
      text: link.text,
      chars: link.text.length,
      cut: link.cut,
      source: "selection",
    };
    return;
  }
  await readSelectionAloud("selection", link.text);
  if (readAloud.status === "reading" || readAloud.status === "starting") sendAppToBack();
}

/**
 * Starts listening: for files opened while the app runs, and for the file that started the app. Safe to call twice.
 *
 * The home-screen widget's buttons arrive through the same door as links (midnote://new/note | todo | board, see
 * utils/widgetLinks.ts): `onWidget` is called with the blank-editor route to open. Nothing is created by the link itself.
 */
export async function startOpenWith(onWidget?: (path: string) => void | Promise<void>): Promise<void> {
  if (started) return;
  started = true;
  const backend = realOpenWithBackend();
  if (!backend) return;
  const openWidget = (url: string, path: string) => {
    breadcrumb(`widget: new ${widgetKind(url)}`);
    void Promise.resolve(onWidget?.(path)).catch((e) => breadcrumb(`widget: could not open ${path} (${e instanceof Error ? e.message.slice(0, 80) : "error"})`));
  };
  try {
    await backend.onUrl((url) => {
      const path = widgetPath(url);
      if (path) openWidget(url, path);
      else if (isTextLink(url)) void handleTextLink(url);
      else void openIncoming(url);
    });
    for (const url of await backend.getCurrent()) {
      if (isTextLink(url)) {
        await handleTextLink(url);
        continue;
      }
      const path = widgetPath(url);
      if (path) {
        // The plugin keeps the app's launch link for as long as the app runs: remember that this session already acted
        // on it, so a page reload does not open another editor.
        let seenWidget = false;
        try {
          seenWidget = sessionStorage.getItem(LAST_WIDGET_KEY) === url;
          sessionStorage.setItem(LAST_WIDGET_KEY, url);
        } catch {
          /* no session storage: open it */
        }
        if (!seenWidget) openWidget(url, path);
        continue;
      }
      if (!isContentUrl(url)) continue;
      // The plugin keeps the app's launch link for as long as the app runs, so a page reload would offer the same
      // file again: remember which one this session already showed.
      let seen = false;
      try {
        seen = sessionStorage.getItem(LAST_COLD_KEY) === url;
        sessionStorage.setItem(LAST_COLD_KEY, url);
      } catch {
        /* no session storage: show it */
      }
      if (!seen) await openIncoming(url);
    }
  } catch (e) {
    breadcrumb(`open with: unavailable (${e instanceof Error ? e.message.slice(0, 120) : "error"})`);
  }
}

/** Closes the sheet and forgets the file. Also stops a read that is still going. */
export function dismissOpenFile(): void {
  seq++;
  openWith.busy = false;
  openWith.file = null;
}

/** Makes a note from the open text, Word, PowerPoint or PDF file and closes the sheet. Returns the note's id, or null. */
export function createNoteFromOpenFile(): string | null {
  const f = openWith.file;
  if (!f || (f.kind !== "text" && f.kind !== "docx" && f.kind !== "pptx" && f.kind !== "pdf") || f.text.trim() === "") return null;
  const n = createNote();
  n.title = titleFor(f.name, f.text);
  // The text goes in exactly as written, escaped (utils/openWith.ts textToNoteHtml): never parsed as markup.
  n.content = textToNoteHtml(f.text);
  saveEntry(n);
  // the title drops the file's extension, so remember what the file was: a .rs or .json file is read as code / JSON
  // (a Word / PowerPoint / PDF file is read as that: by what it was found to be, not by what its name says)
  const asFormat = f.kind === "docx" || f.kind === "pptx" || f.kind === "pdf" ? f.kind : formatFromExtension(f.name);
  if (asFormat) setReadingFormat(n.id, asFormat);
  breadcrumb(`open with: note created from ${f.kind} file (${f.text.length} chars${f.images?.length ? `, ${f.images.length} pictures` : ""})`);
  const pictures = f.images;
  openWith.file = null;
  // the pictures are kept next to the note (not in it); the note is already made, so this only adds to it
  if (pictures && pictures.length > 0) void saveDocImages(n.id, pictures);
  return n.id;
}

// ------------------------------------------------------------------ handing a backup to Backup & restore

let backupSink: ((files: PickedFile[]) => void) | null = null;

/** Backup & restore calls this while its screen is showing, so a backup opened meanwhile goes straight to it. */
export function registerBackupSink(fn: (files: PickedFile[]) => void): () => void {
  backupSink = fn;
  return () => {
    if (backupSink === fn) backupSink = null;
  };
}

/** A backup that arrived while Backup & restore wasn't showing: taken (once) when that screen opens. */
export function takeStashedBackup(): PickedFile[] | null {
  const f = openWith.backup;
  openWith.backup = null;
  return f;
}

/** Hands the open backup file on and closes the sheet. False when there is none. The caller then shows the screen. */
export function sendOpenFileToBackup(): boolean {
  const f = openWith.file;
  if (!f || f.kind !== "backup" || !f.bytes) return false;
  const fallback = f.part === "encrypted" ? "incoming.mdix.enc" : f.part === "key" ? "incoming.mdix.key" : "incoming.mdix";
  const files: PickedFile[] = [{ name: f.name ?? fallback, bytes: f.bytes }];
  openWith.file = null;
  if (backupSink) backupSink(files);
  else openWith.backup = files;
  return true;
}
