// What the phone may ask for. The server owns the system prompts, so the endpoint is a note
// assistant and not a general-purpose chatbot, and prompts can change without an APK release.
import { estimateTokens, utf8Bytes, type ChatMessage } from "./budget";

export const LIMITS = {
  body: 65536, // bytes
  prompt: 4000,
  instruction: 600,
  text: 16000,
  /** The text before / after a selection (each), as the phone sends it. The server trims it further. */
  context: 16000,
  note: 16000,
  turn: 4000,
  turns: 12,
  maxTokens: 4096,
} as const;

/**
 * The ledger refuses a request whose ESTIMATED input is over the model's max_input_tokens (8000 by
 * default). Selection edits stay under this ceiling by trimming the surrounding note text, so a long
 * note never makes an edit fail: only a selection that is itself too long does.
 */
export const INPUT_TOKEN_CEILING = 7600;

/** What "create" makes: a note (free text, or a titled note), or the line format of a todo list or a board (see CREATE_TODO_SYSTEM). */
export type CreateShape = "note" | "todo" | "board";

/** edit = the answer replaces the selection; continue = new text that follows it; ask = an answer about it. */
export type TransformMode = "edit" | "continue" | "ask";

export type RunRequest =
  | { task: "create"; prompt: string; titled: boolean; shape: CreateShape; maxTokens: number | null }
  | { task: "transform"; instruction: string; text: string; mode: TransformMode | null; before: string; after: string; maxTokens: number | null }
  | { task: "chat"; note: string; messages: { role: "user" | "assistant"; content: string }[]; maxTokens: number | null };

export type ParseResult = { ok: true; value: RunRequest } | { ok: false; error: "bad-request" | "too-long" };

const bad: ParseResult = { ok: false, error: "bad-request" };
const long: ParseResult = { ok: false, error: "too-long" };

function plain(v: unknown): v is Record<string, unknown> {
  return !!v && typeof v === "object" && !Array.isArray(v);
}

export function parseRun(raw: unknown): ParseResult {
  if (!plain(raw)) return bad;
  let maxTokens: number | null = null;
  if (raw.max_tokens !== undefined && raw.max_tokens !== null) {
    const m = raw.max_tokens;
    if (typeof m !== "number" || !Number.isInteger(m) || m < 1 || m > LIMITS.maxTokens) return bad;
    maxTokens = m;
  }
  switch (raw.task) {
    case "create": {
      if (typeof raw.prompt !== "string" || !raw.prompt.trim()) return bad;
      if (raw.prompt.length > LIMITS.prompt) return long;
      // titled: the answer is a NOTE (a title line, then the body) rather than free text
      if (raw.titled !== undefined && typeof raw.titled !== "boolean") return bad;
      // shape: what is being created. Absent means a note (older phones never send it).
      let shape: CreateShape = "note";
      if (raw.shape !== undefined) {
        if (raw.shape !== "note" && raw.shape !== "todo" && raw.shape !== "board") return bad;
        shape = raw.shape;
      }
      return { ok: true, value: { task: "create", prompt: raw.prompt.trim(), titled: raw.titled === true && shape === "note", shape, maxTokens } };
    }
    case "transform": {
      if (typeof raw.instruction !== "string" || !raw.instruction.trim()) return bad;
      if (typeof raw.text !== "string" || !raw.text.trim()) return bad;
      let mode: TransformMode | null = null;
      if (raw.mode !== undefined && raw.mode !== null) {
        if (raw.mode !== "edit" && raw.mode !== "continue" && raw.mode !== "ask") return bad;
        mode = raw.mode;
      }
      let before = "";
      let after = "";
      if (raw.before !== undefined || raw.after !== undefined) {
        // the note around a selection only makes sense for a selection task
        if (mode === null) return bad;
        if (raw.before !== undefined && typeof raw.before !== "string") return bad;
        if (raw.after !== undefined && typeof raw.after !== "string") return bad;
        before = (raw.before as string | undefined) ?? "";
        after = (raw.after as string | undefined) ?? "";
      }
      if (raw.instruction.length > LIMITS.instruction || raw.text.length > LIMITS.text) return long;
      if (before.length > LIMITS.context || after.length > LIMITS.context) return long;
      return { ok: true, value: { task: "transform", instruction: raw.instruction.trim(), text: raw.text, mode, before, after, maxTokens } };
    }
    case "chat": {
      if (typeof raw.note !== "string") return bad;
      if (raw.note.length > LIMITS.note) return long;
      if (!Array.isArray(raw.messages) || raw.messages.length < 1) return bad;
      if (raw.messages.length > LIMITS.turns) return long;
      const turns: { role: "user" | "assistant"; content: string }[] = [];
      for (const t of raw.messages) {
        if (!plain(t) || (t.role !== "user" && t.role !== "assistant") || typeof t.content !== "string") return bad;
        if (!t.content.trim()) return bad;
        if (t.content.length > LIMITS.turn) return long;
        turns.push({ role: t.role, content: t.content });
      }
      if (turns[turns.length - 1].role !== "user") return bad;
      return { ok: true, value: { task: "chat", note: raw.note, messages: turns, maxTokens } };
    }
    default:
      return bad;
  }
}

const CREATE_SYSTEM =
  "You are the writing assistant inside a note-taking app. Write the note the user asks for. " +
  "Use plain text with simple Markdown (short headings, bullet lists) where it helps. " +
  "Reply in the language of the request. Output only the note itself: no preamble, no closing remarks.";

// a note for the app to file: the first line is its title (round G, the landing page's "Create with AI")
const CREATE_NOTE_SYSTEM =
  "You write notes inside a note-taking app. Write the note the user asks for. " +
  "Reply in exactly this shape: the first line is a short title (at most 8 words, plain text: no #, no quotes), then one empty line, then the note itself. " +
  "In the note use plain paragraphs, lines that start with '- ' for bullet lists, lines that start with '1. ' for numbered lists, and **bold** for emphasis; no tables and no # headings. " +
  "Reply in the language of the request. No preamble and no closing remarks.";

// the original, context-free transform (Settings -> AI "Edit text")
const TRANSFORM_SYSTEM =
  "You edit text inside a note-taking app. Apply the user's instruction to the text they give you. " +
  "Keep the original language unless told otherwise. Output only the resulting text: no preamble, no explanation.";

const SELECTION_NOTE =
  "The whole note is shown for context, with the selection between [[SELECTION]] and [[/SELECTION]]. " +
  "A line that is only […] means the note continues there.";

const EDIT_SYSTEM =
  "You edit a selected part of a note inside a note-taking app. Apply the user's instruction to the SELECTION only. " +
  SELECTION_NOTE +
  " The rest of the note is only there so you understand it: never repeat it and never change it. " +
  "Keep the language, voice and style of the note unless the instruction says otherwise. " +
  "Output ONLY the replacement for the selection, as plain text without Markdown: no preamble, no explanation, " +
  "no quotation marks around it, and no [[SELECTION]] markers.";

const CONTINUE_SYSTEM =
  "You continue a note inside a note-taking app. " +
  SELECTION_NOTE +
  " Write the text that comes right after the selection, following the user's instruction, in the same language, voice and style as the note. " +
  "Output ONLY the new text, as plain text without Markdown: do not repeat the selection or the rest of the note, " +
  "and add no preamble, no explanation and no [[SELECTION]] markers.";

// The line formats below are read by the phone (src/lib/utils/aiStructured.ts), which is tolerant of what a small model
// gets wrong but cannot guess a format it was not told: change one side and change the other.
//
// A small model copies an EXAMPLE far more faithfully than it obeys a rule, so each prompt states the rules as a numbered
// list AND shows an example that does everything the rules ask (every step has a description; every node has an arrow).
// The size limits are chosen to fit the output budget (max_output, 900 tokens by default) with room to spare: the
// links / the last steps are the part a cut-off answer loses first.
const CREATE_TODO_SYSTEM =
  "You write to-do lists inside a note-taking app. Reply in exactly this line format and nothing else:\n" +
  "TITLE: a short title\n" +
  "## Category name\n" +
  "- Step :: Description of how to do it\n" +
  "- Another step :: Description of how to do it\n" +
  "Rules:\n" +
  "1. The first line is TITLE:. Then 2 to 4 categories. Each category is a line '## Name' followed by 2 to 4 steps, one step per line starting with '- '. At most 12 steps in all.\n" +
  "2. EVERY step line has two parts separated by ' :: ': the step itself (an action of at most 8 words) and then its description (5 to 15 words) that says how to do it, what to watch out for, or what done looks like. " +
  "A step line without ' :: ' and a description is wrong. Never leave a description out and never just repeat the step in it.\n" +
  "3. Plain text only: no numbering, no checkboxes, no bold, no tables, no other Markdown. The words TITLE and the ##, - and :: markers stay as shown; everything else is in the language of the request. " +
  "No introduction and no closing remarks.\n" +
  "Example:\n" +
  "TITLE: Plan a camping weekend\n" +
  "## Before you go\n" +
  "- Book the campsite :: Check the check-in time and ask whether campfires are allowed.\n" +
  "- Pack the tent :: Count the pegs and put the poles up once at home so nothing is missing.\n" +
  "## At the site\n" +
  "- Set up the tent :: Choose flat ground away from the water and turn the door away from the wind.\n" +
  "- Cook dinner :: Keep the stove on bare ground and have a bottle of water close by.";

const CREATE_BOARD_SYSTEM =
  "You build boards (idea maps) inside a note-taking app. A board is boxes (nodes) joined by arrows (links). Reply in exactly this line format and nothing else:\n" +
  "TITLE: a short title\n" +
  "NODE a: Short label :: short detail\n" +
  "NODE b: Another label :: short detail\n" +
  "LINK a -> b\n" +
  "LINK a -> c\n" +
  "Rules:\n" +
  "1. The first line is TITLE:.\n" +
  "2. Then 6 to 12 NODE lines, one per box. Each has a short unique key of letters or digits (a, b, c, ...), a label of at most 5 words, then ' :: ' and a detail of at most 12 words.\n" +
  "3. After ALL the NODE lines come the LINK lines, one per arrow. The LINK lines are required: a board without them is wrong. 'LINK a -> b' means b follows from a (b comes after a, depends on a, or is part of a). " +
  "Write at least as many LINK lines as there are NODE lines minus one.\n" +
  "4. Every node must appear in at least one LINK line, as the start or as the end, so no box is left alone. Start from the main idea and branch out: one node may have several arrows leaving it and several arriving at it. " +
  "Use only keys you defined and never link a node to itself.\n" +
  "5. Plain text only: no positions, no colours, no Markdown. The words TITLE, NODE and LINK, the keys, '::' and '->' stay as shown; the labels and details are in the language of the request. " +
  "No introduction and no closing remarks.\n" +
  "Example:\n" +
  "TITLE: Launch a podcast\n" +
  "NODE a: Pick a topic :: Choose what the show is about and who it is for\n" +
  "NODE b: Plan episodes :: Outline the first five episodes\n" +
  "NODE c: Get equipment :: A microphone and a quiet room\n" +
  "NODE d: Record :: Tape the first episode\n" +
  "NODE e: Edit :: Cut mistakes and add music\n" +
  "NODE f: Publish :: Upload to a hosting site\n" +
  "LINK a -> b\n" +
  "LINK a -> c\n" +
  "LINK b -> d\n" +
  "LINK c -> d\n" +
  "LINK d -> e\n" +
  "LINK e -> f";

// Said again right after the request, where a small model pays the most attention (it forgets rules it read far above).
const TODO_REMINDER = "\n\n(Answer in the line format. Every step line must end with ' :: ' and a short description.)";
const BOARD_REMINDER = "\n\n(Answer in the line format. After the NODE lines write the LINK lines (LINK a -> b) so that every node is connected.)";

const ASK_SYSTEM =
  "You answer a question about a selected part of a note inside a note-taking app. " +
  SELECTION_NOTE +
  " Answer from the note; if the answer is not in it, say so briefly. Be concise, plain text without Markdown, and reply in the language of the question.";

const CHAT_SYSTEM =
  "You answer questions about one note in a note-taking app. The note is between the NOTE markers; if it has several pages, each starts with a line like --- Page 2 ---. " +
  "A line that is only […] means part of the note was left out. " +
  "Answer from the note; if the answer is not in it, say so briefly. " +
  "Be concise, use plain text (no Markdown headings or tables; short lines starting with '- ' are fine) and reply in the user's language.";

export function temperatureFor(req: RunRequest): number {
  switch (req.task) {
    case "create":
      return req.shape === "note" ? 0.7 : 0.4; // a format to follow wants less wandering than a story does
    case "transform":
      return req.mode === "continue" ? 0.6 : req.mode === "ask" ? 0.5 : 0.3;
    case "chat":
      return 0.5;
  }
}

// ---------------------------------------------------------------- selection context

/** Keeps a note's own text from forging the selection markers. */
export function defuse(s: string): string {
  return s.replace(/\[\[(\/?)SELECTION\]\]/gi, "[ [$1SELECTION] ]");
}

function headBytes(s: string, max: number): string {
  if (max <= 0) return "";
  let used = 0;
  let out = "";
  for (const ch of s) {
    const b = utf8Bytes(ch);
    if (used + b > max) break;
    used += b;
    out += ch;
  }
  return out;
}

function tailBytes(s: string, max: number): string {
  if (max <= 0) return "";
  const chars = Array.from(s);
  let used = 0;
  let start = chars.length;
  while (start > 0) {
    const b = utf8Bytes(chars[start - 1]);
    if (used + b > max) break;
    used += b;
    start--;
  }
  return chars.slice(start).join("");
}

const SNAP = 40; // how far a cut may move to land on a word boundary
const CUT_MARK_BYTES = 16; // "[…]\n" + "\n[…]" is 12 bytes; 4 spare for rounding

export interface ContextWindow {
  before: string;
  after: string;
  cutBefore: boolean;
  cutAfter: boolean;
}

/**
 * Fits the note text around a selection into `availBytes`, keeping what is NEAREST the selection.
 * The side that needs less keeps all of it and the other side gets the rest; cuts land on a word
 * boundary when one is close.
 */
export function windowContext(before: string, after: string, availBytes: number): ContextWindow {
  const avail = Math.max(0, Math.floor(availBytes));
  const bb = utf8Bytes(before);
  const ab = utf8Bytes(after);
  if (bb + ab <= avail) return { before, after, cutBefore: false, cutAfter: false };
  const half = Math.floor(avail / 2);
  let keepB: number;
  let keepA: number;
  if (bb <= half) {
    keepB = bb;
    keepA = avail - bb;
  } else if (ab <= half) {
    keepA = ab;
    keepB = avail - ab;
  } else {
    keepB = half;
    keepA = avail - half;
  }
  let b = before;
  let a = after;
  let cutBefore = false;
  let cutAfter = false;
  if (bb > keepB) {
    cutBefore = true;
    b = tailBytes(before, keepB);
    const m = /\s/.exec(b.slice(0, SNAP));
    if (m && b.length > m.index + 1) b = b.slice(m.index + 1);
  }
  if (ab > keepA) {
    cutAfter = true;
    a = headBytes(after, keepA);
    const tail = a.slice(Math.max(0, a.length - SNAP));
    const idx = Math.max(tail.lastIndexOf(" "), tail.lastIndexOf("\n"), tail.lastIndexOf("\t"));
    if (idx > 0) a = a.slice(0, a.length - tail.length + idx);
  }
  return { before: b, after: a, cutBefore, cutAfter };
}

// ---------------------------------------------------------------- chat: the note and the conversation

/** The part of the input budget the conversation so far may take; the note gets the rest. */
const HISTORY_SHARE = 0.4;

function turnTokens(content: string): number {
  return Math.ceil(utf8Bytes(content) / 2) + 8; // the same arithmetic as estimateTokens
}

/**
 * The newest turns that fit `budgetTokens` (always at least the last one: that is the question), starting with a
 * person's turn. Older turns are forgotten rather than refusing the request.
 */
export function windowTurns<T extends { role: "user" | "assistant"; content: string }>(turns: T[], budgetTokens: number): T[] {
  const kept: T[] = [];
  let used = 0;
  for (let i = turns.length - 1; i >= 0; i--) {
    const cost = turnTokens(turns[i].content);
    if (kept.length > 0 && used + cost > budgetTokens) break;
    kept.unshift(turns[i]);
    used += cost;
  }
  while (kept.length > 1 && kept[0].role === "assistant") kept.shift();
  return kept;
}

/** A note too big for its share: its start and its end are kept (60 / 40), the middle becomes "[…]". */
export function windowNote(note: string, availBytes: number): string {
  const avail = Math.max(0, Math.floor(availBytes));
  if (utf8Bytes(note) <= avail) return note;
  const headBudget = Math.floor(avail * 0.6);
  let head = headBytes(note, headBudget);
  let tail = tailBytes(note, avail - headBudget);
  const tailSnap = /\s/.exec(tail.slice(0, SNAP));
  if (tailSnap && tail.length > tailSnap.index + 1) tail = tail.slice(tailSnap.index + 1);
  const headTail = head.slice(Math.max(0, head.length - SNAP));
  const idx = Math.max(headTail.lastIndexOf(" "), headTail.lastIndexOf("\n"), headTail.lastIndexOf("\t"));
  if (idx > 0) head = head.slice(0, head.length - headTail.length + idx);
  return `${head}\n[…]\n${tail}`;
}

function chatMessages(req: Extract<RunRequest, { task: "chat" }>): ChatMessage[] {
  const system = (note: string) => `${CHAT_SYSTEM}\n\n--- NOTE ---\n${note}\n--- END NOTE ---`;
  const history = windowTurns(req.messages, Math.floor(INPUT_TOKEN_CEILING * HISTORY_SHARE));
  const turns = history.map((m) => ({ role: m.role, content: m.content }) as ChatMessage);
  const base = estimateTokens([{ role: "system", content: system("") }, ...turns]);
  const avail = Math.max(0, (INPUT_TOKEN_CEILING - base) * 2 - CUT_MARK_BYTES);
  return [{ role: "system", content: system(windowNote(req.note, avail)) }, ...turns];
}

function selectionMessages(system: string, label: string, req: Extract<RunRequest, { task: "transform" }>, w: ContextWindow): ChatMessage[] {
  const note =
    (w.cutBefore ? "[…]\n" : "") +
    defuse(w.before) +
    "[[SELECTION]]" +
    defuse(req.text) +
    "[[/SELECTION]]" +
    defuse(w.after) +
    (w.cutAfter ? "\n[…]" : "");
  return [
    { role: "system", content: system },
    { role: "user", content: `${label}: ${req.instruction}\n\nNOTE:\n${note}` },
  ];
}

export function buildMessages(req: RunRequest): ChatMessage[] {
  switch (req.task) {
    case "create":
      return [
        { role: "system", content: req.shape === "todo" ? CREATE_TODO_SYSTEM : req.shape === "board" ? CREATE_BOARD_SYSTEM : req.titled ? CREATE_NOTE_SYSTEM : CREATE_SYSTEM },
        { role: "user", content: req.prompt + (req.shape === "todo" ? TODO_REMINDER : req.shape === "board" ? BOARD_REMINDER : "") },
      ];
    case "transform": {
      if (req.mode === null) {
        return [
          { role: "system", content: TRANSFORM_SYSTEM },
          { role: "user", content: `Instruction: ${req.instruction}\n\nText:\n${req.text}` },
        ];
      }
      const system = req.mode === "edit" ? EDIT_SYSTEM : req.mode === "continue" ? CONTINUE_SYSTEM : ASK_SYSTEM;
      const label = req.mode === "ask" ? "Question" : "Instruction";
      const base = estimateTokens(selectionMessages(system, label, req, { before: "", after: "", cutBefore: false, cutAfter: false }));
      // estimateTokens counts utf-8 bytes / 2, so the spare tokens are worth twice as many bytes; the two
      // "[…]" cut marks (12 bytes) and rounding are not in `base`, so room is kept for them
      const avail = Math.max(0, (INPUT_TOKEN_CEILING - base) * 2 - CUT_MARK_BYTES);
      return selectionMessages(system, label, req, windowContext(req.before, req.after, avail));
    }
    case "chat":
      return chatMessages(req);
  }
}

// ---------------------------------------------------------------- tidying the model's answer

const OPEN_MARK = "[[SELECTION]]";
const CLOSE_MARK = "[[/SELECTION]]";

/**
 * Small models add things nobody asked for around a rewrite. This removes the common ones from an
 * edit/continue answer (echoed markers, a code fence around everything, "Here is the text:", quotes
 * around everything, **bold** the note never had) and leaves the rest untouched. Ask answers and the
 * older context-free tasks are only trimmed. It never invents or rewrites words.
 */
const FENCED = /^```[A-Za-z0-9_-]*[ \t]*\n([\s\S]*?)\n?```$/;
const PREAMBLE = /^(?:(?:sure|certainly|of course|okay|ok|absolutely)[!,.]?\s+)?(?:here(?:'s| is| are)|below is)\b[^\n]{0,100}:[ \t]*\n+/i;
const BOLD = /\*\*([^*\n]+?)\*\*/g;

export function cleanReply(req: RunRequest, raw: string): string {
  let t = raw.trim();
  // a titled note keeps its Markdown (the phone turns it into real formatting); only the wrapping goes
  if (req.task === "create") {
    // a todo or board answer is read by the phone line by line; only a fence around it and a lead-in line are taken off
    if (!req.titled && req.shape === "note") return t;
    const f = FENCED.exec(t);
    if (f) t = f[1].trim();
    return t.replace(PREAMBLE, "").trim();
  }
  // a chat answer is shown as plain text, so bold markers are removed
  if (req.task === "chat") return t.replace(BOLD, "$1");
  if (req.task !== "transform" || req.mode === null || req.mode === "ask") return t;

  const open = t.indexOf(OPEN_MARK);
  const close = t.indexOf(CLOSE_MARK);
  if (open !== -1 && close > open) t = t.slice(open + OPEN_MARK.length, close);
  else t = t.split(OPEN_MARK).join("").split(CLOSE_MARK).join("");
  t = t.trim();

  const fenced = FENCED.exec(t);
  if (fenced) t = fenced[1].trim();

  t = t.replace(PREAMBLE, "").trim();

  const src = req.text.trimStart();
  const pairs: [string, string][] = [
    ['"', '"'],
    ["\u201C", "\u201D"],
  ];
  for (const [l, r] of pairs) {
    if (t.length >= 2 && t.startsWith(l) && t.endsWith(r) && !src.startsWith(l)) {
      const inner = t.slice(1, -1);
      if (!inner.includes(l) && !inner.includes(r)) t = inner.trim();
      break;
    }
  }

  if (!req.text.includes("**")) t = t.replace(BOLD, "$1");

  if (req.mode === "continue") {
    const sel = req.text.trim();
    if (sel && t.startsWith(sel) && t.length > sel.length) t = t.slice(sel.length).trimStart();
  }
  return t.trim();
}

/** The label the ledger keeps for a request (what the credits were spent on): the task, and what a "create" made. */
export function featureFor(req: RunRequest): string {
  return req.task === "create" && req.shape !== "note" ? `create-${req.shape}` : req.task;
}
