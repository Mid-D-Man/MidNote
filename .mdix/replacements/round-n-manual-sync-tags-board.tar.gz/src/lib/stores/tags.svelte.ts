// Known-tag registry, reactive. Mirrors mdix_files/schema/tags.mdix.
// sync() is called explicitly from +page.svelte after entries.svelte.ts's
// first-run seeding runs, rather than relying on module-evaluation order
// between the two stores to happen to land tags after entries.
import * as storage from "$lib/storage";
import type { TagScope } from "$lib/storage";
import { isSystemTag, withSystemTags } from "$lib/utils/systemTags";
import { untrack } from "svelte";

export const noteTags = $state<string[]>([]);
export const todoTags = $state<string[]>([]);
export const boardTags = $state<string[]>([]);

export function sync() {
  // Same defensive fix as entries.svelte.ts's refresh() and
  // log.svelte.ts's addLog() — reads noteTags.length/todoTags.length then
  // writes those same arrays via splice. Currently only ever called from
  // onMount (not a tracked context, so not live today), but untrack here
  // means it stays safe even if a future effect calls it.
  untrack(() => {
    const known = storage.loadKnownTags();
    // the built-in tags (utils/systemTags.ts) are merged in here, ahead of the person's own: they are always listed
    noteTags.splice(0, noteTags.length, ...withSystemTags("notes", known.notes));
    todoTags.splice(0, todoTags.length, ...withSystemTags("todos", known.todos));
    boardTags.splice(0, boardTags.length, ...withSystemTags("boards", known.boards));
  });
}

export function registerTag(kind: TagScope, tag: string) {
  storage.addKnownTag(kind, tag);
  sync();
}

export function unregisterTag(kind: TagScope, tag: string) {
  // a built-in tag can't be taken off the list (an entry can still lose it: that is a different action)
  if (isSystemTag(tag, kind)) return;
  storage.removeKnownTag(kind, tag);
  sync();
}

// ---- Shared tags ----
// A shared tag is simply one that is in ALL THREE lists (Notes, Todos, Boards), so Settings -> Tags can add or remove it
// once for every list. Nothing new is stored: it is the same per-list registry (storage.ts known tags), so backup, restore
// and the phone's own files need no change. The built-in tags are not "shared" in this sense (they are merged in).
const SCOPES: readonly TagScope[] = ["notes", "todos", "boards"];

/** Is `tag` (not built in) in every list? Reads the reactive lists, so it is live inside templates and $derived. */
export function isSharedTag(tag: string): boolean {
  return !isSystemTag(tag) && noteTags.includes(tag) && todoTags.includes(tag) && boardTags.includes(tag);
}

/** Add `tag` to all three lists. Returns "added" (new), "completed" (it was in some lists: now in all), "exists" (already
 *  shared) or "built-in" (that name is a built-in tag, which is already in the lists it belongs in: nothing is added). */
export function registerSharedTag(tag: string): "added" | "completed" | "exists" | "built-in" {
  if (isSystemTag(tag)) return "built-in";
  const before = SCOPES.filter((s) => storage.loadKnownTags()[s].includes(tag)).length;
  if (before === SCOPES.length) return "exists";
  for (const s of SCOPES) storage.addKnownTag(s, tag);
  sync();
  return before === 0 ? "added" : "completed";
}

/** Take `tag` off all three lists (items that already carry it keep it). */
export function unregisterSharedTag(tag: string): void {
  if (isSystemTag(tag)) return;
  for (const s of SCOPES) storage.removeKnownTag(s, tag);
  sync();
}
