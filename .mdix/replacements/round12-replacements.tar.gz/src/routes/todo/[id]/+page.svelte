<script lang="ts">
  import { page } from "$app/stores";
  import { goto, onNavigate } from "$app/navigation";
  import { onMount, untrack } from "svelte";
  import TodoHeader from "$lib/components/todos/TodoHeader/TodoHeader.svelte";
  import TodoCategoryTabs from "$lib/components/todos/TodoCategoryTabs/TodoCategoryTabs.svelte";
  import TodoStepsSection from "$lib/components/todos/TodoStepsSection/TodoStepsSection.svelte";
  import TodoAnnotationsSidebar from "$lib/components/todos/TodoAnnotationsSidebar/TodoAnnotationsSidebar.svelte";
  import { saveEntry } from "$lib/stores/entries.svelte";
  import { todoTags, sync as syncTags } from "$lib/stores/tags.svelte";
  import { createTodo, getEntry, generateId } from "$lib/storage";
  import { breadcrumb } from "$lib/debug/log.svelte";
  import { unlockForSession, relockSilently } from "$lib/utils/lockFlow";
  import { resolveTheme, hexToRgba } from "$lib/utils/themePalette";
  import { customThemes } from "$lib/stores/customThemes.svelte";
  import Spinner from "$lib/components/ui/Spinner/Spinner.svelte";
  import type { LockKeyMode, Todo } from "$lib/types/entry";

  const id = $derived($page.params.id);

  let todo = $state<Todo>(createTodo());
  let currentCategory = $state("Steps");
  let notesOpen = $state(false);
  let loadError = $state<string | null>(null);

  onMount(() => {
    breadcrumb(`todo page mounted, id=${id}`);
    syncTags();
    load();
  });

  // SECURITY FIX — same issue and same fix as note/[id]/+page.svelte's
  // identical relockCreds/onNavigate pair; see that file's comment for
  // the full reasoning. Short version: opening a locked todo used to
  // call the PERMANENT unlock (same one the kebab menu's "Unlock" uses)
  // just to view it, and nothing ever put the lock back. handleUnlock
  // below now uses the session-scoped unlockForSession() instead, and
  // this hook silently re-locks with the same password/mode the moment
  // the user navigates away.
  let relockCreds = $state<{ entry: Todo; password: string; mode: LockKeyMode } | null>(null);

  onNavigate(async () => {
    const creds = relockCreds;
    if (!creds) return;
    relockCreds = null;
    if (!getEntry(creds.entry.id)) return; // deleted from inside the editor — nothing to relock
    await relockSilently(creds.entry, creds.password, creds.mode);
  });

  $effect(() => {
    breadcrumb(`todo page effect: id=${id}`);
    load();
  });

  function load() {
    try {
      loadError = null;
      if (!id || id === "new") {
        todo = createTodo();
        // untrack is load-bearing here, not cosmetic — this is the exact
        // bug that caused the hang. load() runs inside the $effect below,
        // which also WRITES `todo` (the reassignment above). Reading
        // todo.categories right after, untracked, makes `todo` a
        // dependency of that same effect — an effect that both reads and
        // writes what it depends on re-triggers itself forever in
        // Svelte 5. Reproduced this exact shape against the real Svelte
        // runtime: unfixed throws effect_update_depth_exceeded within
        // milliseconds, fixed settles after one run.
        currentCategory = untrack(() => todo.categories[0]) ?? "Steps";
        breadcrumb("todo: created new");
        return;
      }
      const existing = getEntry(id);
      if (existing && existing.type === "todo") {
        todo = existing;
        currentCategory = untrack(() => todo.categories[0]) ?? "Steps";
        breadcrumb(
          `todo: loaded ${id}, ${untrack(() => todo.steps.length)} steps, ${untrack(() => todo.categories.length)} categories`
        );
      } else {
        breadcrumb(`todo: ${id} not found or wrong type, redirecting home`);
        goto("/");
      }
    } catch (err) {
      console.error("todo page: load() threw:", err);
      loadError = err instanceof Error ? err.message : String(err);
    }
  }

  function persist() {
    if (!todo.title.trim() && todo.steps.length === 0) return;
    saveEntry(todo);
  }

  function setTags(tags: string[]) {
    todo.tags = tags;
    persist();
  }

  function addCategory(name: string) {
    if (!todo.categories.includes(name)) {
      todo.categories.push(name);
      currentCategory = name;
      persist();
    }
  }

  function removeCategory(name: string) {
    todo.categories = todo.categories.filter((c) => c !== name);
    todo.steps = todo.steps.filter((s) => s.category !== name);
    todo.annotations = todo.annotations.filter((a) => a.category !== name);
    persist();
  }

  function addStep() {
    todo.steps.push({ id: generateId(), category: currentCategory, title: "", content: "" });
    persist();
  }

  function updateStep(stepId: string, title: string, content: string) {
    const step = todo.steps.find((s) => s.id === stepId);
    if (!step) return;
    step.title = title;
    step.content = content;
    persist();
  }

  function deleteStep(stepId: string) {
    todo.steps = todo.steps.filter((s) => s.id !== stepId);
    persist();
  }

  function addAnnotation(category: string) {
    todo.annotations.push({ id: generateId(), category, title: "", content: "" });
    persist();
  }

  function updateAnnotation(annotationId: string, title: string, content: string) {
    const a = todo.annotations.find((x) => x.id === annotationId);
    if (!a) return;
    a.title = title;
    a.content = content;
    persist();
  }

  function deleteAnnotation(annotationId: string) {
    todo.annotations = todo.annotations.filter((a) => a.id !== annotationId);
    persist();
  }

  const stepsForCategory = $derived(todo.steps.filter((s) => s.category === currentCategory));

  let unlocking = $state(false);
  async function handleUnlock() {
    unlocking = true;
    try {
      const result = await unlockForSession(todo);
      // See note/[id]/+page.svelte's identical handleUnlock comment —
      // capturing `todo` itself (not just the credentials) means the
      // onNavigate hook above re-locks the right object even if `todo`
      // has since been reassigned to a different loaded todo.
      if (result) relockCreds = { entry: todo, password: result.password, mode: result.mode };
    } finally {
      unlocking = false;
    }
  }

  // Same reasoning as note/[id]/+page.svelte's identical bodyStyle —
  // see that file's comment for the full design (opaque text panel,
  // not raw compositing over the photo).
  const resolvedBodyTheme = $derived(resolveTheme(todo.bodyTheme, customThemes));
  const bodyStyle = $derived(
    resolvedBodyTheme.kind === "color"
      ? `background: ${hexToRgba(resolvedBodyTheme.color, 0.14)};`
      : resolvedBodyTheme.kind === "image"
        ? `background-image: url(${resolvedBodyTheme.dataUrl}); background-size: cover; background-position: center; background-attachment: fixed;`
        : "",
  );
  const bodyHasImage = $derived(resolvedBodyTheme.kind === "image");
</script>

<svelte:head>
  <title>{todo.title || "Untitled"} — MidNote</title>
</svelte:head>

<main class="todo-page">
  {#if loadError}
    <div class="error-state">
      <p><strong>Something went wrong opening this todo.</strong></p>
      <p class="error-detail">{loadError}</p>
      <button onclick={() => goto("/")}>Back to MidNote</button>
    </div>
  {:else}
  <TodoHeader
    {todo}
    availableTags={todoTags}
    onTagsChange={setTags}
    onSave={persist}
    onBack={() => goto("/")}
    onShowNotes={() => (notesOpen = true)}
  />

  {#if todo.encrypted}
    <div class="locked-state">
      <div class="lock-icon" aria-hidden="true">
        <svg viewBox="0 0 24 24" width="40" height="40" fill="none" stroke="currentColor" stroke-width="1.5">
          <rect x="3" y="11" width="18" height="11" rx="2" /><path d="M7 11V7a5 5 0 0 1 9.9-1" />
        </svg>
      </div>
      <p><strong>This todo is locked.</strong></p>
      <p class="locked-detail">Unlock it to view or edit its steps.</p>
      <button class="unlock-btn" onclick={handleUnlock} disabled={unlocking}>
        {#if unlocking}
          <Spinner class="unlock-spinner" />
        {/if}
        {unlocking ? "Unlocking…" : "Unlock"}
      </button>
    </div>
  {:else}
    <div class="title-row">
      <input
        type="text"
        bind:value={todo.title}
        onblur={persist}
        placeholder="Todo title..."
        class="todo-title"
      />
    </div>

    <TodoCategoryTabs
      categories={todo.categories}
      {currentCategory}
      onCategoryChange={(c) => (currentCategory = c)}
      onAddCategory={addCategory}
      onRemoveCategory={removeCategory}
    />

    <div class="body" style={bodyStyle}>
      <div class="inner" class:inner-panel={bodyHasImage}>
        <TodoStepsSection
          steps={stepsForCategory}
          category={currentCategory}
          onAddStep={addStep}
          onUpdateStep={updateStep}
          onDeleteStep={deleteStep}
        />
      </div>
    </div>

    <TodoAnnotationsSidebar
      bind:open={notesOpen}
      annotations={todo.annotations}
      {currentCategory}
      onAddAnnotation={addAnnotation}
      onUpdateAnnotation={updateAnnotation}
      onDeleteAnnotation={deleteAnnotation}
    />
  {/if}
  {/if}
</main>

<style>
  .todo-page {
    display: flex;
    flex-direction: column;
    height: 100dvh;
    max-width: 100vw;
    overflow-x: hidden;
    background: var(--bg);
  }
  .title-row {
    flex-shrink: 0;
    padding: 0 var(--space-4);
    border-bottom: 1px solid var(--hairline);
    background: var(--surface);
  }
  .todo-title {
    width: 100%;
    box-sizing: border-box;
    font-family: var(--font-display);
    font-size: 18px;
    font-weight: 600;
    color: var(--text-hi);
    background: transparent;
    border: none;
    padding: var(--space-3) 0;
  }
  .todo-title::placeholder {
    color: var(--text-faint);
  }
  .todo-title:focus {
    outline: none;
  }
  .body {
    flex: 1;
    min-height: 0;
    overflow: hidden;
  }
  /* Neutral flex passthrough for the "no theme"/color cases — same
     effective layout TodoStepsSection had as .body's direct child
     before this wrapper existed. .inner-panel is purely additive for
     the image case; see note/[id]/+page.svelte's .inner-panel comment
     for the general reasoning (legible backing over a photo).

     BUGFIX: this used to inset itself with `margin: var(--space-3)`
     plus a drop shadow — a real shrink of the steps list's available
     space compared to the color/none case, and unlike notes' 680px
     .inner there's no max-width slack here to expand into as
     compensation (.body already fills 100% of the page either way, no
     side margins to invisibly eat into). So instead of shrinking to
     make room for a floating card look, this now stays exactly the
     same full-.body footprint as the color/none case always has — just
     a translucent wash over the photo, edge-to-edge, rather than an
     inset card — which is what actually keeps the writing/steps area
     consistent regardless of theme kind. The margin and drop shadow
     both depended on that inset gap to mean anything (a shadow needs
     space to fall into; there isn't any once the panel is flush) so
     both are gone, not just the margin. */
  .inner {
    height: 100%;
    display: flex;
    flex-direction: column;
    min-height: 0;
  }
  .inner.inner-panel {
    background: rgba(var(--surface-rgb), 0.93);
  }
  .error-state {
    flex: 1;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: var(--space-3);
    padding: var(--space-5);
    text-align: center;
  }
  .error-state p {
    color: var(--text-hi);
    margin: 0;
  }
  .error-detail {
    font-family: var(--font-mono);
    font-size: 12px;
    color: var(--text-lo);
  }
  .error-state button {
    margin-top: var(--space-3);
    padding: var(--space-2) var(--space-4);
    background: var(--accent);
    color: var(--bg);
    border: none;
    border-radius: var(--radius-sm);
    font-weight: 500;
    cursor: pointer;
  }
  .locked-state {
    flex: 1;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: var(--space-2);
    padding: var(--space-5);
    text-align: center;
  }
  .lock-icon {
    color: var(--text-faint);
    margin-bottom: var(--space-2);
  }
  .locked-state p {
    color: var(--text-hi);
    margin: 0;
  }
  .locked-state p.locked-detail {
    color: var(--text-lo);
    font-size: 13px;
  }
  .unlock-btn {
    margin-top: var(--space-3);
    padding: var(--space-2) var(--space-5);
    background: var(--accent);
    color: var(--bg);
    border: none;
    border-radius: var(--radius-sm);
    font-weight: 500;
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: var(--space-2);
  }
  .unlock-btn:disabled {
    opacity: 0.6;
    cursor: default;
  }
  /* Same reasoning as note/[id]/+page.svelte's identical override —
     see that file's comment for why plain opacity, not color-mix(). */
  :global(.unlock-spinner) {
    width: 16px !important;
    height: 16px !important;
  }
  :global(.unlock-spinner circle) {
    stroke: var(--bg);
    opacity: 0.35;
  }
  :global(.unlock-spinner path) {
    stroke: var(--bg);
  }
</style>
