// App-wide display/behavior settings.
//
// fontSize: the note body's BASE size — the default a note starts at
// and what the size picker falls back to when the caret isn't sitting
// inside a locally-overridden span. It is NOT what the formatting
// toolbar's size buttons write to anymore — those apply a per-selection
// / per-typing-position override instead (see richText.ts's
// applyFontSize), which is the actual fix for "changing the size
// changed the whole note" rather than just the part being edited.
//
// debugPanelVisible: whether the floating debug panel (see
// components/debug/DebugPanel.svelte) renders at all. Global capture
// (console.error/warn interception, breadcrumbs) always keeps running
// regardless of this — it's cheap and the history since app start stays
// useful if this gets flipped back on — only the panel's own UI is
// gated by it. Surfaced from the burger menu's Settings sheet.
const FONT_SIZE_KEY = "midnote:font-size";
const DEFAULT_SIZE = 15;
const SIZES = [10, 12, 14, 15, 16, 18, 20, 24] as const;

function loadFontSize(): number {
  if (typeof localStorage === "undefined") return DEFAULT_SIZE;
  const raw = localStorage.getItem(FONT_SIZE_KEY);
  const n = raw ? parseInt(raw, 10) : NaN;
  return SIZES.includes(n as (typeof SIZES)[number]) ? n : DEFAULT_SIZE;
}

export const fontSize = $state({ value: loadFontSize() });

export function setFontSize(size: number) {
  fontSize.value = size;
  if (typeof localStorage !== "undefined") localStorage.setItem(FONT_SIZE_KEY, String(size));
}

export const FONT_SIZES = SIZES;

const DEBUG_PANEL_KEY = "midnote:debug-panel-visible";

function loadDebugPanelVisible(): boolean {
  if (typeof localStorage === "undefined") return true;
  const raw = localStorage.getItem(DEBUG_PANEL_KEY);
  // No stored value yet -> default ON, matching the panel's current
  // always-on behavior so existing on-device debugging workflow doesn't
  // silently change until someone actually opens Settings and flips it.
  return raw === null ? true : raw === "true";
}

export const debugPanelVisible = $state({ value: loadDebugPanelVisible() });

export function setDebugPanelVisible(visible: boolean) {
  debugPanelVisible.value = visible;
  if (typeof localStorage !== "undefined") localStorage.setItem(DEBUG_PANEL_KEY, String(visible));
}

// Ruled-paper background lines in the note editor (see NoteContent.svelte).
// Defaults OFF: it's a new, real-device-unverified visual change, safer
// to let people opt in from Settings than to change everyone's editor
// look by default.
const NOTE_LINES_KEY = "midnote:note-lines";

function loadNoteLinesEnabled(): boolean {
  if (typeof localStorage === "undefined") return false;
  return localStorage.getItem(NOTE_LINES_KEY) === "true";
}

export const noteLinesEnabled = $state({ value: loadNoteLinesEnabled() });

export function setNoteLinesEnabled(enabled: boolean) {
  noteLinesEnabled.value = enabled;
  if (typeof localStorage !== "undefined") localStorage.setItem(NOTE_LINES_KEY, String(enabled));
}

// Landing-page theme — the list/notes-and-todos page's own background,
// set from Settings. Deliberately separate from any single entry's
// headerTheme/bodyTheme (entry.ts): a note/todo's own theme, when set,
// overrides these for that one card/editor; these are just the defaults
// the landing page itself paints with. Same {kind,name,customThemeId}
// pointer shape as an entry's theme — see themePalette.ts's
// resolveTheme, which every slot (entry or app-wide) consumes
// identically.
//
// Two independent slots, matching entry.ts's header/body split:
// appHeaderTheme washes the top app-bar/view-tabs region, appBodyTheme
// washes the scrollable list background underneath it. This used to be
// one flat appTheme applied to both — split out so they can genuinely
// differ, same as a per-entry theme now can. No icon slot here: an icon
// is pinned to one specific note/todo, there's no "landing page icon"
// equivalent.
import type { ThemeRef } from "$lib/types/entry";
import { NO_THEME } from "$lib/types/entry";

const APP_THEME_KEY = "midnote:app-theme"; // old, pre-split key — read once for migration, never written again.
const APP_HEADER_THEME_KEY = "midnote:app-header-theme";
const APP_BODY_THEME_KEY = "midnote:app-body-theme";

function isValidThemeRef(v: unknown): v is ThemeRef {
  return !!v && typeof v === "object" && typeof (v as { kind?: unknown }).kind === "string";
}

function readThemeKey(key: string): ThemeRef | null {
  if (typeof localStorage === "undefined") return null;
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    return isValidThemeRef(parsed) ? parsed : null;
  } catch {
    return null;
  }
}

// Pre-split installs have `midnote:app-theme` but neither new key yet —
// that old single value was always the header/card-facing wash (same
// "old flat field IS the header slot" migration as entry.ts's theme ->
// headerTheme), so it becomes the seed for appHeaderTheme specifically,
// never appBodyTheme. Only runs once in practice: after this, both new
// keys exist and this branch is never reached again for this device.
function loadAppHeaderTheme(): ThemeRef {
  return readThemeKey(APP_HEADER_THEME_KEY) ?? readThemeKey(APP_THEME_KEY) ?? { ...NO_THEME };
}

function loadAppBodyTheme(): ThemeRef {
  return readThemeKey(APP_BODY_THEME_KEY) ?? { ...NO_THEME };
}

export const appHeaderTheme = $state<{ value: ThemeRef }>({ value: loadAppHeaderTheme() });
export const appBodyTheme = $state<{ value: ThemeRef }>({ value: loadAppBodyTheme() });

export function setAppHeaderTheme(theme: ThemeRef) {
  appHeaderTheme.value = theme;
  if (typeof localStorage !== "undefined") localStorage.setItem(APP_HEADER_THEME_KEY, JSON.stringify(theme));
}

export function setAppBodyTheme(theme: ThemeRef) {
  appBodyTheme.value = theme;
  if (typeof localStorage !== "undefined") localStorage.setItem(APP_BODY_THEME_KEY, JSON.stringify(theme));
}

// Which list tab (Notes/Todos/Boards) was showing — persisted so leaving
// to view/edit an entry and coming back lands you where you were,
// instead of always resetting to Notes. The list route (+page.svelte) is
// a separate SvelteKit page from note/[id], todo/[id] and board/[id];
// navigating to any of them and back fully unmounts and remounts it, so
// a plain local $state there can't survive the round trip on its own —
// this is the actual fix for "leaving a todo always comes back to Notes."
const ACTIVE_VIEW_KEY = "midnote:active-view";

export type ActiveView = "notes" | "todos" | "boards" | "folders";

export function loadLastActiveView(): ActiveView {
  if (typeof localStorage === "undefined") return "notes";
  const stored = localStorage.getItem(ACTIVE_VIEW_KEY);
  // Explicit allowlist rather than a cast — anything unrecognized
  // (including the value written by a build that predates a view being
  // renamed or removed) falls back to Notes instead of putting the list
  // route into a state with no matching tab.
  return stored === "todos" || stored === "boards" || stored === "folders" ? stored : "notes";
}

export function setLastActiveView(view: ActiveView) {
  if (typeof localStorage !== "undefined") localStorage.setItem(ACTIVE_VIEW_KEY, view);
}

// Round 33 — default font for the note editor. The value is a CSS
// font-family string (see utils/fonts.ts), or null for the app's normal
// sans. It is only the default: a word the user picked a font for keeps its
// own (the inline style Tiptap writes), and a deleted imported font simply
// falls through to the generic family after it.
import { sanitizeFamilyValue } from "$lib/utils/fonts";

const NOTE_FONT_KEY = "midnote:note-font";

function loadNoteFont(): string | null {
  if (typeof localStorage === "undefined") return null;
  return sanitizeFamilyValue(localStorage.getItem(NOTE_FONT_KEY));
}

export const noteFont = $state<{ value: string | null }>({ value: loadNoteFont() });

export function setNoteFont(family: string | null) {
  const clean = sanitizeFamilyValue(family);
  noteFont.value = clean;
  if (typeof localStorage === "undefined") return;
  if (clean === null) localStorage.removeItem(NOTE_FONT_KEY);
  else localStorage.setItem(NOTE_FONT_KEY, clean);
}

// Round 33 — landing-page card layout. One setting for all three tabs
// (notes, todos, boards). "list" is the long-standing one-card-per-row look
// on a phone; "grid" is two compact cards per row (more of your notes on one
// screen). Allowlisted on read, like ActiveView above, so a value written by
// some other build can never put the list into a state with no CSS.
const LIST_VIEW_KEY = "midnote:list-view";

export type ListViewMode = "list" | "grid";

function loadListViewMode(): ListViewMode {
  if (typeof localStorage === "undefined") return "list";
  return localStorage.getItem(LIST_VIEW_KEY) === "grid" ? "grid" : "list";
}

export const listViewMode = $state<{ value: ListViewMode }>({ value: loadListViewMode() });

export function setListViewMode(mode: ListViewMode) {
  listViewMode.value = mode;
  if (typeof localStorage !== "undefined") localStorage.setItem(LIST_VIEW_KEY, mode);
}
