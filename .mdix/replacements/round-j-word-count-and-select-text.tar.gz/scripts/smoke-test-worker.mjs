// Runs ONE scenario against the real production build (build/) and exits
// 1 if anything throws while it mounts and settles. Always run through
// smoke-test.mjs, which spawns this as a fresh child process per
// scenario — that isolation matters: Svelte's client runtime and every
// .svelte.ts store keep module-level singleton state, so running two
// scenarios in the same process would let state leak between them and
// produce false passes/fails. A fresh process per scenario is the only
// way to faithfully mirror "the app just launched."
//
// Not meant to be run directly — see smoke-test.mjs / npm run smoke.

import { JSDOM } from "jsdom";
import { pathToFileURL } from "node:url";
import { readdirSync, readFileSync } from "node:fs";
import { createHash } from "node:crypto";
import path from "node:path";

const BUILD_DIR = process.env.SMOKE_BUILD_DIR;
const ROUTE_PATH = process.env.SMOKE_ROUTE_PATH;
const SEED_ENTRIES = JSON.parse(process.env.SMOKE_SEED_ENTRIES || "[]");
// Round 46: extra localStorage values present before the app boots (scenario.storage).
// A preset value may contain the JSON token "__NOW__" (quotes included): it becomes the current
// time in ms when THIS scenario starts, so a fixture like {at: "__NOW__"} is never already stale
// by the time a long full run reaches it (the full suite takes well over the app's 10-minute
// limit on a pending Google sign-in).
const SEED_STORAGE = JSON.parse((process.env.SMOKE_SEED_STORAGE || "{}").replaceAll('"__NOW__"', String(Date.now())).replaceAll('\\"__NOW__\\"', String(Date.now())));
const SETTLE_MS = Number(process.env.SMOKE_SETTLE_MS || 1200);
// Optional, per-scenario — see smoke-test.mjs's SCENARIOS comment on
// `expectText` for why this exists alongside the crash-only check below:
// a route can mount and settle with zero thrown errors while still
// silently showing the wrong content (stale/reset/blank state), which
// no amount of "did it throw" checking catches.
const EXPECT_TEXT = process.env.SMOKE_EXPECT_TEXT || null;
// Optional, per-scenario — see smoke-test.mjs's SCENARIOS comment on
// `clickAriaLabel` for why this exists: mounting a route and waiting is
// the whole test above, which means nothing a user actually DOES (tap
// Save, type into a field) was ever exercised — a crash that only
// happens inside a click handler (round 24's real on-device
// DataCloneError, thrown from Save, never from mounting) sailed through
// every previous run of this file clean. This clicks one real element
// after the initial settle, matched by its exact aria-label, then waits
// again before the usual error/expectText checks run.
const CLICK_ARIA_LABEL = process.env.SMOKE_CLICK_ARIA_LABEL || null;
// Optional, per-scenario (round 26) — an ordered list of scripted
// interactions (click / type / expectSelector / expectText); see
// smoke-test.mjs's `steps` comment for the step shapes and why.
const STEPS = JSON.parse(process.env.SMOKE_STEPS || "[]");

const dom = new JSDOM("<!doctype html><html><body></body></html>", {
  url: `http://tauri.localhost${ROUTE_PATH}`,
  pretendToBeVisual: true,
  runScripts: "outside-only",
});
const w = dom.window;

if (SEED_ENTRIES.length > 0) {
  w.localStorage.setItem("midnote:entries", JSON.stringify(SEED_ENTRIES));
}
for (const [k, v] of Object.entries(SEED_STORAGE)) w.localStorage.setItem(k, String(v));

// jsdom doesn't implement IntersectionObserver; SvelteKit's link-preload
// wiring touches it during start(), so it needs at least a no-op stub.
class FakeIntersectionObserver {
  observe() {}
  unobserve() {}
  disconnect() {}
}

// jsdom also doesn't implement matchMedia. @xyflow/svelte calls it while
// constructing its store (colorMode resolution — it checks
// prefers-color-scheme), so the board route can't mount without it.
// This is a jsdom gap, NOT an app bug: matchMedia is supported in
// Android WebView and every browser this app targets, so stubbing it
// here is making the harness match reality, not papering over a real
// failure. Reports "no match" for every query, which for colorMode
// resolution means the explicit colorMode prop wins — exactly what
// happens in the real app, where that prop is always set.
function fakeMatchMedia(query) {
  return {
    matches: false,
    media: query,
    onchange: null,
    addListener() {},
    removeListener() {},
    addEventListener() {},
    removeEventListener() {},
    dispatchEvent: () => false,
  };
}
w.matchMedia = fakeMatchMedia;

// Same category as matchMedia above — jsdom has no ResizeObserver, but
// every browser this app targets (Android WebView included) does.
// @xyflow/svelte observes its own container to track the canvas size
// for pan/zoom math, so the board route can't mount without it. The
// stub never fires a callback, which is correct for this harness: it
// means the canvas keeps its initial (zero) measured size and simply
// renders nothing visible, rather than the route throwing. What's
// under test here is "does this route mount and settle without
// crashing", not layout.
class FakeResizeObserver {
  observe() {}
  unobserve() {}
  disconnect() {}
}
w.ResizeObserver = FakeResizeObserver;

// Third jsdom gap of the same kind. jsdom ships SVGElement and
// SVGGraphicsElement but NOT SVGAElement (an <a> inside an SVG) — Svelte's
// own client runtime references it while deciding how to handle an
// element's attributes, which any route rendering SVG reaches. Real
// browsers all define it. Subclassing jsdom's real SVGGraphicsElement
// rather than inventing a bare class keeps `instanceof` checks against
// the SVG hierarchy behaving correctly.
class FakeSVGAElement extends w.SVGGraphicsElement {}
w.SVGAElement = FakeSVGAElement;

// Fourth jsdom gap (round 29). jsdom implements Range but NOT
// Range.getClientRects()/getBoundingClientRect() — layout doesn't exist
// there. ProseMirror calls them whenever it scrolls the caret into view
// (any editor command chained with .focus(), e.g. the toolbar's list
// buttons), which threw "getClientRects is not a function" the first time
// a scenario tapped one. Real browsers all have them. Returning "no
// rectangles" is what a Range with no layout legitimately reports, and
// ProseMirror handles that (it falls back to the element's own box).
if (w.Range && !w.Range.prototype.getClientRects) {
  w.Range.prototype.getClientRects = function () {
    return { length: 0, item: () => null, [Symbol.iterator]: function* () {} };
  };
}
if (w.Range && !w.Range.prototype.getBoundingClientRect) {
  w.Range.prototype.getBoundingClientRect = function () {
    return { x: 0, y: 0, width: 0, height: 0, top: 0, left: 0, right: 0, bottom: 0, toJSON() {} };
  };
}

// Fifth jsdom gap (round 30): downloads. jsdom has no URL.createObjectURL,
// and clicking a real <a download> makes it attempt (and complain about) a
// navigation. Stubbed so the app's own blob-link download path runs for
// real, and each "download" is RECORDED (name + the actual Blob) for the
// `expectDownload` step to inspect — the file's real bytes, not just that
// a click happened.
w.__downloads = [];
{
  const blobsByUrl = new Map();
  let seq = 0;
  w.URL.createObjectURL = (blob) => {
    const url = `blob:smoke/${seq++}`;
    blobsByUrl.set(url, blob);
    return url;
  };
  w.URL.revokeObjectURL = () => {};
  const originalClick = w.HTMLAnchorElement.prototype.click;
  w.HTMLAnchorElement.prototype.click = function () {
    if (this.hasAttribute("download")) w.__downloads.push({ name: this.download, blob: blobsByUrl.get(this.href) });
    else originalClick.call(this);
  };
}

// Round 31: a recording stand-in for the Android notification plugin, so
// the whole Reminder sheet can be driven in jsdom (which has no Android and
// no Tauri). Installed only for scenarios that ask for it
// (SMOKE_REMINDER_BACKEND=fake); without it the app sees its real backend,
// which reports "unsupported" here — itself a scenario. Every call is
// recorded in globalThis.__reminderCalls for the expectGlobal* steps.
if (process.env.SMOKE_REMINDER_BACKEND === "fake") {
  const calls = (globalThis.__reminderCalls = []);
  globalThis.__midnoteReminderBackend = {
    supported: () => true,
    permissionState: async () => "granted",
    requestPermission: async () => "granted",
    createChannel: async () => {
      calls.push("createChannel");
    },
    // Round 44: both take lists now (a repeating reminder is several alarms). One
    // recorded line per payload for schedule, ONE line per cancel call.
    schedule: async (payloads) => {
      for (const p of payloads) calls.push(`schedule:${p.id}:${p.schedule.at.date}:${p.title}`);
    },
    cancel: async (ids) => {
      calls.push(`cancel:${ids.join(",")}`);
    },
    // Round 34: the fake never has a saved copy, so a rename leaves it alone.
    pendingTitle: async () => null,
    onTap: async () => () => {},
  };
}

// Round 34: a recording stand-in for the native share sheet (the real one is
// tauri-plugin-sharekit, Android only). SMOKE_SHARE=fake -> every shared text
// is pushed onto globalThis.__shareCalls as "native:<text>"; SMOKE_SHARE=cancel
// makes the sheet reject the way Android does when you pick an app ("Share
// cancelled"), so the "silent, no false toast" path is exercised too.
if (process.env.SMOKE_SHARE === "fake" || process.env.SMOKE_SHARE === "cancel") {
  const calls = (globalThis.__shareCalls = []);
  const cancel = process.env.SMOKE_SHARE === "cancel";
  globalThis.__midnoteShareDeps = {
    native: async (text) => {
      calls.push(`native:${text}`);
      if (cancel) throw new Error("Share cancelled");
    },
    web: null,
    clipboard: async (text) => {
      calls.push(`clipboard:${text}`);
    },
  };
}

// Round 44: a recording stand-in for the clipboard. SMOKE_COPY=fake -> every text
// "copied" is pushed onto globalThis.__copied.
if (process.env.SMOKE_COPY === "fake") {
  const copied = (globalThis.__copied = []);
  globalThis.__midnoteCopyDeps = {
    clipboard: async (text) => {
      copied.push(text);
    },
    legacy: null,
  };
}

// Round 37/41: a recording stand-in for the phone's speech engine (the real one is
// tauri-plugin-tts, Android only). SMOKE_TTS=fake -> every call is pushed onto
// globalThis.__ttsCalls as a string: "speak:<queue>:<voiceId|default>:<rate>:<text>",
// "stop". Voices: two English, one French.
// It behaves like the real engine: a "flush" speak cuts off whatever is playing, an
// "add" speak waits its turn, each piece takes PIECE_MS to say, and start / finish /
// cancel events are announced with the id speak() returned. SMOKE_TTS=fake-noevents
// is the same engine whose events never reach the app (what the phone turned out to
// do) — reading must carry on, and Resume must still know where it was, by polling.
if (process.env.SMOKE_TTS === "fake" || process.env.SMOKE_TTS === "fake-noevents") {
  const calls = (globalThis.__ttsCalls = []);
  const emitEvents = process.env.SMOKE_TTS === "fake";
  const PIECE_MS = 1500;
  let nextId = 0;
  let handler = null;
  let queue = [];
  let playing = null;
  const emit = (type, id) => {
    if (emitEvents) setTimeout(() => handler?.({ type, id }), 0);
  };
  const playNext = () => {
    if (playing || queue.length === 0) return;
    const item = (playing = queue.shift());
    emit("start", item.id);
    item.timer = setTimeout(() => {
      if (playing !== item) return;
      playing = null;
      emit("finish", item.id);
      playNext();
    }, PIECE_MS);
  };
  const cancelAll = () => {
    if (playing) {
      clearTimeout(playing.timer);
      emit("cancel", playing.id);
      playing = null;
    }
    for (const q of queue) emit("cancel", q.id);
    queue = [];
  };
  globalThis.__midnoteTtsBackend = {
    onEvent: async (h) => {
      handler = h;
      return () => {
        handler = null;
      };
    },
    supported: () => true,
    getVoices: async () => ({
      ready: true,
      voices: [
        { id: "en-us-x-aaa-local", name: "English (United States) · aaa · Local", language: "en-US" },
        { id: "en-gb-x-bbb-local", name: "English (United Kingdom) · bbb · Local", language: "en-GB" },
        { id: "fr-fr-x-ccc-local", name: "French (France) · ccc · Local", language: "fr-FR" },
      ],
    }),
    speak: async (text, o) => {
      calls.push(`speak:${o.queue}:${o.voiceId ?? "default"}:${o.rate}:${text}`);
      const id = `u${++nextId}`;
      if (o.queue === "flush") cancelAll();
      queue.push({ id });
      playNext();
      return { utteranceId: id };
    },
    stop: async () => {
      calls.push("stop");
      cancelAll();
    },
    isSpeaking: async () => playing !== null,
  };
}

// Round E (backup): a stand-in for the lock_payload / unlock_payload Tauri commands (the real ones are Rust:
// DixScript's DLM, AES-256-GCM + Argon2id), so password-protected backups run end to end in jsdom.
// The output is deliberately NOT valid UTF-8 (so it is recognised as an encrypted file), carries a per-backup
// id that the key file repeats, and unlock fails for a wrong password or for a key file from another backup.
// Passwords are never recorded; globalThis.__backupCryptoCalls records "lock" / "unlock".
if (process.env.SMOKE_BACKUP_CRYPTO) {
  const calls = (globalThis.__backupCryptoCalls = []);
  let seq = 0;
  const pwHash = (pw) => createHash("sha256").update(pw).digest();
  globalThis.__midnoteBackupCrypto = {
    async lock(plaintext, password) {
      calls.push("lock");
      if (!password) throw new Error("Password cannot be empty.");
      const id = `SMOKEKEY${++seq}`;
      const h = pwHash(password);
      const body = Buffer.from(plaintext, "utf8");
      const xored = Buffer.from(body.map((b, i) => b ^ h[i % 32]));
      const enc = Buffer.concat([Buffer.from([0x00, 0xff, 0xfe]), Buffer.from(id + "\n", "utf8"), h.subarray(0, 8), xored]);
      return { encryptedDataB64: enc.toString("base64"), keyFileContent: `// DixScript Key File v1.0.0\n// smoke-id: ${id}\n@CONFIG(\n  key_type -> "password",\n)\n` };
    },
    async unlock(encryptedDataB64, keyFileContent, password) {
      calls.push("unlock");
      const enc = Buffer.from(encryptedDataB64, "base64");
      if (enc.length < 12 || enc[0] !== 0x00 || enc[1] !== 0xff) throw new Error("Unlock failed: not an encrypted backup");
      const nl = enc.indexOf(10, 3);
      const id = enc.subarray(3, nl).toString("utf8");
      if (!keyFileContent.includes(`smoke-id: ${id}`)) throw new Error("Unlock failed: key file does not match");
      const h = pwHash(password);
      if (!enc.subarray(nl + 1, nl + 9).equals(h.subarray(0, 8))) throw new Error("Unlock failed: wrong password");
      const xored = enc.subarray(nl + 9);
      return Buffer.from(xored.map((b, i) => b ^ h[i % 32])).toString("utf8");
    },
  };
}

// Round B: a stand-in for the studio's Supabase project (GoTrue sign-in + the little PostgREST
// the app touches), so the whole account flow runs in jsdom with no network.
// SMOKE_ONLINE is a JSON spec:
//   config           {url,key} override (default: a fine https URL + a publishable-looking key)
//   users            [{email,password,confirmed?,id?}]   confirmed defaults to true
//   knownRefreshTokens [{token,email}]   refresh tokens the server will accept
//   validAccess      ["AT-seed"]         extra access tokens REST calls accept
//   offline          every request throws (a phone with no signal)
//   refreshStatus    the refresh endpoint answers this HTTP status (a session the server ended)
//   confirmOnResend  tapping "Resend" confirms the address (stands in for opening the email link)
//   enrolPost        status for POST service_subscriptions (default 201)
//   emailFlows       true: the email-dependent flows (create account by email, forgot password,
//                    resend) are switched on in the build; default off like the real build
//   passwordChange   what PUT /auth/v1/user answers: "ok" (default) | "same" | "reauth" | "weak"
//   signupFail       {status, body}: sign-up is answered with this (e.g. a 500 from a database trigger)
//   google           what happens when the app opens Google sign-in in the browser:
//                    "ok" (the link comes back with a code) | "dupe" (the same link twice) |
//                    "denied" | "error" | "never" (default: the person never returns)
//   googleUser       {email} the Google account that signs in (default gina@gmail.test)
//   coldStart        {verifier,email?}: the app was CLOSED while in the browser and is opened by
//                    the returning link (pair it with storage midnote:oauth-pending)
//   strayLink        the app is opened by a midnote://auth link nobody asked for
// The stand-in server checks PKCE for real: the code only trades for a session when
// base64url(sha256(code_verifier)) equals the challenge the app sent, so a wrong hash,
// encoding or verifier fails the scenario.
// Every request is recorded as "METHOD /path" (+ the body for the enrolment POST, + the display
// name for a sign-up) in
// globalThis.__onlineCalls; passwords and tokens are never recorded. Minted tokens are
// "FAKEAT-n" / "FAKERT-n" so assertions can't be fooled by the seeded "AT-seed" / "RT-seed".
if (process.env.SMOKE_ONLINE) {
  const spec = JSON.parse(process.env.SMOKE_ONLINE);
  const calls = (globalThis.__onlineCalls = []);
  const users = new Map();
  const refreshTokens = new Map();
  const validAccess = new Set(spec.validAccess ?? []);
  let n = 0;
  const addUser = (email, password, confirmed, id) =>
    users.set(email, { id: id ?? `00000000-0000-4000-8000-${String(users.size + 1).padStart(12, "0")}`, email, password, confirmed });
  for (const u of spec.users ?? []) addUser(u.email, u.password, u.confirmed !== false, u.id);
  for (const k of spec.knownRefreshTokens ?? []) refreshTokens.set(k.token, k.email);
  const json = (status, obj) => ({ status, text: async () => JSON.stringify(obj) });
  const codes = new Map();
  const gUser = spec.googleUser ?? { email: "gina@gmail.test" };
  const sha = (text) => createHash("sha256").update(text).digest("base64url");
  const mint = (u) => {
    const at = `FAKEAT-${++n}`;
    const rt = `FAKERT-${++n}`;
    validAccess.add(at);
    refreshTokens.set(rt, u.email);
    return { access_token: at, refresh_token: rt, expires_in: 3600, expires_at: 4102444800, token_type: "bearer", user: { id: u.id, email: u.email } };
  };
  // Round D2: the AI proxy (workers/midnote-ai). spec.ai = { url, status?, statusHttp?, run?, runs?, offline?, rejectFirst? }.
  // Calls are recorded as "METHOD /path auth=user|bad|none <body>" in globalThis.__aiCalls ("user" = the bearer is one of
  // the access tokens this fake issued or accepts, so a wrong token - e.g. the publishable key - shows up as "bad").
  // No spec.ai -> the build has no AI address (aiUrl null).
  const aiCalls = (globalThis.__aiCalls = []);
  let aiRun = 0;
  const AI_STATUS = { enabled: true, has_account: true, balance: 2996, daily_cap: 400, daily_left: 396, next_topup_at: "2026-11-17T10:00:00.000Z", pool_open: true, resets_in: 21600 };
  globalThis.__midnoteOnline = {
    config: spec.config ?? { url: "https://smoke.supabase.co", key: "sb_publishable_smoke" },
    emailFlows: spec.emailFlows === true,
    aiUrl: spec.ai ? spec.ai.url : null,
    fetch: async (url, init) => {
      if (spec.ai && String(url).startsWith(spec.ai.url)) {
        const a = spec.ai;
        const au = new URL(url);
        const bearer = String((init.headers && init.headers.Authorization) || "").replace("Bearer ", "");
        const who = validAccess.has(bearer) ? "user" : bearer ? "bad" : "none";
        aiCalls.push(`${init.method} ${au.pathname} auth=${who}${init.body ? " " + init.body : ""}`);
        if (a.offline) throw new TypeError("Failed to fetch");
        if (who !== "user" || (a.rejectFirst && !a._rejected && (a._rejected = true))) return json(401, { error: "signed-out", message: "Sign in to use AI." });
        if (au.pathname === "/v1/ai/status") return json(a.statusHttp ?? 200, a.status ?? AI_STATUS);
        if (au.pathname === "/v1/ai/run") {
          const r = (a.runs ?? [])[aiRun++] ?? a.run ?? { status: 200, body: { text: "OK", model: "m", credits_charged: 4, balance: 2992 } };
          return json(r.status, r.body);
        }
        return json(404, { error: "not-found" });
      }
      const u = new URL(url);
      const body = init.body ? JSON.parse(init.body) : {};
      calls.push(`${init.method} ${u.pathname}${u.search}${u.pathname.endsWith("service_subscriptions") && init.method === "POST" ? " " + init.body : ""}${u.pathname === "/auth/v1/signup" ? " display_name=" + (body.data?.display_name ?? "") : ""}`);
      if (spec.offline) throw new TypeError("Failed to fetch");
      if (u.pathname === "/auth/v1/token" && u.searchParams.get("grant_type") === "password") {
        const user = users.get(body.email);
        if (!user || user.password !== body.password) return json(400, { code: 400, error_code: "invalid_credentials", msg: "Invalid login credentials" });
        if (!user.confirmed) return json(400, { code: 400, error_code: "email_not_confirmed", msg: "Email not confirmed" });
        return json(200, mint(user));
      }
      if (u.pathname === "/auth/v1/token" && u.searchParams.get("grant_type") === "refresh_token") {
        if (spec.refreshStatus) return json(spec.refreshStatus, { code: spec.refreshStatus, error_code: "refresh_token_not_found", msg: "Invalid Refresh Token: Refresh Token Not Found" });
        const email = refreshTokens.get(body.refresh_token);
        if (!email) return json(400, { code: 400, error_code: "refresh_token_not_found", msg: "Invalid Refresh Token: Refresh Token Not Found" });
        refreshTokens.delete(body.refresh_token);
        return json(200, mint(users.get(email)));
      }
      if (u.pathname === "/auth/v1/token" && u.searchParams.get("grant_type") === "pkce") {
        const issued = codes.get(body.auth_code);
        if (!issued) return json(400, { code: 400, error_code: "validation_failed", msg: "invalid flow state, no valid flow state found" });
        if (sha(String(body.code_verifier)) !== issued.challenge) return json(400, { code: 400, error_code: "validation_failed", msg: "code challenge does not match previously saved code verifier" });
        codes.delete(body.auth_code);
        if (!users.has(issued.email)) addUser(issued.email, "no-password-google-account", true);
        return json(200, mint(users.get(issued.email)));
      }
      if (u.pathname === "/auth/v1/signup") {
        if (spec.signupFail) return json(spec.signupFail.status, spec.signupFail.body);
        if (String(body.password).length < 6) return json(422, { code: 422, error_code: "weak_password", msg: "Password should be at least 6 characters." });
        const existing = users.get(body.email);
        if (existing) return json(200, { id: "fake", email: body.email, identities: [] });
        addUser(body.email, body.password, false);
        return json(200, { id: users.get(body.email).id, email: body.email, confirmation_sent_at: "now" });
      }
      if (u.pathname === "/auth/v1/resend") {
        if (spec.confirmOnResend && users.get(body.email)) users.get(body.email).confirmed = true;
        return json(200, {});
      }
      if (u.pathname === "/auth/v1/recover") return json(200, {});
      if (u.pathname === "/auth/v1/logout") return json(204, {});
      if (u.pathname === "/auth/v1/user" && init.method === "PUT") {
        const bearer = String(init.headers.Authorization || "").replace("Bearer ", "");
        if (!validAccess.has(bearer)) return json(401, { message: "JWT expired" });
        const mode = spec.passwordChange ?? "ok";
        if (mode === "same") return json(422, { code: 422, error_code: "same_password", msg: "New password should be different from the old password." });
        if (mode === "reauth") return json(400, { code: 400, error_code: "reauthentication_needed", msg: "Password update requires reauthentication" });
        if (mode === "weak") return json(422, { code: 422, error_code: "weak_password", msg: "Password is known to be weak and easy to guess, please choose a different one." });
        return json(200, { id: "x", email: "x" });
      }
      if (u.pathname.startsWith("/rest/v1/")) {
        const bearer = String(init.headers.Authorization || "").replace("Bearer ", "");
        if (!validAccess.has(bearer)) return json(401, { message: "JWT expired" });
        if (u.pathname === "/rest/v1/services") return json(200, [{ id: "svc-1" }]);
        if (u.pathname === "/rest/v1/service_subscriptions") return init.method === "POST" ? json(spec.enrolPost ?? 201, {}) : json(200, []);
      }
      return json(404, {});
    },
  };

  // The phone's browser + the midnote://auth deep link, as the app sees them.
  const listeners = [];
  const emit = (url) => {
    for (const cb of [...listeners]) cb(url);
  };
  const coldUrls = [];
  if (spec.coldStart) {
    codes.set("COLDCODE", { challenge: sha(spec.coldStart.verifier), email: spec.coldStart.email ?? gUser.email });
    coldUrls.push("midnote://auth?code=COLDCODE");
  }
  if (spec.strayLink) coldUrls.push("midnote://auth?code=STRAYCODE");
  let codeN = 0;
  globalThis.__midnoteDeepLink = {
    getCurrent: async () => coldUrls,
    onUrl: async (cb) => {
      listeners.push(cb);
      return () => {
        const i = listeners.indexOf(cb);
        if (i >= 0) listeners.splice(i, 1);
      };
    },
    openUrl: async (url) => {
      const u = new URL(url);
      calls.push(`OPEN ${u.origin}${u.pathname} provider=${u.searchParams.get("provider")} method=${u.searchParams.get("code_challenge_method")} redirect=${u.searchParams.get("redirect_to")}`);
      const mode = spec.google ?? "never";
      if (u.pathname !== "/auth/v1/authorize" || mode === "never") return;
      const code = `GCODE-${++codeN}`;
      codes.set(code, { challenge: u.searchParams.get("code_challenge"), email: gUser.email });
      const back = {
        ok: `midnote://auth?code=${code}`,
        dupe: `midnote://auth?code=${code}`,
        denied: "midnote://auth?error=access_denied&error_code=access_denied&error_description=The+user+denied+access",
        error: "midnote://auth?error=server_error&error_description=Unable+to+exchange+external+code",
      }[mode];
      setTimeout(() => {
        emit(back);
        if (mode === "dupe") setTimeout(() => emit(back), 20);
      }, 30);
    },
  };
}

// Bare-identifier browser globals the SvelteKit client runtime and app
// code touch directly (the way real browser globals work — `window`
// properties are implicitly global). Extend this list if a new scenario
// hits a ReferenceError for some other browser API.
const GLOBALS_TO_COPY = [
  "window", "document", "location", "history", "navigator", "customElements",
  "HTMLElement", "Element", "Node", "Text", "Comment", "DocumentFragment",
  "SVGAElement", "SVGElement", "HTMLMediaElement", "HTMLInputElement",
  "HTMLTextAreaElement", "HTMLButtonElement", "HTMLAnchorElement", "HTMLFormElement",
  "HTMLSelectElement", "DOMParser", "Headers", "Request", "Response", "URL",
  "URLSearchParams", "MutationObserver", "getSelection",
  "TextEncoder", "TextDecoder", "btoa", "atob", "sessionStorage", "localStorage",
  "pageXOffset", "pageYOffset", "scrollX", "scrollY", "innerWidth", "innerHeight",
  "getComputedStyle", "matchMedia", "requestIdleCallback", "cancelIdleCallback",
];
// NOTE (round 26): "performance" used to be in the list above and must
// NOT be. jsdom's own Performance.now() is implemented by calling the
// GLOBAL `performance.now()` — and copying jsdom's performance object over
// the global makes that call itself, forever (RangeError: Maximum call
// stack size exceeded, from inside jsdom, the moment ANY app code calls
// performance.now()). Node ships its own working global `performance`,
// which is what jsdom's implementation wants to find there; window.performance
// (jsdom's) still exists and delegates to it. Found when the find & replace
// plugin's search-budget timer ran under this harness.
for (const key of GLOBALS_TO_COPY) {
  if (key in w) {
    // defineProperty, not plain assignment — Node has its own read-only
    // built-in globals (navigator, crypto, ...) that a bare `global.x = y`
    // throws on.
    Object.defineProperty(global, key, {
      value: w[key], writable: true, configurable: true, enumerable: true,
    });
  }
}
global.window = w;
global.document = w.document;
global.addEventListener = w.addEventListener.bind(w);
global.removeEventListener = w.removeEventListener.bind(w);
global.dispatchEvent = w.dispatchEvent.bind(w);
global.scrollTo = () => {};
global.requestAnimationFrame = (cb) => setTimeout(cb, 0);
global.cancelAnimationFrame = (id) => clearTimeout(id);
global.IntersectionObserver = FakeIntersectionObserver;
global.matchMedia = fakeMatchMedia;
global.ResizeObserver = FakeResizeObserver;
global.SVGAElement = FakeSVGAElement;
global.fetch = async () => new Response("{}", { status: 404 });

// SvelteKit's client entry reads a per-build-hashed global
// (__sveltekit_XXXXX) for its base path — extract the real one from the
// build's own index.html rather than hardcoding it, since it changes on
// every build.
const indexHtml = readFileSync(path.join(BUILD_DIR, "index.html"), "utf-8");
const sveltekitGlobalName = (indexHtml.match(/__sveltekit_\w+/) || [null, "__sveltekit_r5jb0"])[0];
globalThis[sveltekitGlobalName] = { base: "" };

const errors = [];
w.addEventListener("error", (e) => errors.push(e.error ?? e.message));
process.on("unhandledRejection", (err) => errors.push(err));

const target = w.document.createElement("div");
target.style.display = "contents";
w.document.body.appendChild(target);

try {
  const entryDir = path.join(BUILD_DIR, "_app", "immutable", "entry");
  const entryFiles = readdirSync(entryDir);
  const startFile = entryFiles.find((f) => f.startsWith("start."));
  const appFile = entryFiles.find((f) => f.startsWith("app."));
  const startUrl = pathToFileURL(path.join(entryDir, startFile)).href;
  const appUrl = pathToFileURL(path.join(entryDir, appFile)).href;
  const [kit, app] = await Promise.all([import(startUrl), import(appUrl)]);
  await kit.start(app, target);
} catch (err) {
  errors.push(err);
}

// Give effects/microtasks room to settle — or to spiral, if a loop like
// the effect_update_depth_exceeded one is back.
await new Promise((r) => setTimeout(r, SETTLE_MS));

if (CLICK_ARIA_LABEL && errors.length === 0) {
  const el = target.querySelector(`[aria-label="${CLICK_ARIA_LABEL}"]`);
  if (!el) {
    errors.push(new Error(`No element with aria-label="${CLICK_ARIA_LABEL}" found to click.`));
  } else {
    el.click();
    // A shorter second wait than the initial SETTLE_MS — this is only
    // waiting on whatever the click's own handler kicks off (a save's
    // in-memory update + fire-and-forget persist, an $effect it
    // triggers), not a full route mount.
    await new Promise((r) => setTimeout(r, Math.min(SETTLE_MS, 600)));
  }
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

if (STEPS.length > 0 && errors.length === 0) {
  for (let i = 0; i < STEPS.length; i++) {
    const step = STEPS[i];
    const where = `steps[${i}] ${JSON.stringify(step)}`;
    if (step.click) {
      const el = target.querySelector(`[aria-label="${step.click}"]`);
      if (!el) {
        errors.push(new Error(`${where}: no element with aria-label="${step.click}" to click.`));
        break;
      }
      el.click();
    } else if (step.type) {
      const el = step.type.selector ? target.querySelector(step.type.selector) : target.querySelector(`[aria-label="${step.type.label}"]`);
      if (!el) {
        errors.push(new Error(`${where}: no input with ${step.type.selector ? `selector ${step.type.selector}` : `aria-label="${step.type.label}"`} to type into.`));
        break;
      }
      el.value = step.type.value;
      el.dispatchEvent(new w.Event("input", { bubbles: true }));
      // Round 35: a <select> reports a choice through `change`, not `input`
      // (the todo step card's "Move step to category"). Harmless for text fields.
      el.dispatchEvent(new w.Event("change", { bubbles: true }));
    } else if (step.paste !== undefined) {
      // Round 27: fire a real `paste` event (with a text/plain clipboard)
      // at the live Tiptap editor. jsdom has no ClipboardEvent or
      // DataTransfer, so the event is a plain Event carrying the one
      // property (`clipboardData.getData`) the app's handler reads.
      const pm = target.querySelector(".ProseMirror");
      if (!pm) {
        errors.push(new Error(`${where}: no .ProseMirror editor to paste into.`));
        break;
      }
      const ev = new w.Event("paste", { bubbles: true, cancelable: true });
      ev.clipboardData = { getData: (t) => (t === "text/plain" ? step.paste : "") };
      pm.dispatchEvent(ev);
      if (!ev.defaultPrevented) {
        errors.push(new Error(`${where}: the paste event wasn't handled (defaultPrevented is false) — the plain-text paste handler isn't wired into the editor.`));
        break;
      }
    } else if (step.expectDownload) {
      const want = step.expectDownload;
      // `find: true` looks at every recorded download (latest first) for one ending in `ext`;
      // otherwise the LAST download must be that file.
      const d = want.find ? [...w.__downloads].reverse().find((x) => x.name.endsWith(want.ext)) : w.__downloads[w.__downloads.length - 1];
      if (!d || !d.blob) {
        errors.push(new Error(`${where}: no download was triggered.`));
        break;
      }
      if (!d.name.endsWith(want.ext)) {
        errors.push(new Error(`${where}: last download was "${d.name}", expected a file ending ${want.ext}.`));
        break;
      }
      if (want.binary) {
        // an encrypted file must NOT be readable text
        const raw = new Uint8Array(await d.blob.arrayBuffer());
        let isText = true;
        try {
          new TextDecoder("utf-8", { fatal: true }).decode(raw);
          isText = !raw.includes(0);
        } catch {
          isText = false;
        }
        if (isText) {
          errors.push(new Error(`${where}: "${d.name}" is readable text but was expected to be encrypted binary.`));
          break;
        }
      }
      if (want.notContains) {
        const hay = Buffer.from(await d.blob.arrayBuffer()).toString("latin1") + Buffer.from(await d.blob.arrayBuffer()).toString("utf8");
        const leaked = want.notContains.filter((x) => hay.includes(x));
        if (leaked.length) {
          errors.push(new Error(`${where}: "${d.name}" leaks ${JSON.stringify(leaked)} in the clear.`));
          break;
        }
      }
      if (want.magic === undefined) continue;
      // The app's `new Blob()` is Node's own (Blob isn't one of the globals
      // copied from jsdom), so read it with Node's Blob.arrayBuffer() —
      // jsdom's FileReader rejects a Blob from another implementation.
      const buf = new Uint8Array(await d.blob.arrayBuffer());
      const head = String.fromCharCode(...buf.slice(0, want.magic.length));
      if (want.contains) {
        const body = new TextDecoder().decode(buf);
        const missing = want.contains.filter((s) => !body.includes(s));
        if (missing.length) {
          errors.push(new Error(`${where}: "${d.name}" doesn't contain ${JSON.stringify(missing)}.`));
          break;
        }
      }
      if (head !== want.magic || buf.length < (want.minBytes ?? 0)) {
        errors.push(new Error(`${where}: "${d.name}" starts with ${JSON.stringify(head)} and is ${buf.length} bytes; expected magic ${JSON.stringify(want.magic)} and >= ${want.minBytes ?? 0} bytes.`));
        break;
      }
    } else if (step.expectDownloadCount !== undefined) {
      if (w.__downloads.length !== step.expectDownloadCount) {
        errors.push(new Error(`${where}: expected ${step.expectDownloadCount} download(s), got ${w.__downloads.length} (${w.__downloads.map((x) => x.name).join(", ")}).`));
        break;
      }
    } else if (step.expectGlobalIncludes || step.expectGlobalCount) {
      // Round 31: inspect a recording array on globalThis (e.g. the fake
      // reminder backend's __reminderCalls).
      const spec = step.expectGlobalIncludes ?? step.expectGlobalCount;
      const lines = Array.isArray(globalThis[spec.name]) ? globalThis[spec.name] : [];
      const hits = lines.filter((l) => String(l).includes(spec.substring)).length;
      if (step.expectGlobalIncludes && hits === 0) {
        errors.push(new Error(`${where}: no entry in ${spec.name} contains "${spec.substring}". Recorded: ${JSON.stringify(lines).slice(0, 300)}`));
        break;
      }
      if (step.expectGlobalCount && hits !== spec.count) {
        errors.push(new Error(`${where}: expected ${spec.count} entries in ${spec.name} containing "${spec.substring}", found ${hits}. Recorded: ${JSON.stringify(lines).slice(0, 300)}`));
        break;
      }
    } else if (step.expectNoText) {
      if (target.textContent.includes(step.expectNoText)) {
        errors.push(new Error(`${where}: page text still contains "${step.expectNoText}".`));
        break;
      }
    } else if (step.expectStoredOrder) {
      // Round 35: the listed strings must appear in stored data in THIS order
      // (first occurrence of each) — proves a reorder reached storage.
      let all = "";
      for (let k = 0; k < w.localStorage.length; k++) all += w.localStorage.getItem(w.localStorage.key(k)) + "\n";
      const at = step.expectStoredOrder.map((s) => all.indexOf(s));
      const missing = step.expectStoredOrder.filter((_, i) => at[i] === -1);
      if (missing.length > 0) {
        errors.push(new Error(`${where}: not found in stored data: ${JSON.stringify(missing)}.`));
        break;
      }
      if (!at.every((v, i) => i === 0 || v > at[i - 1])) {
        errors.push(new Error(`${where}: stored order is not ${JSON.stringify(step.expectStoredOrder)} (positions ${JSON.stringify(at)}).`));
        break;
      }
    } else if (step.expectStored !== undefined || step.expectNotStored !== undefined) {
      // Searches every localStorage value: proves a change reached the
      // storage layer (saveEntry), not just the screen.
      let all = "";
      for (let k = 0; k < w.localStorage.length; k++) all += w.localStorage.getItem(w.localStorage.key(k)) + "\n";
      const needle = step.expectStored ?? step.expectNotStored;
      const has = all.includes(needle);
      if (step.expectStored !== undefined && !has) {
        errors.push(new Error(`${where}: "${needle}" was not found in stored data.`));
        break;
      }
      if (step.expectNotStored !== undefined && has) {
        errors.push(new Error(`${where}: "${needle}" is still in stored data.`));
        break;
      }
    } else if (step.clickSelector) {
      // Round 29: for elements with no aria-label of their own (Tiptap's
      // checklist checkbox is a bare <input type=checkbox>).
      const el = target.querySelector(step.clickSelector);
      if (!el) {
        errors.push(new Error(`${where}: nothing matched ${step.clickSelector} to click.`));
        break;
      }
      el.click();
    } else if (step.chooseFile) {
      // Round 45: pick a file in an <input type="file">. The File is Node's own (it has
      // .text(), like the Blob note above); jsdom can't be given real files, so the
      // input's `files` is defined directly and a `change` event announced.
      // Round E (backup): `files: [{ name, text }, { fromDownload: ".mdix.enc" }]` picks several files at once;
      // `fromDownload` re-uses the real bytes of the latest recorded download ending that way (a backup the app just saved).
      const { selector, name, text } = step.chooseFile;
      const el = target.querySelector(selector);
      if (!el) {
        errors.push(new Error(`${where}: nothing matched ${selector} to choose a file in.`));
        break;
      }
      const specs = step.chooseFile.files ?? [{ name, text }];
      const picked = [];
      for (const f of specs) {
        if (f.fromDownload) {
          const d = [...w.__downloads].reverse().find((x) => x.name.endsWith(f.fromDownload));
          if (!d || !d.blob) {
            errors.push(new Error(`${where}: no recorded download ending ${f.fromDownload} to pick.`));
            break;
          }
          picked.push(new File([new Uint8Array(await d.blob.arrayBuffer())], f.name ?? d.name));
        } else {
          picked.push(new File([f.text], f.name));
        }
      }
      if (picked.length !== specs.length) break;
      Object.defineProperty(el, "files", { value: picked, configurable: true });
      el.dispatchEvent(new w.Event("change", { bubbles: true }));
    } else if (step.longPress) {
      // Round 44: press and hold (a card's long-press-to-select). Pointer events with
      // isPrimary, held longer than the 500 ms the gesture needs, then released.
      const el = target.querySelector(step.longPress);
      if (!el) {
        errors.push(new Error(`${where}: nothing matched ${step.longPress} to long-press.`));
        break;
      }
      const make = (type) => {
        const init = { bubbles: true, cancelable: true, clientX: 5, clientY: 5, isPrimary: true, pointerId: 1 };
        if (typeof w.PointerEvent === "function") return new w.PointerEvent(type, init);
        return Object.assign(new w.MouseEvent(type, init), { isPrimary: true });
      };
      el.dispatchEvent(make("pointerdown"));
      await new Promise((r) => setTimeout(r, 700));
      el.dispatchEvent(make("pointerup"));
    } else if (step.selectText) {
      // Round F: a REAL partial selection in the editor. jsdom cannot drag a selection, so this sets ProseMirror's own
      // selection through the Tiptap instance (which Tiptap keeps on the editor's DOM element). { from, to? } are texts
      // inside ONE text node each: the selection runs from the start of `from` to the end of `to` (default: of `from`).
      const sel = step.selectText;
      const el = target.querySelector(sel.selector ?? ".ProseMirror");
      const ed = el && el.editor;
      if (!ed) {
        errors.push(new Error(`${where}: no editor on ${sel.selector ?? ".ProseMirror"} to select text in.`));
        break;
      }
      let start = -1;
      let end = -1;
      ed.state.doc.descendants((node, pos) => {
        if (!node.isText || end >= 0) return;
        let from = 0;
        if (start < 0) {
          const i = node.text.indexOf(sel.from);
          if (i < 0) return;
          start = pos + i;
          from = i + sel.from.length;
          if (sel.to === undefined) {
            end = start + sel.from.length;
            return;
          }
        }
        const j = node.text.indexOf(sel.to, from);
        if (j >= 0) end = pos + j + sel.to.length;
      });
      if (start < 0 || end < 0) {
        errors.push(new Error(`${where}: could not find "${sel.from}"${sel.to === undefined ? "" : ` .. "${sel.to}"`} in the editor to select.`));
        break;
      }
      ed.commands.setTextSelection({ from: start, to: end });
      await new Promise((r) => setTimeout(r, sel.settleMs ?? 150));
    } else if (step.editorInsert !== undefined) {
      // Round F: a document change made behind the sheet's back (typing at the caret), for the "note changed" guards.
      const el = target.querySelector(".ProseMirror");
      const ed = el && el.editor;
      if (!ed) {
        errors.push(new Error(`${where}: no editor on the page.`));
        break;
      }
      ed.commands.insertContent(step.editorInsert);
      await new Promise((r) => setTimeout(r, 150));
    } else if (step.expectEditorHtml !== undefined) {
      // Round F: the editor's exact HTML (what would be saved), to prove what a Replace / Insert did and did not touch.
      const el = target.querySelector(".ProseMirror");
      const ed = el && el.editor;
      if (!ed) {
        errors.push(new Error(`${where}: no editor on the page.`));
        break;
      }
      const html = ed.getHTML();
      if (html !== step.expectEditorHtml) {
        errors.push(new Error(`${where}: editor HTML is\n  ${html}\nbut should be\n  ${step.expectEditorHtml}`));
        break;
      }
    } else if (step.expectSelection !== undefined) {
      // Select-by-pattern round: the editor's REAL selection, as text (lines separated by "\n"). null = nothing selected.
      const el = target.querySelector(".ProseMirror");
      const ed = el && el.editor;
      if (!ed) {
        errors.push(new Error(`${where}: no editor on the page.`));
        break;
      }
      const { from, to, empty } = ed.state.selection;
      const got = empty ? null : ed.state.doc.textBetween(from, to, "\n", "\n");
      if (got !== step.expectSelection) {
        errors.push(new Error(`${where}: the selection is ${JSON.stringify(got)} but should be ${JSON.stringify(step.expectSelection)}`));
        break;
      }
    } else if (step.expectValue) {
      // The value of an input found by aria-label (expectText only reads text nodes, never input values).
      const el = target.querySelector(`[aria-label="${step.expectValue.label}"]`);
      if (!el) {
        errors.push(new Error(`${where}: no input with aria-label="${step.expectValue.label}".`));
        break;
      }
      if (el.value !== step.expectValue.value) {
        errors.push(new Error(`${where}: "${step.expectValue.label}" holds ${JSON.stringify(el.value)} but should hold ${JSON.stringify(step.expectValue.value)}`));
        break;
      }
    } else if (step.expectSelectorText) {
      // The EXACT trimmed text of the first element matching a selector (expectText is only a substring check).
      const el = target.querySelector(step.expectSelectorText.selector);
      if (!el) {
        errors.push(new Error(`${where}: nothing matched ${step.expectSelectorText.selector}.`));
        break;
      }
      const got = (el.textContent ?? "").trim();
      if (got !== step.expectSelectorText.text) {
        errors.push(new Error(`${where}: ${step.expectSelectorText.selector} reads ${JSON.stringify(got)} but should read ${JSON.stringify(step.expectSelectorText.text)}`));
        break;
      }
    } else if (step.press) {
      // Round 38: a keyboard shortcut on an element — e.g. Ctrl+A inside the editor
      // to make a real selection (ProseMirror handles it through its own keymap).
      const el = target.querySelector(step.press.selector);
      if (!el) {
        errors.push(new Error(`${where}: nothing matched ${step.press.selector} to press a key on.`));
        break;
      }
      el.focus?.();
      for (const type of ["keydown", "keyup"]) {
        el.dispatchEvent(new w.KeyboardEvent(type, { key: step.press.key, ctrlKey: !!step.press.ctrl, bubbles: true, cancelable: true }));
      }
      await new Promise((r) => setTimeout(r, step.press.settleMs ?? 150));
    } else if (step.expectNoSelector) {
      // Round 36: the inverse of expectSelector — something must NOT be on the page.
      if (target.querySelector(step.expectNoSelector)) {
        errors.push(new Error(`${where}: ${step.expectNoSelector} matched, but it should not be on the page.`));
        break;
      }
    } else if (step.expectSelector) {
      if (!target.querySelector(step.expectSelector)) {
        errors.push(new Error(`${where}: nothing matched ${step.expectSelector}.`));
        break;
      }
    } else if (step.expectText) {
      if (!target.textContent.includes(step.expectText)) {
        errors.push(new Error(`${where}: page text doesn't contain "${step.expectText}". Actual: ${target.textContent.trim().slice(0, 200)}`));
        break;
      }
    }
    await sleep(step.wait ?? 250);
  }
}

if (errors.length > 0) {
  for (const e of errors) {
    console.error((e && e.stack) || (e && e.message) || String(e));
  }
  process.exit(1);
}

if (EXPECT_TEXT && !target.textContent.includes(EXPECT_TEXT)) {
  console.error(`Expected the settled page to contain "${EXPECT_TEXT}", but it didn't.`);
  console.error(`Actual visible text: ${target.textContent.trim().slice(0, 300) || "(empty)"}`);
  process.exit(1);
}

process.exit(0);
