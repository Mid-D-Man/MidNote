<script lang="ts">
  import Button from "$lib/components/ui/Button/Button.svelte";
  import Sheet from "$lib/components/ui/Sheet/Sheet.svelte";
  import AuthDialog, { type AuthMode } from "$lib/components/layout/AuthDialog/AuthDialog.svelte";
  import SettingsSheet from "$lib/components/layout/SettingsSheet/SettingsSheet.svelte";
  import TrashSheet from "$lib/components/layout/TrashSheet/TrashSheet.svelte";
  import { goto } from "$app/navigation";
  import { pushToast } from "$lib/stores/toast.svelte";
  import { account } from "$lib/stores/account.svelte";
  import { appHeaderTheme } from "$lib/stores/settings.svelte";
  import { resolveTheme, hexToRgba, getImageTextColorVars } from "$lib/utils/themePalette";
  import { customThemes } from "$lib/stores/customThemes.svelte";

  let menuOpen = $state(false);
  let authOpen = $state(false);
  let authMode = $state<AuthMode>("signin");

  function openAuth(mode: AuthMode) {
    menuOpen = false;
    authMode = account.emailFlows ? mode : "signin";
    authOpen = true;
  }
  let settingsOpen = $state(false);
  let trashOpen = $state(false);

  // This <header> — hamburger, "MidNote" wordmark, sync icon — is what
  // the landing-page "Header" theme slot actually means (confirmed
  // against a real annotated screenshot: this bar specifically, not the
  // Notes/Todos tab row below it, which is genuinely part of "Body"
  // now — see +page.svelte's pageBodyStyle comment). Self-contained,
  // same pattern as NoteEditorHeader/TodoHeader's own headerStyle:
  // this component owns its own theme resolution rather than the
  // parent computing and passing down a style string.
  const resolvedHeaderTheme = $derived(resolveTheme(appHeaderTheme.value, customThemes));
  const headerStyle = $derived(
    resolvedHeaderTheme.kind === "color"
      ? `background: ${hexToRgba(resolvedHeaderTheme.color, 0.16)};`
      : resolvedHeaderTheme.kind === "image"
        ? // BUGFIX: this was written in the same round that fixed the
          // header/body mapping (before the colorthief contrast system
          // existed) and never got backfilled — the h1/icon buttons
          // below had no dynamic contrast handling at all until now,
          // same class of gap as NoteEditorHeader/TodoHeader's identical
          // fix.
          `background-image: linear-gradient(rgba(4,6,16,0.35), rgba(4,6,16,0.35)), url(${resolvedHeaderTheme.dataUrl}); background-size: cover; background-position: center; ${getImageTextColorVars(resolvedHeaderTheme.textColor)}`
        : "",
  );

  // The cloud button. Signed out it opens sign-in; signed in it says so honestly, because
  // the sync itself is the next round and a button that pretends to sync would be a lie.
  function handleSync() {
    if (!account.signedIn) {
      openAuth("signin");
      return;
    }
    pushToast({
      title: "Signed in",
      description: "Sync isn't built yet. Your notes are safe on this phone.",
    });
  }
</script>

<header class="app-header" style={headerStyle}>
  <Button variant="ghost" size="icon" aria-label="Open menu" onclick={() => (menuOpen = true)}>
    <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2">
      <line x1="3" y1="6" x2="21" y2="6" />
      <line x1="3" y1="12" x2="21" y2="12" />
      <line x1="3" y1="18" x2="21" y2="18" />
    </svg>
  </Button>

  <h1><img src="/midnote-logo.svg" alt="" class="logo-mark" /> MidNote</h1>

  <Button variant="ghost" size="icon" aria-label="Cloud sync" onclick={handleSync}>
    <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2">
      <path d="M18 10h-1.26A8 8 0 1 0 9 20h9a5 5 0 0 0 0-10z" />
    </svg>
  </Button>
</header>

<Sheet bind:open={menuOpen} side="left" title="Menu">
  <nav class="menu-nav">
    <Button variant="ghost" onclick={() => { menuOpen = false; trashOpen = true; }}>
      Trash
    </Button>
    {#if account.signedIn}
      <Button variant="ghost" aria-label="Open account" onclick={() => { menuOpen = false; void goto("/settings/account"); }}>
        Account
      </Button>
    {:else}
      <Button variant="ghost" aria-label="Open login" onclick={() => openAuth("signin")}>
        Login
      </Button>
      {#if account.emailFlows}
        <Button variant="ghost" aria-label="Open sign up" onclick={() => openAuth("signup")}>
          Sign Up
        </Button>
      {/if}
    {/if}
    <Button variant="ghost" aria-label="Open settings" onclick={() => { menuOpen = false; settingsOpen = true; }}>
      Settings
    </Button>
  </nav>
</Sheet>

<AuthDialog bind:open={authOpen} bind:mode={authMode} />
<!-- Back returns to the Menu this was opened from. -->
<SettingsSheet bind:open={settingsOpen} onBack={() => { settingsOpen = false; menuOpen = true; }} />
<!-- Back returns to the Menu this was opened from. -->
<TrashSheet bind:open={trashOpen} onBack={() => { trashOpen = false; menuOpen = true; }} />

<style>
  .app-header {
    height: 15vh;
    min-height: 80px;
    max-height: 120px;
    border-bottom: 1px solid var(--hairline);
    background: var(--surface);
    padding: 0 var(--space-4);
    display: flex;
    align-items: center;
    justify-content: space-between;
  }
  h1 {
    font-family: var(--font-display);
    font-size: 17px;
    /* Same fallback pattern as Button.svelte's .btn-ghost — see that
       file's comment. Falls back to the normal token when no header
       theme (or a non-image one) is active. */
    color: var(--theme-text-hi, var(--text-hi));
    margin: 0;
    display: flex;
    align-items: center;
    gap: var(--space-2);
  }
  /* The logo's own colors (black base, green/blue-violet accents) are
     baked into the SVG's fill attributes, not currentColor — they can't
     adapt to dark mode / a header theme the way the "MidNote" text next
     to it does. A small light backdrop keeps the (mostly black) mark
     visible against this app's dark-mode default (--surface is a
     near-black navy there — a black logo directly on it would all but
     disappear) without needing a second logo asset for now. */
  .logo-mark {
    width: 22px;
    height: 22px;
    padding: 2px;
    border-radius: var(--radius-sm);
    background: #ffffff;
    flex-shrink: 0;
  }
  .menu-nav {
    display: flex;
    flex-direction: column;
    gap: var(--space-2);
    margin-top: var(--space-4);
  }
</style>
