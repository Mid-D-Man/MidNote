<script lang="ts">
  import "../lib/tokens.css";
  import Toast from "$lib/components/ui/Toast/Toast.svelte";
  import LockPrompt from "$lib/components/shared/LockPrompt/LockPrompt.svelte";
  import LoadingOverlay from "$lib/components/ui/LoadingOverlay/LoadingOverlay.svelte";
  import LoadingScreen from "$lib/components/layout/LoadingScreen/LoadingScreen.svelte";
  import DebugPanel from "$lib/components/debug/DebugPanel.svelte";
  import { installGlobalCapture } from "$lib/debug/log.svelte";
  import { debugPanelVisible } from "$lib/stores/settings.svelte";
  import { initFromBackend, entries, setReminderAtQuietly } from "$lib/stores/entries.svelte";
  import { sync as syncTags } from "$lib/stores/tags.svelte";
  import { onMount } from "svelte";
  import { goto } from "$app/navigation";
  import { installReminderTapHandler, topUpRepeatingReminders } from "$lib/utils/reminders";
  import { initCustomFonts } from "$lib/stores/customFonts.svelte";
  import { initCustomThemes } from "$lib/stores/customThemes.svelte";
  import { initCustomIcons } from "$lib/stores/customIcons.svelte";
  import { initAccount } from "$lib/stores/account.svelte";
  import { initSync, startSync, syncStatus, restoreFromCloud } from "$lib/stores/sync.svelte";
  import ConfirmDialog from "$lib/components/ui/ConfirmDialog/ConfirmDialog.svelte";
  import ReadAloudBar from "$lib/components/shared/ReadAloudBar/ReadAloudBar.svelte";
  import OpenFileSheet from "$lib/components/shared/OpenFileSheet/OpenFileSheet.svelte";
  import { startOpenWith } from "$lib/stores/openWith.svelte";
  import { syncReadAloud } from "$lib/stores/readAloud.svelte";
  import { startAutoLock } from "$lib/utils/autoLock";
  import { lockNow, hasLockedSecrets } from "$lib/utils/lockFlow";
  import { autoLockAway } from "$lib/stores/lockSession.svelte";
  import type { Snippet } from "svelte";

  let { children }: { children: Snippet } = $props();

  // Moved here from +page.svelte (round 22): that file's own local
  // isLoading/LoadingScreen only ever gated its own markup, which was
  // fine back when everything storage.ts returned was already sitting
  // in localStorage by the time any component's <script> ran. Now that
  // storage.ts's real data arrives from an async Tauri round trip (see
  // that file's header), gating has to live at the ROOT layout instead —
  // every route (note/[id], todo/[id], board/[id], not just the landing
  // page) reads from the same entries.svelte.ts store, and a direct
  // navigation to one of those (a restored route on relaunch, a
  // hot-reload landing mid-route in dev) needs the exact same guarantee
  // the landing page needed: nothing downstream mounts, and so nothing
  // downstream can call getEntry()/loadEntries() for real data, before
  // that data actually exists. `storageReady` is the real signal;
  // `isLoading` is kept alongside it purely so the splash's own ~1.3s
  // animated progress bar still plays out for a moment even on the
  // fast localStorage-fallback dev path, rather than flashing instantly
  // — the overlay only ever clears once BOTH are satisfied.
  let isLoading = $state(true);
  let storageReady = $state(false);

  // Round 44: repeating reminders are kept going by the app — see utils/reminders.ts
  // (RECURRING REMINDERS). Run when the app starts and again whenever it comes back
  // to the foreground, at most once every 10 minutes. Never throws.
  const TOP_UP_EVERY_MS = 10 * 60_000;
  let lastTopUp = 0;
  function topUpRepeating(force = false) {
    const now = Date.now();
    if (!force && now - lastTopUp < TOP_UP_EVERY_MS) return;
    lastTopUp = now;
    void topUpRepeatingReminders(entries, (id, patch) => setReminderAtQuietly(id, patch.reminderAt)).catch(() => {});
  }
  function onVisible() {
    if (document.visibilityState === "visible") topUpRepeating();
  }

  onMount(() => {
    document.addEventListener("visibilitychange", onVisible);
    // Locked notes: forget the app password and put any open locked note back under its
    // lock once the app has been away / idle too long (see utils/autoLock.ts).
    const stopAutoLock = startAutoLock({
      getAway: () => autoLockAway.value,
      hasSecrets: hasLockedSecrets,
      lock: lockNow,
      setTimer: (fn, ms) => setTimeout(fn, ms),
      clearTimer: (handle) => clearTimeout(handle as ReturnType<typeof setTimeout>),
    });
    // Capture always runs regardless of the panel's own visibility
    // setting — see settings.svelte.ts's comment on debugPanelVisible.
    installGlobalCapture();

    // Round B: restore the signed-in session (if any) before the header first paints.
    // Local only, no network wait; never throws.
    initAccount();
    // Round C: sync listens for changes from the very start (so even the boot-time clean-up of
    // old Trash is seen); its first run waits until storage is ready, below.
    initSync();

    // Round 33: register imported fonts with the browser. Independent of
    // entry loading (a note just paints in its fallback face for the moment
    // before its font arrives), so it runs alongside rather than gating
    // anything. Never throws.
    void initCustomFonts();

    (async () => {
      await initFromBackend();
      // Same explicit-ordering reasoning tags.svelte.ts's own sync()
      // comment already documented: called here, once, right after
      // entries' own first-run seeding is guaranteed to have already
      // run (initFromBackend awaits storage.initStorage() and does its
      // own seeding check before returning) — not relying on
      // module-evaluation order between the two stores.
      syncTags();
      // Round 43: uploaded themes/icons live in IndexedDB now. Load them (moving
      // any still in the old localStorage list) BEFORE anything renders, so a
      // themed note never paints without its background. Neither init throws.
      await Promise.all([initCustomThemes(), initCustomIcons()]);
      storageReady = true;
      // Round 31: tapping a reminder notification opens its note/todo/board.
      // No-op outside the Android app. The returned unsubscribe isn't kept:
      // the root layout lives for the whole session.
      void installReminderTapHandler((path) => goto(path));
      // Round K: a file opened with MidNote from the phone's "Open with" list (its sheet is below).
      // No-op outside the Android app. Never throws.
      // The home-screen widget's three buttons (new note / todo / board) arrive the same way, as a link: open that
      // blank editor. When the same blank editor is already open (it may hold something typed), leave it first so
      // a fresh one opens instead of nothing happening.
      syncReadAloud(); // a reading may still be going on in the background service
      void startOpenWith(async (path) => {
        if (location.pathname === path) await goto("/");
        await goto(path);
      });
      topUpRepeating(true);
      // Round C: the first sync of the session (no-op when signed out). Never throws.
      startSync();
    })();

    return () => {
      document.removeEventListener("visibilitychange", onVisible);
      stopAutoLock();
    };
  });
</script>

{#if isLoading || !storageReady}
  <LoadingScreen oncomplete={() => (isLoading = false)} />
{:else}
  {@render children()}
{/if}
<ReadAloudBar />
<OpenFileSheet />
<ConfirmDialog
  bind:open={syncStatus.offerRestore}
  title="Restore your notes?"
  description="If this account already has notes, todos or boards in the cloud, this brings them to this phone. Nothing here is deleted and nothing is sent up."
  confirmLabel="Restore"
  onconfirm={() => void restoreFromCloud()}
/>
<Toast />
<LockPrompt />
<LoadingOverlay />
{#if debugPanelVisible.value}
  <DebugPanel />
{/if}
