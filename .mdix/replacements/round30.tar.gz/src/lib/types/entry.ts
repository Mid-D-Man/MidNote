// Shape mirrors mdix_files/schema/*.mdix exactly — a Note/Todo here maps
// 1:1 onto an entries/<id>.mdix file's @DATA fields, and EntryRef maps
// onto a notes_index.mdix / todos_index.mdix row. Keeping the frontend
// type identical to the DixScript schema means storage.ts's eventual swap
// from localStorage to real Tauri invoke calls is a backend-only change,
// not a data-shape rewrite.

// Mirrors themes.mdix's theme_preset()/theme_custom() QuickFuncs exactly
// — a pointer, never the actual image. Exactly one of name/customThemeId
// is non-null depending on kind. "preset" resolves against
// themePalette.ts's bundled solid-color palette (nothing about a
// preset's color lives in DixScript, same as the schema comment says);
// "custom" looks up an uploaded image by id in the CustomTheme registry
// (see custom-themes.mdix / stores/customThemes.svelte.ts) so one upload
// can be reused across many notes without duplicating the blob.
export interface ThemeRef {
  kind: "preset" | "custom";
  name: string | null;
  customThemeId: string | null;
}

// No-theme sentinel — matches the schema seed data's Themes.theme_preset("none")
// convention (a real preset name, not a null theme field).
export const NO_THEME: ThemeRef = { kind: "preset", name: "none", customThemeId: null };

// Mirrors custom-themes.mdix's custom_theme() shape exactly. `data` is a
// base64 data URL (already downscaled — see storage.ts's
// storeCustomThemeImage) so it can go straight into a CSS
// background-image without another decode step.
export interface CustomTheme {
  id: string;
  data: string;
  width: number;
  height: number;
  createdAt: string;
  // Precomputed once at upload time (storage.ts's storeCustomThemeImage,
  // via colorthief's real pixel-sampling — not guessed) — "#ffffff" or
  // "#000000", whichever reads legibly over this image's actual sampled
  // color. Computed once and stored rather than recomputed on every
  // render because getting it requires decoding the image into a canvas,
  // which is inherently async in a browser — not something any of this
  // app's synchronous $derived theme-resolution code (resolveTheme,
  // called from plain reactive expressions all over the app) could ever
  // do on the fly. Optional because it doesn't exist on any CustomTheme
  // uploaded before this field existed — see resolveTheme's fallback for
  // exactly what happens then (nothing regresses; old uploads keep their
  // pre-existing look).
  textColor?: string;
}

export type LockKeyMode = "app" | "custom";

// Same "pointer, not the value" shape ThemeRef uses — a preset name
// (themePalette.ts's ICON_PRESETS) or a small uploaded image, looked up
// by id in the CustomIcon registry below. No icon at all is `null` on
// EntryRef.icon directly (unlike ThemeRef, there's no "none" preset
// sentinel here — IconPicker's own "None" swatch just calls
// onChange(null)).
export type IconRef = { kind: "preset"; name: string } | { kind: "custom"; customIconId: string };

// Mirrors CustomTheme's registry shape, at icon-badge scale — a small
// uploaded image referenced by id (IconRef.customIconId) so one upload
// can be reused across many notes/todos without duplicating the blob.
// Kept as its own registry rather than reusing CustomTheme: a theme is
// a full-bleed background (JPEG, downscaled to ~720px, colorthief-
// analyzed for text contrast); an icon is a tiny badge (PNG for
// transparency, downscaled to ~128px — see storage.ts's
// storeCustomIconImage — with no contrast analysis needed since it's
// never painted behind text).
// A private, timestamped remark on a whole entry (round 30). No author
// field: MidNote has no accounts, every comment is the device owner's. Kept
// out of EntryRef on purpose — comments are content, not list-card
// metadata, so they're on the three heavy interfaces below and are excluded
// from the index rows (src-tauri/src/data/index.rs). See utils/comments.ts.
export interface EntryComment {
  id: string;
  text: string;
  createdAt: string; // ISO 8601
}

export interface CustomIcon {
  id: string;
  data: string;
  createdAt: string;
}

export interface EntryRef {
  id: string;
  title: string;
  tags: string[];
  lastModified: string;
  isBookmarked: boolean;
  encrypted: boolean;
  // Quick per-card strikethrough toggle from the ⋮ overflow menu — shared
  // between notes and todos deliberately (confirmed explicitly, not
  // assumed): same field, same toggle function, same visual treatment
  // for both card types. Not the same concept as a todo "step" being
  // checked off (steps/annotations already have their own completion
  // state inside Todo) — this is a whole-entry-level flag, e.g. "this
  // note/todo is done with, keep it around but visually mark it so."
  struck: boolean;
  // ⋮ overflow menu — pinned entries float to the top of the list, but
  // only while the search box is empty (see +page.svelte's sortedItems):
  // pinning is a browsing convenience, not something that should ever
  // hide or reorder an actual search result you went looking for.
  isPinned: boolean;
  // Per-entry visual theme, selected from the same Actions sheet as
  // Share/Duplicate. Distinct from settings.svelte.ts's appHeaderTheme/
  // appBodyTheme, which are the landing-page-wide defaults — these
  // override them for one specific note/todo.
  //
  // Split into two independent slots (was a single flat `theme` field):
  // headerTheme is what NoteCard/the todo row paint themselves with in
  // the list, AND what the editor's own header bar (NoteEditorHeader/
  // TodoHeader) tints — i.e. exactly the old `theme` field's behavior,
  // just renamed and re-scoped now that there's a second slot next to
  // it. bodyTheme is new: it paints the editor's actual writing surface
  // (see routes/note/[id]/+page.svelte's .scroll-area / the todo
  // equivalent). Deliberately restricted to solid-color presets only
  // for now (ThemePicker's `allowCustom={false}` for this slot) — an
  // uploaded image sitting directly behind live Tiptap caret/selection
  // rendering hasn't been verified safe yet, so custom images stay
  // header-only until that gets its own tested pass. See themePalette.ts's
  // resolveTheme, which both slots resolve through identically.
  headerTheme: ThemeRef;
  bodyTheme: ThemeRef;
  // Small badge shown next to the entry's title (list card only, for
  // now) — either a preset glyph or a small uploaded image (see IconRef
  // above), or null for no icon. Entry-only: there's no landing-page
  // equivalent (settings.svelte.ts's app-wide theme has just
  // header+body, no icon slot — an icon only makes sense pinned to one
  // specific note/todo).
  icon: IconRef | null;
  // Lock — real DixScript-Rust AES-256-GCM/Argon2id encryption via
  // src-tauri/src/data/crypto.rs, not a client-side shim. `encrypted`
  // above is the existing is-this-entry-locked flag (already had a
  // schema home before this feature); the three fields below are new.
  // While locked: `content` (notes) / `steps`+`annotations` (todos) AND
  // `tags` are cleared on the visible entry (matches notes_index.mdix's
  // existing "encrypted entries keep their real title but empty tags"
  // convention) and moved into the encrypted payload instead, so
  // nothing is lost — unlocking restores them from there, not from
  // anywhere else. `lockKeyMode` records which password this specific
  // entry needs, purely so the unlock prompt can ask for the right
  // thing ("your app password" vs "this note's password") — see
  // stores/lockSession.svelte.ts and utils/lockFlow.ts.
  lockKeyMode: LockKeyMode | null;
  lockedPayload: string | null;
  lockedKeyFile: string | null;
  // Trash — null means "not deleted, shows in the normal list normally".
  // A timestamp means "in Trash as of this moment", set/cleared entirely
  // through storage.ts's moveToTrash/restoreFromTrash — every existing
  // "Delete" affordance (CardOverflowMenu, the three editor headers)
  // already goes through entries.svelte.ts's single removeEntry()
  // choke point, so this is a soft delete everywhere Delete already
  // was, with zero call-site changes needed beyond that one function.
  // Storage.ts purges anything past TRASH_RETENTION_DAYS old on boot —
  // see purgeExpiredTrash — so this being set is never permanent on its
  // own.
  deletedAt: string | null;
}

export interface NotePage {
  id: string;
  content: string;
  // Custom label shown in PagesPanel/export instead of the auto-numbered
  // "Page N" — null means "no custom name, use the auto-numbered one".
  name: string | null;
}

export interface Note extends EntryRef {
  comments: EntryComment[];
  type: "regular";
  content: string;
  // Additional pages beyond this note's own main `content` field, which
  // always stays "page 1" — deliberately not folded into a single
  // `pages: NotePage[]` covering everything, so every existing note (and
  // every piece of code already reading/writing note.content directly:
  // search, NoteCard's preview, export, encryption) keeps working
  // completely unchanged for the common single-page case. Empty array
  // means "just the one page", same as before this field existed.
  pages: NotePage[];
  // Page 1 (content, above) isn't a NotePage object, so its custom name
  // — same optional-rename feature as every other page, see
  // PagesPanel.svelte — lives here instead of on a page record. null
  // means auto-numbered ("Page 1"), same convention as NotePage.name.
  page1Name: string | null;
}

export interface Step {
  id: string;
  category: string;
  title: string;
  content: string;
}

export interface Annotation {
  id: string;
  category: string;
  title: string;
  content: string;
}

export interface Todo extends EntryRef {
  comments: EntryComment[];
  type: "todo";
  categories: string[];
  steps: Step[];
  annotations: Annotation[];
}

// --- Boards ---
// A board is the third top-level entry type, a sibling to Note and Todo
// rather than a kind of page inside a note (decided explicitly, not
// assumed): a board carries its own persisted pan/zoom viewport, which
// has no meaning in the linear page-switcher the Pages feature uses,
// and extending EntryRef the same way Note/Todo do means it inherits
// title/tags/bookmark/pin/strike/theme/icon handling for free.
//
// Node and edge shapes are deliberately OUR OWN, not @xyflow/svelte's
// `Node`/`Edge` types re-exported. What gets persisted is only the
// handful of fields a board actually means (what/where/connected-to);
// everything xyflow adds at runtime (measured dimensions, internal
// z-index/handle bookkeeping, selection and drag state) is view state
// that gets recomputed on mount and must never reach storage. The
// board route converts between the two in one place each way — see
// toFlowNodes/fromFlowNodes there. This also keeps the on-disk shape
// stable if the canvas library is ever swapped out, which matters
// because the library choice is still only spike-confirmed.
export type BoardNodeKind = "text" | "image";

export interface BoardNode {
  id: string;
  kind: BoardNodeKind;
  x: number;
  y: number;
  label: string;
  // Only meaningful for kind "text" — the longer body under the label.
  body: string | null;
  // Only meaningful for kind "image" — an id into the CustomIcon
  // registry, reusing that existing upload/downscale path rather than
  // introducing a third image store. null means "no image picked yet",
  // which renders as an empty placeholder tile rather than an error.
  customIconId: string | null;
}

export interface BoardEdge {
  id: string;
  source: string;
  target: string;
}

// Persisted so reopening a board returns you to the part of it you were
// actually looking at — on a phone-sized canvas that matters a lot more
// than on desktop, since very little of a board fits on screen at once.
export interface BoardViewport {
  x: number;
  y: number;
  zoom: number;
}

export interface Board extends EntryRef {
  comments: EntryComment[];
  type: "board";
  nodes: BoardNode[];
  edges: BoardEdge[];
  viewport: BoardViewport | null;
}

export type Entry = Note | Todo | Board;

